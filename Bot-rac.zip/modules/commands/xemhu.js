const fs = require('fs');
const path = require('path');

module.exports.config = {
    name: "xemhu",
    version: "1.0.0",
    hasPermssion: 0,
    usePrefix: false,
    credits: "Mây Trắng",
    description: "Kiểm tra số tiền trong hũ Tài Xỉu",
    commandCategory: "Trò Chơi",
    usages: "@xemhu",
    cooldowns: 5
};

const potPath = path.join(__dirname, 'data', 'pot.json');

function readPot() {
    try {
        return JSON.parse(fs.readFileSync(potPath, 'utf8'));
    } catch (error) {
        return { amount: 0 };
    }
}

function replace(int) {
    return int.toString().replace(/(.)(?=(\d{3})+$)/g, '$1,');
}

module.exports.run = function ({ api, event }) {
    const { threadID, messageID } = event;
    const { sendMessage } = api;

    const pot = readPot();
    sendMessage(`Số tiền trong hũ Tài Xỉu: ${replace(pot.amount)} VNĐ`, threadID, messageID);
};