const fs = require('fs');
const path = require('path');

module.exports.config = {
    name: "giftcode",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "Mây Trắng",
    usePrefix: false,
    description: "Nhập giftcode",
    commandCategory: "Tiện ích",
    usages: "[giftcode]",
    cooldowns: 5
};

const dataPath = path.join(__dirname, 'data', 'data.json');
const giftcodePath = path.join(__dirname, 'data', 'giftcode.json');

module.exports.run = async function ({ event, api, args }) {
    const { threadID, messageID, senderID } = event;
    const { sendMessage } = api;

    if (args.length !== 1) {
        return sendMessage("Sai cú pháp. Vui lòng nhập đúng cú pháp: @giftcode [giftcode]", threadID, messageID);
    }

    const giftcode = args[0];


    let giftcodes;
    try {
        giftcodes = JSON.parse(fs.readFileSync(giftcodePath, 'utf8'));
    } catch (error) {
        return sendMessage("Không thể đọc dữ liệu giftcode.", threadID, messageID);
    }


    if (!giftcodes[giftcode]) {
        return sendMessage("Giftcode không hợp lệ.", threadID, messageID);
    }


    let data;
    try {
        data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (error) {
        return sendMessage("Không thể đọc dữ liệu người dùng.", threadID, messageID);
    }


    const user = data.find(user => user.user_id === senderID);
    if (!user) {
        return sendMessage("Chưa Đăng Ký @dangkytx để đăng ký.", threadID, messageID);
    }


    if (user.used_giftcodes && user.used_giftcodes.includes(giftcode)) {
        return sendMessage("Bạn đã sử dụng giftcode này rồi.", threadID, messageID);
    }


    if (giftcodes[giftcode].uses <= 0) {
        return sendMessage("Giftcode đã hết lượt sử dụng.", threadID, messageID);
    }

    giftcodes[giftcode].uses--;


    user.balance += giftcodes[giftcode].amount;


    if (!user.used_giftcodes) {
        user.used_giftcodes = [];
    }
    user.used_giftcodes.push(giftcode);


    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
    fs.writeFileSync(giftcodePath, JSON.stringify(giftcodes, null, 2));

    sendMessage(`Bạn đã nhận được ${giftcodes[giftcode].amount} VNĐ từ giftcode ${giftcode}. Số dư hiện tại của bạn là ${user.balance} VNĐ.`, threadID, messageID);
};