  /*lưu ý: phần thay key thì vô web https://www.screenshotmachine.com/ 
  tạo key rồi thay vô 
  api cap https://replit.com/@Duychaybot0/APIcap?v=1 
  fork về bấm run rồi thay vô link repl
  thêm tiện ích này để lấy cookie rồi thay vô
  https://chrome.google.com/webstore/detail/get-token-cookie/naciaagbkifhpnoodlkhbejjldaiffcm
  */
  const axios = require("axios");
  const fs = require("fs");
  module.exports.config = {
    name: "cap",
    version: "0.0.1",
    hasPermssion: 0,
    credits: "Tpk - táo",
    description: "Cap màn hình",
    commandCategory: "Người dùng",
      cooldowns: 5
  }
  module.exports.onLoad = async () => {
      const { existsSync } = global.nodemodule["fs-extra"];
      const { resolve } = global.nodemodule["path"];

      const path = resolve(__dirname, "cache", "pornlist.txt");

      if (!existsSync(path)) return await global.utils.downloadFile("https://raw.githubusercontent.com/blocklistproject/Lists/master/porn.txt", path);
      else return;
  }

  module.exports.run = async ({ event, api, args, Currencies }) => {
    const request = require("request");
  const fs = require("fs");

     const { threadID, messageID, senderID } = event;
      var cc = [
        "https://i.imgur.com/3yv1a9Z.jpeg",
  "https://i.imgur.com/oNSoyAP.jpeg",
  "",
   "",
                ];
  let image = [];
   for(let i = 0; i < 4; i++) {
      const stream = (await axios.get(cc[i], {
          responseType: "stream"
      })).data;
      image.push(stream);
  };
    const ccc = {
      body: `🌐==== [ 𝗖𝗔𝗣 𝗙𝗔𝗖𝗘𝗕𝗢𝗢𝗞 ] ====🌐
  ━━━━━━━━━━━━━━━━━━
  [👉]➜ 𝗗𝘂̛𝗼̛́𝗶 𝗹𝗮̀ 𝗰𝗮́𝗰 𝗹𝗼𝗮̣𝗶 𝗰𝗮𝗽 𝗯𝗮̣𝗻 𝗵𝗮̃𝘆 𝗰𝗵𝗼̣𝗻

  𝟭. 𝗰𝗮𝗽 𝘄𝗮𝗹𝗹 𝗱𝗮̣𝗻𝗴 đ𝗶𝗲̣̂𝗻 𝘁𝗵𝗼𝗮̣𝗶 𝗻𝗲̂̀𝗻 𝘁𝗿𝗮̆́𝗻𝗴 ⚪
  𝟮. 𝗰𝗮𝗽 𝘄𝗮𝗹𝗹 𝗱𝗮̣𝗻𝗴 𝗻𝗲̂̀𝗻 𝗽𝗰 𝗻𝗲̂̀𝗻 𝘁𝗿𝗮̆́𝗻𝗴 ⚪
  𝟯. 𝗖𝗮𝗽 𝘄𝗮𝗹𝗹 𝗱𝗮̣𝗻𝗴 đ𝗶𝗲̣̂𝗻 𝘁𝗵𝗼𝗮̣𝗶 𝗻𝗲̂̀𝗻 đ𝗲𝗻 🖤
  𝟰. 𝗖𝗮𝗽 𝘄𝗮𝗹𝗹 𝗱𝗮̣𝗻𝗴 𝗽𝗰 𝗻𝗲̂̀𝗻 đ𝗲𝗻 🖤

  [⚠️]➜ 𝗥𝗲𝗽𝗹𝘆 𝘁𝗶𝗻 𝗻𝗵𝗮̆́𝗻 𝗻𝗮̀𝘆 𝗸𝗲̀𝗺 𝘀𝗼̂́ 𝘁𝗵𝘂̛́ 𝘁𝘂̛̣ đ𝗲̂̉ 𝗰𝗵𝗼̣𝗻
   `,
      attachment: image
  };
      if (!args[0]) {        
          return api.sendMessage(ccc, event.threadID, (error, info) => {

              global.client.handleReply.push({
                  type: "choosee",
                  name: this.config.name,
                  author: event.senderID,
                  messageID: info.messageID
              })
          })
      }
  }
      module.exports.handleReply = async function ({
      args,
      event,
      Users,
      api,
      handleReply,
      Currencies,
      __GLOBAL
  }) {
    const axios = require("axios");
    const fs = require("fs-extra");
    const request = require("request");
    let data = (await Currencies.getData(event.senderID)).ghepTime;


      switch (handleReply.type) {
      case "choosee": {
          switch (event.body) {
          case "1": {
            const axios = require('axios');
            const moment = require("moment-timezone");
    const tpkk = moment.tz("Asia/Ho_Chi_Minh").format("DD/MM/YYYY || HH:mm:ss");
    let name = await Users.getNameUser(event.senderID);
      let mentions = [];
      mentions.push({
        tag: name,
        id: event.senderID
      })
         api.unsendMessage(handleReply.messageID);
      api.sendMessage({body: `[⏳]➜ đ𝗼̛̣𝗶 𝘁𝗶́ 𝗻𝗵𝗮 ${name} 𝗯𝗼𝘁 đ𝗮𝗻𝗴 𝗰𝗮𝗽`, mentions}, event.threadID, event.messageID);
     if (Object.keys(event.mentions).length == 1) {
        var uid = Object.keys(event.mentions)[0];
      }
    else {
            var uid = event.senderID;
      }
      var cookies = "oo=v1; usida=eyJ2ZXIiOjEsImlkIjoiQXM0cDNvbTFzb2pyNDMiLCJ0aW1lIjoxNzAwOTQyNTY2fQ%3D%3D; m_ls=%7B%22c%22%3A%7B%221%22%3A%22HCwAABby4AkW1vuP0gMTBRbwrdG65P4bAA%22%2C%222%22%3A%22GSwVQBxMAAAWARaArYDTDBYAABV-HEwAABYAFoCtgNMMFgAAFigA%22%2C%2295%22%3A%22HCwAABYIFpjp45UHEwUW8K3RuuT-GwA%22%7D%2C%22d%22%3A%22b66be23e-029c-40b6-a897-bd43db7cb944%22%2C%22s%22%3A%220%22%2C%22u%22%3A%221lq5w3%22%7D; datr=ndFIZNIx4hyZ1oCzoMrUK8-8; sb=ndFIZFkLD2WpHIj1ub3x0jL6; wl_cbv=v2%3Bclient_version%3A2370%3Btimestamp%3A1701353247; c_user=100088578121564; xs=37%3AW6vz7tcyr71Y1A%3A2%3A1701353347%3A-1%3A6276; fr=0NOesEdy0FipMNSQd.AWXPxfCM2-GV7WnUXFFWGueUNmc.BkSNGd.dX.AAA.0.0.BlaJeC.AWXCOJbuZb8; m_page_voice=100088578121564; wd=360x561; locale=vi_VN; fbl_cs=AhA9480MWA7uwirG05KGyuyuGGU2ZmZva0NxQmxRNGRQUlM4RXNXM3hPNw; fbl_ci=1236814656936415; fbl_st=100638968%3BT%3A28355926; vpd=v1%3B561x360x3; useragent=TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDUuMS4xOyB2aXZvIFYzTWF4KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvOTYuMC40NjY0LjQ2IE1vYmlsZSBTYWZhcmkvNTM3LjM2; _uafec=Mozilla%2F5.0%20(Linux%3B%20Android%205.1.1%3B%20vivo%20V3Max)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F96.0.4664.46%20Mobile%20Safari%2F537.36;",
      vaildItems = ['sb', 'datr', 'c_user', 'xs', 'm_pixel_ratio', 'locale', 'wd', 'fr', 'presence', 'xs', 'm_page_voice', 'fbl_st', 'fbl_ci', 'fbl_cs', 'vpd', 'wd', 'fr', 'presence'];
      cookies.split(';').forEach(item => {
          var data = item.split('=');
          if (vaildItems.includes(data[0])) cookie += `${data[0]}=${data[1]};`;
      });
      var url = encodeURI(encodeURI((`https://apicap.mdongdev.repl.co/screenshot/${uid}/${cookies}`))),
          path = __dirname + `/cache/${uid}.png`;
      axios({
          method: "GET",
          url: `https://api.screenshotmachine.com/?key=ca867a&url=${url}&dimension=480x800&cacheLimit=0&delay=400`,
          responseType: "arraybuffer"
      }).then(res => {
          fs.writeFileSync(path, Buffer.from(res.data, "utf-8"));
          api.sendMessage({body: `🌐==== [ 𝗖𝗔𝗣 𝗙𝗔𝗖𝗘𝗕𝗢𝗢𝗞 ] ====🌐
  ━━━━━━━━━━━━━━━━━━━
  [🌸]➜ 𝗕𝗼𝘁 𝘃𝘂̛̀𝗮 𝗰𝗮𝗽 𝘅𝗼𝗻𝗴 𝘆𝗲̂𝘂 𝗰𝘂̉𝗮 𝗰𝘂̉𝗮 𝗯𝗮̣𝗻
  ━━━━━━━━━━━━━━━━━━━
  [⚜️]➜ 𝗖𝗮𝗽 𝘄𝗮𝗹𝗹 𝗙𝗮𝗰𝗲𝗯𝗼𝗼𝗸 𝗱𝗮̣𝗻𝗴 đ𝗶𝗲̣̂𝗻 𝘁𝗵𝗼𝗮̣𝗶 𝗻𝗲̂̀𝗻 𝘁𝗿𝗮̆́𝗻𝗴 𝗰𝘂̉𝗮 𝗯𝗮̣𝗻 đ𝗮̂𝘆 `,mentions, attachment: fs.createReadStream(path) }, event.threadID, () => fs.unlinkSync(path), event.messageID);
      }).catch(err => console.log(err));
          };
              break;
          case "2": {
            const axios = require('axios');
            api.unsendMessage(handleReply.messageID);
  const moment = require("moment-timezone");
    const tpkk = moment.tz("Asia/Ho_Chi_Minh").format("DD/MM/YYYY || HH:mm:ss");
    let name = await Users.getNameUser(event.senderID);
      let mentions = [];
      mentions.push({
        tag: name,
        id: event.senderID
      })
         api.unsendMessage(handleReply.messageID);
      api.sendMessage({body: `[⏳]➜ đ𝗼̛̣𝗶 𝘁𝗶́ 𝗻𝗵𝗮 ${name} 𝗯𝗼𝘁 đ𝗮𝗻𝗴 𝗰𝗮𝗽`, mentions}, event.threadID, event.messageID);
     if (Object.keys(event.mentions).length == 1) {
        var uid = Object.keys(event.mentions)[0];
      }
    else {
            var uid = event.senderID;
      }
      var cookies = `"oo=v1; usida=eyJ2ZXIiOjEsImlkIjoiQXM0cDNvbTFzb2pyNDMiLCJ0aW1lIjoxNzAwOTQyNTY2fQ%3D%3D; m_ls=%7B%22c%22%3A%7B%221%22%3A%22HCwAABby4AkW1vuP0gMTBRbwrdG65P4bAA%22%2C%222%22%3A%22GSwVQBxMAAAWARaArYDTDBYAABV-HEwAABYAFoCtgNMMFgAAFigA%22%2C%2295%22%3A%22HCwAABYIFpjp45UHEwUW8K3RuuT-GwA%22%7D%2C%22d%22%3A%22b66be23e-029c-40b6-a897-bd43db7cb944%22%2C%22s%22%3A%220%22%2C%22u%22%3A%221lq5w3%22%7D; datr=ndFIZNIx4hyZ1oCzoMrUK8-8; sb=ndFIZFkLD2WpHIj1ub3x0jL6; wl_cbv=v2%3Bclient_version%3A2370%3Btimestamp%3A1701353247; c_user=100088578121564; xs=37%3AW6vz7tcyr71Y1A%3A2%3A1701353347%3A-1%3A6276; fr=0NOesEdy0FipMNSQd.AWXPxfCM2-GV7WnUXFFWGueUNmc.BkSNGd.dX.AAA.0.0.BlaJeC.AWXCOJbuZb8; m_page_voice=100088578121564; wd=360x561; locale=vi_VN; fbl_cs=AhA9480MWA7uwirG05KGyuyuGGU2ZmZva0NxQmxRNGRQUlM4RXNXM3hPNw; fbl_ci=1236814656936415; fbl_st=100638968%3BT%3A28355926; vpd=v1%3B561x360x3; useragent=TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDUuMS4xOyB2aXZvIFYzTWF4KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvOTYuMC40NjY0LjQ2IE1vYmlsZSBTYWZhcmkvNTM3LjM2; _uafec=Mozilla%2F5.0%20(Linux%3B%20Android%205.1.1%3B%20vivo%20V3Max)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F96.0.4664.46%20Mobile%20Safari%2F537.36;"`,
      vaildItems = ['sb', 'datr', 'c_user', 'xs', 'm_pixel_ratio', 'locale', 'wd', 'fr', 'presence', 'xs', 'm_page_voice', 'fbl_st', 'fbl_ci', 'fbl_cs', 'vpd', 'wd', 'fr', 'presence'];
      cookies.split(';').forEach(item => {
          var data = item.split('=');
          if (vaildItems.includes(data[0])) cookie += `${data[0]}=${data[1]};`;
      });
      var url = encodeURI(encodeURI((`https://apicap.mdongdev.repl.co/screenshot/${uid}/${cookies}}`))),
          path = __dirname + `/cache/${uid}.png`;
      axios({
          method: "GET",
          url: `https://api.screenshotmachine.com/?key=ca867a&url=${url}&dimension=1920x1080&cacheLimit=0&delay=400`,
          responseType: "arraybuffer"
      }).then(res => {
          fs.writeFileSync(path, Buffer.from(res.data, "utf-8"));
          api.sendMessage({body: `‎🌐==== [ 𝗖𝗔𝗣 𝗙𝗔𝗖𝗘𝗕𝗢𝗢𝗞 ] ====🌐
  ━━━━━━━━━━━━━━━━━━━
  [🌸]➜ 𝗕𝗼𝘁 𝘃𝘂̛̀𝗮 𝗰𝗮𝗽 𝘅𝗼𝗻𝗴 𝘆𝗲̂𝘂 𝗰𝘂̉𝗮 𝗰𝘂̉𝗮 𝗯𝗮̣𝗻
  ━━━━━━━━━━━━━━━━━━━
  [⚜️]➜ 𝗖𝗮𝗽 𝘄𝗮𝗹𝗹 𝗙𝗮𝗰𝗲𝗯𝗼𝗼𝗸 𝗱𝗮̣𝗻𝗴 𝗽𝗰 𝗻𝗲̂̀𝗻 𝘁𝗿𝗮̆́𝗻𝗴 𝗰𝘂̉𝗮 𝗯𝗮̣𝗻 đ𝗮̂𝘆`,mentions, attachment: fs.createReadStream(path) }, event.threadID, () => fs.unlinkSync(path), event.messageID);
      }).catch(err => console.log(err));
          };
              break;
          case "3": {
            const axios = require('axios');
            api.unsendMessage(handleReply.messageID);
  const moment = require("moment-timezone");
    const tpkk = moment.tz("Asia/Ho_Chi_Minh").format("DD/MM/YYYY || HH:mm:ss");
    let name = await Users.getNameUser(event.senderID);
      let mentions = [];
      mentions.push({
        tag: name,
        id: event.senderID
      })
         api.unsendMessage(handleReply.messageID);
      api.sendMessage({body: `[⏳]➜ đ𝗼̛̣𝗶 𝘁𝗶́ 𝗻𝗵𝗮 ${name} 𝗯𝗼𝘁 đ𝗮𝗻𝗴 𝗰𝗮𝗽`, mentions}, event.threadID, event.messageID);
     if (Object.keys(event.mentions).length == 1) {
        var uid = Object.keys(event.mentions)[0];
      }
    else {
            var uid = event.senderID;
      }
      var cookie = `oo=v1; usida=eyJ2ZXIiOjEsImlkIjoiQXM0cDNvbTFzb2pyNDMiLCJ0aW1lIjoxNzAwOTQyNTY2fQ%3D%3D; m_ls=%7B%22c%22%3A%7B%221%22%3A%22HCwAABby4AkW1vuP0gMTBRbwrdG65P4bAA%22%2C%222%22%3A%22GSwVQBxMAAAWARaArYDTDBYAABV-HEwAABYAFoCtgNMMFgAAFigA%22%2C%2295%22%3A%22HCwAABYIFpjp45UHEwUW8K3RuuT-GwA%22%7D%2C%22d%22%3A%22b66be23e-029c-40b6-a897-bd43db7cb944%22%2C%22s%22%3A%220%22%2C%22u%22%3A%221lq5w3%22%7D; datr=ndFIZNIx4hyZ1oCzoMrUK8-8; sb=ndFIZFkLD2WpHIj1ub3x0jL6; wl_cbv=v2%3Bclient_version%3A2370%3Btimestamp%3A1701353247; c_user=100088578121564; xs=37%3AW6vz7tcyr71Y1A%3A2%3A1701353347%3A-1%3A6276; fr=0NOesEdy0FipMNSQd.AWXPxfCM2-GV7WnUXFFWGueUNmc.BkSNGd.dX.AAA.0.0.BlaJeC.AWXCOJbuZb8; m_page_voice=100088578121564; wd=360x561; locale=vi_VN; fbl_cs=AhA9480MWA7uwirG05KGyuyuGGU2ZmZva0NxQmxRNGRQUlM4RXNXM3hPNw; fbl_ci=1236814656936415; fbl_st=100638968%3BT%3A28355926; vpd=v1%3B561x360x3; useragent=TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDUuMS4xOyB2aXZvIFYzTWF4KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvOTYuMC40NjY0LjQ2IE1vYmlsZSBTYWZhcmkvNTM3LjM2; _uafec=Mozilla%2F5.0%20(Linux%3B%20Android%205.1.1%3B%20vivo%20V3Max)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F96.0.4664.46%20Mobile%20Safari%2F537.36;`,
      vaildItems = ['sb', 'datr', 'c_user', 'xs', 'm_pixel_ratio', 'locale', 'wd', 'fr', 'presence', 'xs', 'm_page_voice', 'fbl_st', 'fbl_ci', 'fbl_cs', 'vpd', 'wd', 'fr', 'presence'];
      cookie.split(';').forEach(item => {
          var data = item.split('=');
          if (vaildItems.includes(data[0])) cookie += `${data[0]}=${data[1]};`;
      });
      var url = encodeURI(encodeURI((`https://apicap.mdongdev.repl.co/screenshot/${uid}/${cookie}}`))),
          path = __dirname + `/cache/${uid}.png`;
      axios({
          method: "GET",
          url: `https://api.screenshotmachine.com/?key=ca867a&url=${url}&dimension=480x800&cacheLimit=0&delay=400`,
          responseType: "arraybuffer"
      }).then(res => {
          fs.writeFileSync(path, Buffer.from(res.data, "utf-8"));
          api.sendMessage({body: `🌐==== [ 𝗖𝗔𝗣 𝗙𝗔𝗖𝗘𝗕𝗢𝗢𝗞 ] ====🌐
  ━━━━━━━━━━━━━━━━━━━
  [🌸]➜ 𝗕𝗼𝘁 𝘃𝘂̛̀𝗮 𝗰𝗮𝗽 𝘅𝗼𝗻𝗴 𝘆𝗲̂𝘂 𝗰𝘂̉𝗮 𝗰𝘂̉𝗮 𝗯𝗮̣𝗻
  ━━━━━━━━━━━━━━━━━━━
  [⚜️]➜ 𝗖𝗮𝗽 𝘄𝗮𝗹𝗹 𝗙𝗮𝗰𝗲𝗯𝗼𝗼𝗸 𝗱𝗮̣𝗻𝗴 đ𝗶𝗲̣̂𝗻 𝘁𝗵𝗼𝗮̣𝗶 𝗻𝗲̂̀𝗻 đ𝗲𝗻 𝗰𝘂̉𝗮 𝗯𝗮̣𝗻 đ𝗮̂𝘆`,mentions, attachment: fs.createReadStream(path) }, event.threadID, () => fs.unlinkSync(path), event.messageID);
      }).catch(err => console.log(err));
          };
              break;
          case "4": {
            const axios = require('axios');
            api.unsendMessage(handleReply.messageID);
  const moment = require("moment-timezone");
    const tpkk = moment.tz("Asia/Ho_Chi_Minh").format("DD/MM/YYYY || HH:mm:ss");
    let name = await Users.getNameUser(event.senderID);
      let mentions = [];
      mentions.push({
        tag: name,
        id: event.senderID
      })
         api.unsendMessage(handleReply.messageID);
      api.sendMessage({body: `[⏳]➜ đ𝗼̛̣𝗶 𝘁𝗶́ 𝗻𝗵𝗮 ${name} 𝗯𝗼𝘁 đ𝗮𝗻𝗴 𝗰𝗮𝗽`, mentions}, event.threadID, event.messageID);
     if (Object.keys(event.mentions).length == 1) {
        var uid = Object.keys(event.mentions)[0];
      }
    else {
            var uid = event.senderID;
      }
      var cookie = `oo=v1; usida=eyJ2ZXIiOjEsImlkIjoiQXM0cDNvbTFzb2pyNDMiLCJ0aW1lIjoxNzAwOTQyNTY2fQ%3D%3D; m_ls=%7B%22c%22%3A%7B%221%22%3A%22HCwAABby4AkW1vuP0gMTBRbwrdG65P4bAA%22%2C%222%22%3A%22GSwVQBxMAAAWARaArYDTDBYAABV-HEwAABYAFoCtgNMMFgAAFigA%22%2C%2295%22%3A%22HCwAABYIFpjp45UHEwUW8K3RuuT-GwA%22%7D%2C%22d%22%3A%22b66be23e-029c-40b6-a897-bd43db7cb944%22%2C%22s%22%3A%220%22%2C%22u%22%3A%221lq5w3%22%7D; datr=ndFIZNIx4hyZ1oCzoMrUK8-8; sb=ndFIZFkLD2WpHIj1ub3x0jL6; wl_cbv=v2%3Bclient_version%3A2370%3Btimestamp%3A1701353247; c_user=100088578121564; xs=37%3AW6vz7tcyr71Y1A%3A2%3A1701353347%3A-1%3A6276; fr=0NOesEdy0FipMNSQd.AWXPxfCM2-GV7WnUXFFWGueUNmc.BkSNGd.dX.AAA.0.0.BlaJeC.AWXCOJbuZb8; m_page_voice=100088578121564; wd=360x561; locale=vi_VN; fbl_cs=AhA9480MWA7uwirG05KGyuyuGGU2ZmZva0NxQmxRNGRQUlM4RXNXM3hPNw; fbl_ci=1236814656936415; fbl_st=100638968%3BT%3A28355926; vpd=v1%3B561x360x3; useragent=TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDUuMS4xOyB2aXZvIFYzTWF4KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvOTYuMC40NjY0LjQ2IE1vYmlsZSBTYWZhcmkvNTM3LjM2; _uafec=Mozilla%2F5.0%20(Linux%3B%20Android%205.1.1%3B%20vivo%20V3Max)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F96.0.4664.46%20Mobile%20Safari%2F537.36;`,
      vaildItems = ['sb', 'datr', 'c_user', 'xs', 'm_pixel_ratio', 'locale', 'wd', 'fr', 'presence', 'xs', 'm_page_voice', 'fbl_st', 'fbl_ci', 'fbl_cs', 'vpd', 'wd', 'fr', 'presence'];
      cookie.split(';').forEach(item => {
          var data = item.split('=');
          if (vaildItems.includes(data[0])) cookie += `${data[0]}=${data[1]};`;
      });
      var url = encodeURI(encodeURI((`https://apicap.mdongdev.repl.co/screenshot/${uid}/${cookie}`))),
          path = __dirname + `/cache/${uid}.png`;
      axios({
          method: "GET",
          url: `https://api.screenshotmachine.com/?key=ca867a&url=${url}&dimension=1920x1080&cacheLimit=0&delay=400`,
          responseType: "arraybuffer"
      }).then(res => {
          fs.writeFileSync(path, Buffer.from(res.data, "utf-8"));
          api.sendMessage({body: `🌐==== [ 𝗖𝗔𝗣 𝗙𝗔𝗖𝗘𝗕𝗢𝗢𝗞 ] ====🌐
  ━━━━━━━━━━━━━━━━━━━
  [🌸]➜ 𝗕𝗼𝘁 𝘃𝘂̛̀𝗮 𝗰𝗮𝗽 𝘅𝗼𝗻𝗴 𝘆𝗲̂𝘂 𝗰𝘂̉𝗮 𝗰𝘂̉𝗮 𝗯𝗮̣𝗻
  ━━━━━━━━━━━━━━━━━━━
  [⚜️]➜ 𝗖𝗮𝗽 𝘄𝗮𝗹𝗹 𝗙𝗮𝗰𝗲𝗯𝗼𝗼𝗸 𝗱𝗮̣𝗻𝗴 𝗽𝗰 𝗻𝗲̂̀𝗻 đ𝗲𝗻 𝗰𝘂̉𝗮 𝗯𝗮̣𝗻 đ𝗮̂𝘆`,mentions, attachment: fs.createReadStream(path) }, event.threadID, () => fs.unlinkSync(path), event.messageID);
      }).catch(err => console.log(err));
            }
              break;
            default:
             const choose = parseInt(event.body);
                if (isNaN(event.body)) return api.sendMessage("n", event.threadID, event.messageID);
                if (choose > 2 || choose < 1) return api.sendMessage("u", event.threadID, event.messageID); 
           }
        }
     }
  }