const fs = require('fs');
const path = require('path');

module.exports.config = {
    name: "chuyentien",
    version: "1.0.0",
    hasPermssion: 0,
    usePrefix: false,
    credits: "Mây Trắng",
    description: "Chuyển tiền cho người dùng khác",
    commandCategory: "Tài chính",
    usages: "Replly Tin Nhắn @chuyentien [số tiền]",
    cooldowns: 5
};

const dataPath = path.join(__dirname, 'data', 'data.json');

module.exports.run = async function ({ api, event, args, Users }) {
    const { threadID, messageID, senderID, messageReply } = event;
    const { sendMessage } = api;


    if (args.length !== 1 || isNaN(parseInt(args[0]))) {
        return sendMessage("Sai cú pháp. Vui lòng nhập đúng cú pháp: Relly tin nhắn người muốn chuyển @chuyentien [số tiền]", threadID, messageID);
    }

    const amount = parseInt(args[0]);


    if (amount <= 0) return sendMessage("Số tiền phải trên 0", threadID, messageID);


    let data;
    try {
        data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (error) {
        return sendMessage("Chưa Đăng Ký @dangkytx để đăng ký", threadID, messageID);
    }


    const sender = data.find(user => user.user_id === senderID);
    if (!sender) return sendMessage("Chưa Đăng Ký @dangkytx để đăng ký", threadID, messageID);
    if (sender.balance < amount) return sendMessage("Số dư của bạn không đủ để thực hiện giao dịch này.", threadID, messageID);


    if (!messageReply || !messageReply.senderID) {
        return sendMessage("Vui lòng trả lời tin nhắn của người bạn muốn chuyển tiền.", threadID, messageID);
    }

    const receiverID = messageReply.senderID;
    const receiver = data.find(user => user.user_id === receiverID);
    if (!receiver) return sendMessage("Chưa Đăng Ký @dangkytx để đăng ký", threadID, messageID);


    sender.balance -= amount;
    receiver.balance += amount;


    try {
        fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
    } catch (error) {
        return sendMessage("Không thể lưu dữ liệu người dùng.", threadID, messageID);
    }

    const senderName = sender.full_name;
    const receiverName = receiver.full_name;
    const senderBalance = sender.balance.toLocaleString();

    sendMessage(`💵 Chuyển thành công ${amount.toLocaleString()} VNĐ tới ${receiverName}✨\n💳 Số dư còn lại của bạn: ${senderBalance} VNĐ`, threadID, messageID);
};