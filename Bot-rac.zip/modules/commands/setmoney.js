const fs = require('fs');
const path = require('path');

module.exports.config = {
    name: "setmoney",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "Mây Trắng",
    description: "Thay đổi số tiền của người dùng",
    commandCategory: "Admin",
    usages: "[số tiền] (phải reply tin nhắn của người dùng)",
    cooldowns: 5
};

const dataPath = path.join(__dirname, 'data', 'data.json');

module.exports.run = async function ({ api, event, args, Users }) {
    const { threadID, messageID, type, messageReply } = event;
    const { sendMessage } = api;


    if (args.length !== 1 || isNaN(parseInt(args[0]))) {
        return sendMessage("Sai cú pháp. Vui lòng nhập đúng cú pháp: @setmoney [số tiền] (phải reply tin nhắn của người dùng)", threadID, messageID);
    }

    if (type !== "message_reply") {
        return sendMessage("Bạn phải reply tin nhắn của người dùng để thay đổi số tiền.", threadID, messageID);
    }

    const targetID = messageReply.senderID;
    const amount = parseInt(args[0]);


    if (amount <= 0) return sendMessage("Số tiền phải trên 0.", threadID, messageID);


    let data;
    try {
        data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (error) {
        return sendMessage("Không thể đọc dữ liệu người dùng.", threadID, messageID);
    }


    const user = data.find(user => user.user_id === targetID);
    if (!user) return sendMessage("Không tìm thấy người dùng trong dữ liệu.", threadID, messageID);


    user.balance = amount;


    try {
        fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
    } catch (error) {
        return sendMessage("Không thể lưu dữ liệu người dùng.", threadID, messageID);
    }

    sendMessage(`Đã thay đổi số tiền của người dùng ${user.full_name} (UID: ${targetID}) thành ${amount} VNĐ.`, threadID, messageID);
};