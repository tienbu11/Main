const axios = require('axios');
const request = require('request');
const fs = require("fs-extra");
module.exports.config = {
  name: "admin",
  version: "1.0.5",
  usePrefix: false,
  hasPermssion: 0,
  credits: "Mirai Team",
  description: "Bật tắt chế độ chỉ qtv dùng lệnh",
  commandCategory: "ADMIN",
  usages: " bật tắt chế độ chỉ admin và qtv dùng lệnh",
    cooldowns: 5,
    dependencies: {
        "fs-extra": ""
    }
};

module.exports.languages = {
    "vi": {
      "addedNewNDH": 'Đã thêm thành công %1 người dùng trở thành Người hỗ trợ\n\n%2',
        "listAdmin": `[ Danh Sách Admin ]\n────────────────\n\n%1\n\n\n[ Người điều hành ]\n────────────────\n\n%2`,
        "notHavePermssion": 'Bạn không đủ quyền hạn để có thể sử dụng chức năng "%1"',
        "addedNewAdmin": 'Đã thêm %1 người dùng trở thành người điều hành bot:\n\n%2',
        "removedAdmin": 'Đã gỡ bỏ %1 người điều hành bot:\n\n%2',
  "removedNDH": '𝗠𝗢𝗗𝗘 - Đã gỡ thành công vai trò Người hỗ trợ %1 người dùng trở lại làm thành viên\n\n%2'
    },
    "en": {
        "listAdmin": '[Admin] Admin list: \n\n%1',
        "notHavePermssion": '[Admin] You have no permission to use "%1"',
        "addedNewAdmin": '[Admin] Added %1 Admin :\n\n%2',
        "removedAdmin": '[Admin] Remove %1 Admin:\n\n%2'
    }
}
module.exports.onLoad = function() {
    const { writeFileSync, existsSync } = require('fs-extra');
    const { resolve } = require("path");
    const path = resolve(__dirname, 'bot', 'data.json');
    if (!existsSync(path)) {
        const obj = {
            adminbox: {}
        };
        writeFileSync(path, JSON.stringify(obj, null, 4));
    } else {
        const data = require(path);
        if (!data.hasOwnProperty('adminbox')) data.adminbox = {};
        writeFileSync(path, JSON.stringify(data, null, 4));
    }
}

module.exports.run = async  ({ api, event, args, Users, permssion, getText, Currencies }) => {
const content = args.slice(1, args.length);
axios.get('https://hoanghao.me/api/images/vdanime').then(res => {
  let ext = res.data.url.substring(res.data.url.lastIndexOf(".") + 1);
let callback = function () {
    if (args.length == 0)
      api.sendMessage({body:`[ ADMIN CONFIG SETTING ]\n────────────────\n${global.config.PREFIX} admin add → Thêm người dùng làm Admin\n${global.config.PREFIX} admin remove → Gỡ vai trò admin\n${global.config.PREFIX} admin addndh → Thêm người dùng làm Người Hỗ Trợ\n${global.config.PREFIX} admin removendh → Gỡ vai trò Người hỗ trợ\n${global.config.PREFIX} admin list → Xem danh sách admin và người hỗ trợ\n${global.config.PREFIX} admin qtvonly → Bật tắt chế độ chỉ quản trị viên mới được dùng bot\n${global.config.PREFIX} admin ndhonly → Bật tắt chế độ người hỗ trợ\n${global.config.PREFIX} admin only → Bật tắt chế độ chỉ admin mới dùng được bot\n${global.config.PREFIX} admin ibrieng → Bật tắt chế độ cấm người dùng nhắn tin với bot\n${global.config.PREFIX} admin reload [time] → Khởi động lại bot\n${global.config.PREFIX} admin echo [text] → Nhắn câu mà bạn yêu cầu\n${global.config.PREFIX} admin read [tên mdl] → Gửi scr của modules\n${global.config.PREFIX} admin rename [tên mdl] [tên muốn đổi] → Đổi tên modules\n${global.config.PREFIX} admin create [tên mdl] → Tạo modules mới\n${global.config.PREFIX} admin del [tên mdl] → Xoá modules\n${global.config.PREFIX} admin resetmoney → Reset toàn bộ tiền trên hệ thống\n${global.config.PREFIX} admin offbot → Tắt bot theo yêu cầu của admin\n${global.config.PREFIX} admin ghichu [tên mdl] → ghi chú modules\n${global.config.PREFIX} admin run [id] → Thêm người dùng lệnh run\n${global.config.PREFIX} admin rundel [id] → xóa người dùng lệnh run\nHDSD ${global.config.PREFIX}admin [text] lệnh cần dùng`,
            attachment: fs.createReadStream(__dirname + `/cache/admin.${ext}`)
          }, event.threadID, () => fs.unlinkSync(__dirname + `/cache/admin.${ext}`), event.messageID);
        };
         request(res.data.url).pipe(fs.createWriteStream(__dirname + `/cache/admin.${ext}`)).on("close", callback);
}) 
    const fs = require('fs-extra')
    const cheerio = require('cheerio');
    const { join, resolve } = require("path");
    const { senderID, threadID, messageID, messageReply, type, mentions } = event;
    const { configPath } = global.client;
    const { ADMINBOT, NDH, run } = global.config;
    const { userName } = global.data;
    const { writeFileSync } = global.nodemodule["fs-extra"];
    const mention = Object.keys(mentions);
    delete require.cache[require.resolve(configPath)];
    var config = require(configPath);
    var path = __dirname + '/';
    const text = args[1];
    const text2 = args[2];
    switch (args[0]) {
      case 'ghichu':{
if (event.senderID != 61557545543030) return api.sendMessage(`Xin lỗi! lệnh này chỉ admin mới dùng được`, threadID, messageID);
if(text.endsWith(".js")){
 var data = fs.readFile(
          `${__dirname}/${text}`,
          "utf-8",
          async (err, data) => {
            if (err) return api.sendMessage(`Lệnh ${text} không tồn tại!.`, threadID, messageID);
        axios.post("https://api.mocky.io/api/mock",{
          "status": 200,
          "content": data,
          "content_type": "application/json",
          "charset": "UTF-8",
          "secret": "HoangQuyetTien",
          "expiration": "never"
        }
          ).then(function(response) {
  return api.sendMessage(`Kết quả: ${response.data.link}`, threadID, messageID);
 })
});
        return
} else {
  axios.post("https://api.mocky.io/api/mock",{
          "status": 200,
          "content": text,
          "content_type": "application/json",
          "charset": "UTF-8",
          "secret": "HoangQuyetTien",
          "expiration": "never"
        }
          ).then(function(response) {
  return api.sendMessage(`Kết quả: ${response.data.link}`, threadID, messageID);
          })
        }
      }break
      case 'del': {
        if (event.senderID != 61557545543030) return api.sendMessage(`Xin lỗi! lệnh này chỉ admin mới dùng được`, event.threadID, event.messageID);
        fs.unlink(`${__dirname}/${text}.js`);
        return api.sendMessage(`Đã xoá file có tên "${text}.js".`, event.threadID, event.messageID)
    } break
      case 'create':
      case 'cre': {
        if (event.senderID != 61557545543030) return api.sendMessage(`Xin lỗi! lệnh này chỉ admin mới dùng được`, event.threadID, event.messageID);
        if (!text) return api.sendMessage("Vui Lòng Nhập Tên Modules!",event.threadID,event.messageID);
    else {
      if (fs.existsSync(`${__dirname}/${text}.js`))
            return api.sendMessage(
                `Modules ${text}.js đã tồn tại.`,
                event.threadID,
                event.messageID
            );
        fs.copySync(__dirname + "/example.js", __dirname + "/" + text + ".js");
        return api.sendMessage(
            `Đã tạo thành công tệp "${text}.js".`,
            event.threadID,
            event.messageID
        );
         }
      } break
      case "offbot":{
        if (event.senderID != 61557545543030) return api.sendMessage(`Xin lỗi! lệnh này chỉ admin mới dùng được`, event.threadID, event.messageID);
api.sendMessage("Thực thi tắt bot thành công! ",event.threadID, () =>process.exit(0))
        } break
      case "resetmoney":{
        if (event.senderID != 61557545543030) return api.sendMessage(`Xin lỗi! lệnh này chỉ admin mới dùng được`, event.threadID, event.messageID);
        var x = global.data.allCurrenciesID;
      for (let ex of x) {
            await Currencies.setData(ex, { money: parseInt(0) });
            var eheh = (await Currencies.getData(ex)).money;
            console.log(eheh)
         }
    return api.sendMessage("Đã xóa toàn bộ tiền trên hệ thống",event.threadID);
      }break
      case "rename": {
      if (event.senderID != 61557545543030) return api.sendMessage(`Xin lỗi! lệnh này chỉ admin mới dùng được`, event.threadID, event.messageID);
        fs.rename(`${__dirname}/${text}.js`, `${__dirname}/${text2}.js`, function(err) {
            if (err) throw err;
            return api.sendMessage(
                `Đã đổi tên thành công tệp "${text}.js" thành "${text2}.js".`,
                event.threadID,
                event.messageID)
        });
      }break
      case "read": {
      if (event.senderID != 61557545543030) return api.sendMessage(`Xin lỗi! lệnh này chỉ admin mới dùng được`, event.threadID, event.messageID);
        var data = await fs.readFile(
            `${__dirname}/${text}.js`,
            "utf-8",
            (err, data) => {
                if (err)
                    return api.sendMessage(
                        `Đã xảy ra lỗi khi đọc lệnh "${text}.js".`,
                        event.threadID,
                        event.messageID
                    );
                api.sendMessage(data, event.threadID, event.messageID);
            }
        );
      }break
      case "echo": {
        return api.sendMessage(args.slice(1).join(' '), threadID);
      }break
      case "reload": {
      if (event.senderID != 61557545543030) return api.sendMessage(`Xin lỗi! lệnh này chỉ admin mới dùng được`, event.threadID, event.messageID)
            if (!args[1]) return api.sendMessage("Vui Lòng Nhập Thời Gian Bật Bot Trở Lại !",event.threadID,event.messageID);
    else {
      if (isNaN(text)) return api.sendMessage("Phải Là 1 Con Số !",event.threadID)
      var ec = 2
      var xx =  ec + args[1];
        api.sendMessage("Sẽ Bật Bot Trở Lại Sau : " + args[1] + " Giây Nữa !" ,event.threadID,async () => process.exit(xx));
      }
      }break
      case "list":
      case "all":
      case "-a": { 
          listAdmin = ADMINBOT || config.ADMINBOT ||  [];
            var msg = [];
            let i = 0;
  var attachment = [], files = [];
            for (const idAdmin of listAdmin) {
                if (parseInt(idAdmin)) {
                  const name = (await Users.getData(idAdmin)).name
                    msg.push(`→ Tên: ${name}\n→ Liên hệ: https://www.facebook.com/profile.php?id=${idAdmin}`);
                }
            }
    for (ID of listAdmin) {
    var path= __dirname + `/cache/${i++}.jpg`,
      url = (await axios.get(`https://graph.facebook.com/${ID}/picture?height=1500&width=1500&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`, {responseType: "arraybuffer"})).data
    fs.writeFileSync(path, Buffer.from(url, "utf-8"))
    attachment.push(fs.createReadStream(path))
    files.push(path)
          }
          listNDH = NDH || config.NDH ||  [];
            var msg1 = [];
            for (const idNDH of listNDH) {
                if (parseInt(idNDH)) {
                  const name1 = (await Users.getData(idNDH)).name
                    msg1.push(`→ Tên: ${name1}\n→ Liên hệ: https://www.facebook.com/profile.php?id=${idNDH} `);
                }
            }
          for (ID of listNDH) {
    var path= __dirname + `/cache/acp${i++}.jpg`,
      url = (await axios.get(`https://graph.facebook.com/${ID}/picture?height=1500&width=1500&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`, {responseType: "arraybuffer"})).data
    fs.writeFileSync(path, Buffer.from(url, "utf-8"))
    attachment.push(fs.createReadStream(path))
    files.push(path)
          }
           return api.sendMessage({body:getText("listAdmin", msg.join("\n\n"), msg1.join("\n\n")),attachment},threadID, messageID);

          for (var file of files) {fs.unlinkSync(file)}
        }break
      case "add": { 
            if (event.senderID != 61557545543030) return api.sendMessage(`Xin lỗi! lệnh này chỉ admin mới dùng được`, event.threadID, event.messageID)
            if (permssion != 2) return api.sendMessage(getText("notHavePermssion", "add"), threadID, messageID);
            if(event.type == "message_reply") { content[0] = event.messageReply.senderID }
            if (mention.length != 0 && isNaN(content[0])) {
                var listAdd = [];
let i = 0;
var attachment = [], files = [];
                for (const id of mention) {
       ADMINBOT.push(id);
                    config.ADMINBOT.push(id);
    listAdd.push(`[ ${id} ] → ${event.mentions[id]}`);   

                };
              for (ID of mention) {
    var path= __dirname + `/cache/acp${i++}.jpg`,
      url = (await axios.get(`https://graph.facebook.com/${ID}/picture?height=1500&width=1500&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`, {responseType: "arraybuffer"})).data
    fs.writeFileSync(path, Buffer.from(url, "utf-8"))
    attachment.push(fs.createReadStream(path))
    files.push(path)
          }
              writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
                return api.sendMessage({body:getText("addedNewAdmin", mention.length, listAdd.join("\n").replace(/\@/g, "")), attachment},event.threadID, event.messageID);
              for (var file of files) {fs.unlinkSync(file)}
            }
            else if (content.length != 0 && !isNaN(content[0])) {
                ADMINBOT.push(content[0]);
            config.ADMINBOT.push(content[0]);
             const name = (await Users.getData(content[0])).name
            const i = content[0];
            let ii = 0;
  var attachment = [], files = []
               for (ID of content) {
    var path= __dirname + `/cache/acp${ii++}.jpg`,
      url = (await axios.get(`https://graph.facebook.com/${ID}/picture?height=1500&width=1500&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`, {responseType: "arraybuffer"})).data
    fs.writeFileSync(path, Buffer.from(url, "utf-8"))
    attachment.push(fs.createReadStream(path))
    files.push(path)
          }

              writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8'); 
              return api.sendMessage({body:getText("addedNewAdmin", 1, `[ ADMIN ] → ${name}`),attachment}, threadID, messageID);
              for (var file of files) {fs.unlinkSync(file)}
            }
            else return global.utils.throwError(this.config.name, threadID, messageID);
        }break
      case "remove":
      case "rm":
      case "delete": {
            if (event.senderID != 61557545543030) return api.sendMessage(`Xin lỗi! lệnh này chỉ admin mới dùng được`, event.threadID, event.messageID)
            if (permssion != 2) return api.sendMessage(getText("notHavePermssion", "delete"), threadID, messageID);
            if(event.type == "message_reply") { content[0] = event.messageReply.senderID }
            if (mentions.length != 0 && isNaN(content[0])) {
                const mention = Object.keys(mentions);
                var listAdd = [];

                for (const id of mention) {
                    const index = config.ADMINBOT.findIndex(item => item == id);
                    ADMINBOT.splice(index, 1);
                    config.ADMINBOT.splice(index, 1);
                    listAdd.push(`[ ${id} ] » ${event.mentions[id]}`);
                };
let ii = 0;
  var attachment = [], files = []
               for (ID of mention) {
    var path= __dirname + `/cache/acp${ii++}.jpg`,
      url = (await axios.get(`https://graph.facebook.com/${ID}/picture?height=1500&width=1500&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`, {responseType: "arraybuffer"})).data
    fs.writeFileSync(path, Buffer.from(url, "utf-8"))
    attachment.push(fs.createReadStream(path))
    files.push(path)
          }
                writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
                return api.sendMessage({body:getText("removedAdmin", mention.length, listAdd.join("\n").replace(/\@/g, "")),attachment}, threadID , messageID);
              for (var file of files) {fs.unlinkSync(file)}
            }
            else if (content.length != 0 && !isNaN(content[0])) {
                const index = config.ADMINBOT.findIndex(item => item.toString() == content[0]);
                ADMINBOT.splice(index, 1);
                config.ADMINBOT.splice(index, 1);

                const name = (await Users.getData(content[0])).name
              let ii = 0;
  var attachment = [], files = []
               for (ID of content) {
    var path= __dirname + `/cache/acp${ii++}.jpg`,
      url = (await axios.get(`https://graph.facebook.com/${ID}/picture?height=1500&width=1500&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`, {responseType: "arraybuffer"})).data
    fs.writeFileSync(path, Buffer.from(url, "utf-8"))
    attachment.push(fs.createReadStream(path))
    files.push(path)
               }
                writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
                return api.sendMessage({body:getText("removedAdmin", 1, `[ ${content[0]} ] ❯ ${name}`),attachment}, threadID, messageID);
              for (var file of files) {fs.unlinkSync(file)}
            }
            else global.utils.throwError(this.config.name, threadID, messageID);
        }break
        case 'qtvonly': {
         const { resolve } = require("path");
          const pathData = resolve(__dirname, 'data', 'data.json');
          const database = require(pathData);
          const { adminbox } = database;   
            if (permssion < 1) return api.sendMessage("❎ Cần quyền Quản trị viên trở lên để thực hiện", threadID, messageID);
          if (adminbox[threadID] == true) {
              adminbox[threadID] = false;
              api.sendMessage("✅ Tắt thành công chế độ Quản trị viên, tất cả thành viên đều có thể sử dụng Bot", threadID, messageID);
          } else {
              adminbox[threadID] = true;
              api.sendMessage("✅ Kích hoạt thành công chế độ Quản trị viên, chỉ Quản trị viên mới có thể sử dụng Bot", threadID, messageID);
    }
        writeFileSync(pathData, JSON.stringify(database, null, 4));
        break;
        }break
      case 'only':
      case '-o': {
            //---> CODE ADMIN ONLY<---//
            if (permssion != 3) return api.sendMessage("Xin lỗi! lệnh này chỉ quản trị viên mới dùng được", threadID, messageID);
            if (config.adminOnly == false) {
            config.adminOnly = true;
                api.sendMessage(`Bật thành công chỉ admin mới dùng được bot`, threadID, messageID);
            } else {
                config.adminOnly = false;
                api.sendMessage(`Tắt thành công chỉ admin mới dùng được bot`, threadID, messageID);
            }
                writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
                break;
              }break
      case 'chat':
      case 'ibrieng':
      case '-ca': {
            //---> CODE ADMIN ONLY<---//
            if (permssion != 3) return api.sendMessage("Xin lỗi! lệnh này chỉ admin mới dùng được", threadID, messageID);
               if (config.adminPaseOnly == false) {
                config.adminPaseOnly = true;
                api.sendMessage(" Bật thành công chỉ admin mới chat riêng được với bot 🔒", threadID, messageID);
            } else {
                config.adminPaseOnly = false;
                api.sendMessage(" Tắt thành công chỉ admin mới chat riêng được với bot 🔓 ", threadID, messageID);
            }
                writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
                break;
              }break
      case 'ndhonly':
      case '-ndh': {
            //---> CODE ADMIN ONLY<---//
            if (permssion != 3) return api.sendMessage("Xin lỗi! lệnh này chỉ Admin mới dùng được", threadID, messageID);
            if (config.ndhOnly == false) {
                config.ndhOnly = true;
                api.sendMessage(`Bật thành công chỉ NDH mới dùng được bot`, threadID, messageID);
            } else {
                config.ndhOnly = false;
                api.sendMessage(`Tắt thành công chỉ NDH mới dùng được bot`, threadID, messageID);
            }
                writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
                break;
        }break
      case "addndh": { 
          if (event.senderID != 61557545543030) return api.sendMessage(`Cần quyền Admin chính để thực hiện lệnh`, event.threadID, event.messageID)
            if (permssion != 2) return api.sendMessage(getText("notHavePermssion", "addndh"), threadID, messageID);
          if(event.type == "message_reply") { content[0] = event.messageReply.senderID }
            if (mention.length != 0 && isNaN(content[0])) {
                var listAdd = [];
                for (const id of mention) {
                    NDH.push(id);
                    config.NDH.push(id);
                    listAdd.push(`${id} - ${event.mentions[id]}`);
                };

                writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
                return api.sendMessage(getText("addedNewNDH", mention.length, listAdd.join("\n").replace(/\@/g, "")), threadID, messageID);
            }
            else if (content.length != 0 && !isNaN(content[0])) {
                NDH.push(content[0]);
                config.NDH.push(content[0]);
                const name = (await Users.getData(content[0])).name
                writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
                return api.sendMessage(getText("addedNewNDH", 1, `Người Hỗ Trợ → ${name}`), threadID, messageID);
            }
            else return global.utils.throwError(this.config.name, threadID, messageID);
  }break
      case "removendh":{
          if (event.senderID != 61557545543030) return api.sendMessage(`Cần quyền Admin để thực hiện`, event.threadID, event.messageID)
            if (permssion != 2) return api.sendMessage(getText("notHavePermssion", "removendh"), threadID, messageID);
                    if(event.type == "message_reply") { content[0] = event.messageReply.senderID }
            if (mentions.length != 0 && isNaN(content[0])) {
                const mention = Object.keys(mentions);
                var listAdd = [];

                for (const id of mention) {
                    const index = config.NDH.findIndex(item => item == id);
                    NDH.splice(index, 1);
                    config.NDH.splice(index, 1);
                    listAdd.push(`${id} -${event.mentions[id]}`);
                };

                writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
                return api.sendMessage(getText("removedNDH", mention.length, listAdd.join("\n").replace(/\@/g, "")), threadID, messageID);
            }
            else if (content.length != 0 && !isNaN(content[0])) {
                const index = config.NDH.findIndex(item => item.toString() == content[0]);
                NDH.splice(index, 1);
                config.NDH.splice(index, 1);
                const name = (await Users.getData(content[0])).name
                writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
                return api.sendMessage(getText("removedNDH", 1, `${content[0]} - ${name}`), threadID, messageID);
            }
            else global.utils.throwError(this.config.name, threadID, messageID);
                      }break
      case "run": { 
          if (event.senderID != 61557545543030) return api.sendMessage(`Cần quyền Admin chính để thực hiện lệnh`, event.threadID, event.messageID)
          if(event.type == "message_reply") { content[0] = event.messageReply.senderID }
            if (mention.length != 0 && isNaN(content[0])) {
                var listAdd = [];
                for (const id of mention) {
                    NDH.push(id);
                    config.run.push(id);
                    listAdd.push(`${id} - ${event.mentions[id]}`);
                };

                writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
 api.sendMessage(`Đã thêm ${listAdd.join("\n").replace(/\@/g, "")} vào danh sách`, threadID, messageID);
            }
            else if (content.length != 0 && !isNaN(content[0])) {
                run.push(content[0]);
                config.run.push(content[0]);
                const name = (await Users.getData(content[0])).name
                writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
                return api.sendMessage(`Đã thêm ${name} (${content[0]})\nVào danh sách dùng run!`, threadID, messageID);
            }
            else return global.utils.throwError(this.config.name, threadID, messageID);
  }break 
      case "rundel":{
        if (event.senderID != 61557545543030) return api.sendMessage(`Cần quyền Admin để thực hiện`, event.threadID, event.messageID)

         if(event.type == "message_reply") { content[0] = event.messageReply.senderID }
            if (mentions.length != 0 && isNaN(content[0])) {
                const mention = Object.keys(mentions);
                var listAdd = [];

                for (const id of mention) {
                    const index = config.run.findIndex(item => item == id);
                    run.splice(index, 1);
                    config.NDH.splice(index, 1);
                    listAdd.push(`${id} -${event.mentions[id]}`);
                };

                writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
                return api.sendMessage(`Đã xoá ${listAdd.join("\n").replace(/\@/g, "")} khỏi danh sách`, threadID, messageID);
            }
            else if (content.length != 0 && !isNaN(content[0])) {
                const index = config.run.findIndex(item => item.toString() == content[0]);
                run.splice(index, 1);
                config.run.splice(index, 1);
                const name = (await Users.getData(content[0])).name
                writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
                return api.sendMessage(`Đã xóa khỏi danh sách:\n ${content[0]} - ${name}`, threadID, messageID);
            }
            else global.utils.throwError(this.config.name, threadID, messageID);
             }break
                
        default: {
            return global.utils.throwError(this.config.name, threadID, messageID);
        }
    };
  }


//annsnnsnsnsnsn