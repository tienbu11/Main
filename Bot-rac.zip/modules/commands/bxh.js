const fs = require('fs');
const path = require('path');

module.exports.config = {
    name: "bxh",
    version: "1.0.0",
    hasPermssion: 0,
    usePrefix: false,
    credits: "Mây Trắng",
    description: "Xem bảng xếp hạng đại gia",
    commandCategory: "Thông tin",
    usages: "@bxh",
    cooldowns: 5
};

const dataPath = path.join(__dirname, 'data', 'data.json');

function formatCurrency(int) {
    return int.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
}

module.exports.run = async function ({ event, api }) {
    const { threadID, messageID } = event;
    const { sendMessage } = api;


    let data;
    try {
        data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (error) {
        return sendMessage("Không thể đọc dữ liệu người dùng.", threadID, messageID);
    }


    const sortedUsers = data.sort((a, b) => b.balance - a.balance);


    let leaderboard = "Bảng Xếp Hạng Đại Gia\n\n";
    sortedUsers.slice(0, 11).forEach((user, index) => {
        leaderboard += `${index + 1}. ${user.full_name} - ${formatCurrency(user.balance)} VNĐ\n`;
    });

    sendMessage(leaderboard, threadID, messageID);
};