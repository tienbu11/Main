const urls = require('./../../anh/girl.json');
const { streamURL } = global.utils;

class Command {
  constructor(config) {
    this.config = config;
    this.queues = [];
  }

  async onLoad(o) {
    let status = false;
    if (!global.client.xx) {
      global.client.xx = setInterval(async () => {
        if (status || this.queues.length > 5) return;
        status = true;

        try {
          const uploads = await Promise.all([...Array(5)].map(() => this.upload(o)));
          this.queues.push(...uploads);
        } catch (error) {
          console.error('Error during upload:', error);
        } finally {
          status = false;
        }
      }, 1000 * 5);
    }
  }

  async upload(o) {
    const { api } = o;
    const url = urls[Math.floor(Math.random() * urls.length)];

    try {
      const response = await api.postFormData('https://upload.facebook.com/ajax/mercury/upload.php', {
        upload_1024: await getStreamFromURL(url)
      });

      const metadata = JSON.parse(response.body.replace('for (;;);', '')).payload?.metadata?.[0] || {};
      return Object.entries(metadata)[0];
    } catch (error) {
      console.error('Error during upload:', error);
      return null;
    }
  }

  async run(o) {
    const send = (msg) => new Promise((resolve) => o.api.sendMessage(msg, o.event.threadID, (err, res) => resolve(res || err), o.event.messageID));

    try {
      const t = process.uptime(), h = Math.floor(t / (60 * 60)), p = Math.floor((t % (60 * 60)) / 60), s = Math.floor(t % 60);
      await send({ body: '『 Chưa Nhập Tên Lệnh 』\n                ' + `${h}:${p}:${s}\n\n`, attachment: this.queues.splice(0, 1) });
    } catch (error) {
      console.error('Error during sending:', error);
    }
  }
}

module.exports = new Command({
  name: '\n',
  version: '0.0.1',
  usePrefix: false,
  hasPermssion: 0,
  credits: 'DC-Nam',
  description: '',
  commandCategory: 'Tiện Ích',
  usages: '[]',
  cooldowns: 0,
});