const fs = require('fs');
const path = require('path');

module.exports.config = {
    name: "taoacctx",
    version: "1.0.0",
    hasPermssion: 0,
    usePrefix: false,
    credits: "Mây Trắng",
    description: "Đăng ký người dùng để chơi Tài Xỉu",
    commandCategory: "Trò Chơi",
    usages: "@dangkytx",
    cooldowns: 5
};

const dataPath = path.join(__dirname, 'data', 'data.json');

module.exports.run = async function ({ event, api, Users }) {
    const { threadID, messageID, senderID } = event;
    const { sendMessage } = api;

    
    const name = await Users.getNameUser(senderID);

    
    let data;
    try {
        data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (error) {
        data = [];
    }

    
    const userExists = data.some(user => user.user_id === senderID);
    if (userExists) {
        return sendMessage("Bạn đã đăng ký trước đó.", threadID, messageID);
    }

    
    const newUser = {
        user_id: senderID,
        full_name: name,
        balance: 6000000 
    };
    data.push(newUser);

    
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

    
    sendMessage("Đăng ký thành công!", threadID, messageID);
};