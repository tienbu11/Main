const axios = require("axios");
const fs = require("fs");
const gtts = require("gtts");

module.exports.config = {
  name: "bardv2",
  version: "1.1",
  usePrefix: true,
  hasPermission: 0,
  credits: "tienBu",
  description: "Bard ai",
  usePrefix: false,
  commandCategory: "AI",
  usages: "tên lênh + câu hỏi",
  cooldowns: 5,
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID, type, messageReply, body } = event;

  let question = "";

  if (type === "message_reply" && messageReply.attachments[0]?.type === "photo") {
    const attachment = messageReply.attachments[0];
    const imageURL = attachment.url;
    question = await convertImageToText(imageURL);

    if (!question) {
      api.sendMessage(
        "❌ Failed to convert the photo to text. Please try again with a clearer photo.",
        threadID,
        messageID
      );
      return;
    }
  } else {
    question = body.slice(5).trim();

    if (!question) {
      api.sendMessage("Please provide a question or query", threadID, messageID);
      return;
    }
  }

  api.sendMessage("Đang tìm kiếm câu trả lời, vui lòng chờ...", threadID, messageID);

  try {
    const res = await axios.get(
      `https://project-bard.onrender.com/api/bard?q=${encodeURIComponent(question)}&uid=${uid}`
    );

    const respond = res.data.message;
    const formattedAnswer = `${respond}`;

    const gttsPath = 'voice.mp3';
    const gttsInstance = new gtts(formattedAnswer, 'vi');
    gttsInstance.save(gttsPath, function (error, result) {
      if (error) {
        console.error("Lỗi lưu gTTS:", error);
        api.sendMessage("❌ Lỗi tạo phản hồi bằng giọng nói.", threadID, messageID);
      } else {
        const textAnswer = `${respond}`;
        const voiceAnswer = `${respond}`;
        
        api.sendMessage(textAnswer, threadID, (error, messageInfo) => {
          if (!error) {
            api.sendMessage({
              body: voiceAnswer,
              attachment: fs.createReadStream(gttsPath)
            }, threadID);
          }
        });
      }
    });
  } catch (error) {
    console.error(error);
    api.sendMessage("❌ Đã xảy ra lỗi khi tìm nạp dữ liệu.", threadID, messageID);
  }
};

async function convertImageToText(imageURL) {
  const response = await axios.get(
    `https://bard-ai.arjhilbard.repl.co/api/other/img2text?input=${encodeURIComponent(imageURL)}`
  );
  return response.data.extractedText;
}
