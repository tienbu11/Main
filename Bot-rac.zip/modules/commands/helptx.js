module.exports.config = {
  name: "helptx",
  version: "1.0.0",
  hasPermssion: 0,
  usePrefix: false,
  credits: "Mây Trắng",
  description: "Hiển thị danh sách các lệnh có sẵn",
  commandCategory: "Hỗ trợ",
  usages: "@helptx",
  cooldowns: 5
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID } = event;
  const { sendMessage } = api;

  const helpMessage = `
Các Lệnh Có Sẵn:
–bxh - Bảng Xếp Hạng Đại Gia

–dangkytx - Đăng Kí Tài Khoản

–taixiu - Game Tài xỉu @taixiu xem cách chơi

–chanle - Game Chẵn Lẻ @chanle xem cách chơi

–phitieu - Game Ném phi tiêu phitieu xem cách chơi

–bowling - Game Ném bowling @bowling xem cách chơi

–xemhu - Xem tiền trong hũ tài xỉu

–profile - Xem Thông Tin Tài Khoản

–giftcode - Nhập Giftcode

–listcode - Liệt Kê Tất Cả Giftcodes

–chuyentien - Chuyển Tiền Cho Người Khác

–@money - Replly Xem Tiền Người Khác

Lệnh Của Admin:
–setmoney - Cộng Tiền - Trừ Tiền Cho Người Dùng

–taogiftcode - Tạo Giftcode Mới  

–txauto - Mở Phiên Tài Xỉu Trong 60s

–stop - Tắt Phiên Tài Xỉu
`;

  sendMessage(helpMessage, threadID, messageID);
};