const fs = require('fs');
const path = require('path');

module.exports.config = {
		name: "money",
		version: "1.0.0",
		hasPermssion: 0,
	usePrefix: false,
		credits: "Mây Trắng",
		description: "Xem tiền của người dùng",
		commandCategory: "Tài chính",
		usages: "Replly Tin Nhắn @money",
		cooldowns: 5
};

const dataPath = path.join(__dirname, 'data', 'data.json');

module.exports.run = async function ({ api, event, Users }) {
		const { threadID, messageID, senderID, messageReply } = event;
		const { sendMessage } = api;

		if (!messageReply || !messageReply.senderID) {
				return sendMessage("Vui lòng trả lời tin nhắn của người bạn muốn xem tiền.", threadID, messageID);
		}

		const targetID = messageReply.senderID;


		let data;
		try {
				data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
		} catch (error) {
				return sendMessage("Chưa Đăng Ký @dangkytx để đăng ký", threadID, messageID);
		}


		const user = data.find(user => user.user_id === targetID);
		if (!user) return sendMessage("Chưa Đăng Ký @dangkytx để đăng ký", threadID, messageID);

		const targetName = user.full_name;
		const balance = user.balance.toLocaleString();

		sendMessage(`Số dư của ${targetName} là ${balance} VNĐ`, threadID, messageID);
};