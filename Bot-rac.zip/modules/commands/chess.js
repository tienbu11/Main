const readline = require('readline');
exports.config = {
    name: 'chess',
    version: '0.0.1',
    hasPermssion: 0,
    credits: 'bu',
    description: 'tag người muốn chơi cùng',
    commandCategory: 'Game',
    usages: '[]',
    cooldowns: 3
};
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const chessBoard = Array(8).fill(null).map(() => Array(8).fill(' '));

function printBoard() {
  console.log('   a b c d e f g h');
  console.log('  +----------------');
  for (let i = 0; i < 8; i++) {
    console.log(`${8 - i}| ${chessBoard[i].join(' ')}`);
  }
  console.log('  +----------------');
}

function isValidMove(start, end) {
  // Add your logic to check if the move is valid
  return true;
}

function makeMove(start, end) {
  // Add your logic to update the chess board
  chessBoard[end[0]][end[1]] = chessBoard[start[0]][start[1]];
  chessBoard[start[0]][start[1]] = ' ';
}

function playGame() {
  printBoard();

  function promptMove(player) {
    rl.question(`${player}'s turn. Enter your move (e.g., 'a2 a4'): `, (move) => {
      const [start, end] = move.split(' ').map(coord => [8 - parseInt(coord[1]), coord.charCodeAt(0) - 97]);

      if (isValidMove(start, end)) {
        makeMove(start, end);
        printBoard();
        promptMove(player === 'Player 1' ? 'Player 2' : 'Player 1');
      } else {
        console.log('Invalid move. Try again.');
        promptMove(player);
      }
    });
  }

  promptMove('Player 1');
}

playGame();