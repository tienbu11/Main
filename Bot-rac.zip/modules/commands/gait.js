module.exports.config = {
	name: "gái",
	version: "1.0.0",
	hasPermssion: 0,
	credits: "tq.info",
	description: "RanDom Video Gái",
	commandCategory: "no prefix",
	usages: "Gái",
	cooldowns: 0,
	denpendencies: {
		"fs-extra": "",
		"request": ""
		
  }
};
module.exports.handleEvent = async ({ api, event, Threads }) => {
  if (event.body.indexOf("tiktok")==0 ||
event.body.indexOf("girl")==0 ) 
//Thay (tên gọi)theo sở thích
//[ Lưu ý !! Không được để trống ( Tên gọi ) 
//Hoặc có thể xoá bớt [event.body.indexOf(")==0 ]
{
    const axios = global.nodemodule["axios"];
const request = global.nodemodule["request"];
const fs = global.nodemodule["fs-extra"];
    var link = [ 
      "https://i.imgur.com/g30TrDi.mp4",
"https://i.imgur.com/T3ZNpN1.mp4",
"https://i.imgur.com/6iasuYd.mp4",
"https://i.imgur.com/VWeHh0X.mp4",
"https://i.imgur.com/7zUlEth.mp4",
"https://i.imgur.com/3AdgWNO.mp4",
"https://i.imgur.com/LkX9wJG.mp4",
"https://i.imgur.com/jyXYG4q.mp4",
"https://i.imgur.com/x6QR6zn.mp4",
"https://i.imgur.com/sjNkyNU.mp4",
"https://i.imgur.com/moveAR6.mp4",
"https://i.imgur.com/TPbWTzS.mp4",
"https://i.imgur.com/Xbp1tQP.mp4",
"https://i.imgur.com/tgw5uwB.mp4",
"https://i.imgur.com/JZeUXZc.mp4",
"https://i.imgur.com/gdyGpMY.mp4",
"https://i.imgur.com/u1GlQB3.mp4",
"https://i.imgur.com/YlkEXKV.mp4",
"https://i.imgur.com/pruI2XL.mp4",
"https://i.imgur.com/THY3LaL.mp4",
"https://i.imgur.com/A0jikXQ.mp4",
"https://i.imgur.com/9RZ0y9V.mp4",
"https://i.imgur.com/6d3uPwf.mp4",
"https://i.imgur.com/HTqJmsM.mp4",
"https://i.imgur.com/bvL5KbN.mp4",
"https://i.imgur.com/q4wwiU8.mp4",
"https://i.imgur.com/gJRkh8G.mp4"

           ];
     var callback = () => api.sendMessage({body:` `
,attachment: fs.createReadStream(__dirname + "/cache/1.mp4")}, event.threadID, () => fs.unlinkSync(__dirname + "/cache/1.mp4"), );  
      return request(encodeURI(link[Math.floor(Math.random() * link.length)])).pipe(fs.createWriteStream(__dirname+"/cache/1.mp4")).on("close",() => callback());
}
                                                                                                         }
module.exports.run = async({api,event,args,Users,Threads,Currencies}) => {

   };
