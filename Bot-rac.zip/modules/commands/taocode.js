const fs = require('fs');
const path = require('path');

module.exports.config = {
    name: "taocode",
    version: "1.0.0",
    hasPermssion: 2,
    usePrefix: false,
    credits: "Mây Trắng",
    description: "Tạo giftcode",
    commandCategory: "Admin",
    usages: "[giftcode] [số tiền] [số lượt dùng]",
    cooldowns: 5
};

const giftcodePath = path.join(__dirname, 'data', 'giftcode.json');

module.exports.run = async function ({ event, api, args }) {
    const { threadID, messageID } = event;
    const { sendMessage } = api;

    if (args.length !== 3 || isNaN(parseInt(args[1])) || isNaN(parseInt(args[2]))) {
        return sendMessage("Sai cú pháp. Vui lòng nhập đúng cú pháp: /taogiftcode [giftcode] [số tiền] [số lượt dùng]", threadID, messageID);
    }

    const giftcode = args[0];
    const amount = parseInt(args[1]);
    const uses = parseInt(args[2]);

    
    let giftcodes;
    try {
        giftcodes = JSON.parse(fs.readFileSync(giftcodePath, 'utf8'));
    } catch (error) {
        giftcodes = {};
    }

    
    giftcodes[giftcode] = { amount, uses };

    
    fs.writeFileSync(giftcodePath, JSON.stringify(giftcodes, null, 2));

    sendMessage(`Đã tạo giftcode ${giftcode} với số tiền ${amount} VNĐ và ${uses} lượt dùng.`, threadID, messageID);
};