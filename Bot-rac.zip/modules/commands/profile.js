const fs = require('fs');
const path = require('path');

module.exports.config = {
    name: "profile",
    version: "1.0.0",
    hasPermssion: 0,
    usePrefix: false,
    credits: "Mây Trắng",
    description: "Xem thông tin cá nhân của người dùng",
    commandCategory: "Thông tin",
    usages: "@profile",
    cooldowns: 5
};

const dataPath = path.join(__dirname, 'data', 'data.json');

function formatCurrency(int) {
    return int.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
}

module.exports.run = async function ({ event, api }) {
    const { threadID, messageID, senderID } = event;
    const { sendMessage } = api;

    
    let data;
    try {
        data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (error) {
        return sendMessage("Không thể đọc dữ liệu người dùng.", threadID, messageID);
    }

    
    const user = data.find(user => user.user_id === senderID);
    if (!user) {
        return sendMessage("Bạn chưa đăng ký. @dangkytx để đăng ký", threadID, messageID);
    }

    
    const userInfo = `👤 User ID: ${user.user_id}\n`
                   + `🪪 Tên: ${user.full_name}\n`
                   + `💳 Số dư: ${formatCurrency(user.balance)} VNĐ`;

    sendMessage(userInfo, threadID, messageID);
};