const fs = require('fs');
const path = require('path');

module.exports.config = {
    name: "listcode",
    version: "1.0.0",
    hasPermssion: 0,
    usePrefix: false,
    credits: "Mây Trắng",
    description: "Xem danh sách các giftcode hiện có",
    commandCategory: "Tiện ích",
    usages: "@listcode",
    cooldowns: 5
};

const giftcodePath = path.join(__dirname, 'data', 'giftcode.json');

function formatCurrency(int) {
    return int.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
}

module.exports.run = async function ({ event, api }) {
    const { threadID, messageID } = event;
    const { sendMessage } = api;


    let giftcodes;
    try {
        giftcodes = JSON.parse(fs.readFileSync(giftcodePath, 'utf8'));
    } catch (error) {
        return sendMessage("Không thể đọc dữ liệu giftcode.", threadID, messageID);
    }


    let listCodeMessage = "Danh sách Giftcode\n\n";
    for (const code in giftcodes) {
        const amount = formatCurrency(giftcodes[code].amount);
        const uses = giftcodes[code].uses;
        listCodeMessage += `Code: ${code}, Số tiền: ${amount} VNĐ, Lượt dùng: ${uses}\n\n`;
    }

    sendMessage(listCodeMessage.trim(), threadID, messageID);
};