const fs = require('fs');
const path = require('path');
const axios = require('axios');

module.exports.config = {
    name: "txauto",
    version: "1.0.0",
    hasPermssion: 2,
    usePrefix: false,
    credits: "Mây Trắng",
    description: "Mở phiên Tài Xỉu tự động",
    commandCategory: "Trò Chơi",
    usages: "@mophienauto",
    cooldowns: 5
};

const dataPath = path.join(__dirname, 'data', 'data.json');
const statePath = path.join(__dirname, 'data', 'state.json');
const potPath = path.join(__dirname, 'data', 'pot.json');

const gifs = [
    "https://trangbel.x10.mx/gif/1.gif",
    "https://trangbel.x10.mx/gif/2.gif",
    "https://trangbel.x10.mx/gif/3.gif",
    "https://trangbel.x10.mx/gif/4.gif",
    "https://trangbel.x10.mx/gif/5.gif",
    "https://trangbel.x10.mx/gif/6.gif"
];

function readState() {
    try {
        return JSON.parse(fs.readFileSync(statePath, 'utf8'));
    } catch (error) {
        return { isSessionActive: false, bets: [], history: [] };
    }
}

function writeState(state) {
    fs.writeFileSync(statePath, JSON.stringify(state, null, 2));
}

function readPot() {
    try {
        return JSON.parse(fs.readFileSync(potPath, 'utf8'));
    } catch (error) {
        return { amount: 0 };
    }
}

function writePot(pot) {
    fs.writeFileSync(potPath, JSON.stringify(pot, null, 2));
}

function replace(int) {
    return int.toString().replace(/(.)(?=(\d{3})+$)/g, '$1,');
}

module.exports.run = function ({ api, event }) {
    const { threadID, messageID } = event;
    const { sendMessage } = api;
    let state = readState();
    let pot = readPot();

    if (state.isSessionActive) {
        return sendMessage("Phiên cược hiện đang diễn ra.", threadID, messageID);
    }

    state = { isSessionActive: true, bets: [], history: state.history };
    writeState(state);

    sendMessage(`Phiên đã được mở và bắt đầu nhận cược trong 60s\n\n[+] Cú pháp: tài [số tiền] hoặc xỉu [số tiền] hoặc all\n[+] Cược tối thiểu là 5,000 VNĐ, không cược 2 cửa trong cùng 1 phiên\n[+] Nổ hũ: Khi ba con xúc xắc có giá trị giống nhau sẽ nổ hũ.`, threadID);

    let timeLeft = 60;
    const countdownInterval = setInterval(() => {
        timeLeft -= 10;
        state = readState();
        pot = readPot(); 

        if (!state.isSessionActive) {
            clearInterval(countdownInterval);
            return;
        }
        if (timeLeft > 0) {
            const historyEmojis = state.history.map(result => result === "tài" ? "⚫️" : "⚪️").join('');
            sendMessage(`⏳ Chỉ còn ${timeLeft}s để đặt cược, bà con nhanh tay làm giàu đê !!!\n\n👥 Tổng người chơi: ${state.bets.length}\n⚫️ Theo Tài: ${state.bets.filter(bet => bet.choose === 'tài').length} người, tổng tiền: ${replace(state.bets.filter(bet => bet.choose === 'tài').reduce((a, b) => a + b.amount, 0))} VNĐ\n⚪️ Theo Xỉu: ${state.bets.filter(bet => bet.choose === 'xỉu').length} người, tổng tiền: ${replace(state.bets.filter(bet => bet.choose === 'xỉu').reduce((a, b) => a + b.amount, 0))} VNĐ\n💰Hũ: ${replace(pot.amount)} VNĐ\n\n${historyEmojis}`, threadID);
        } else {
            clearInterval(countdownInterval);
            finalizeSession(api, threadID);
        }
    }, 10000);

    setTimeout(() => {
        clearInterval(countdownInterval);
        finalizeSession(api, threadID);
    }, 60000);
};

async function finalizeSession(api, threadID) {
    let state = readState();
    let pot = readPot();

    if (!state.isSessionActive) return;

    if (state.bets.length === 0) {
        state.isSessionActive = false;
        writeState(state);
        return api.sendMessage("Không có ai cược trong phiên này. Phiên kết thúc.", threadID, () => {
            setTimeout(() => module.exports.run({ api, event: { threadID, messageID: null } }), 10000);
        });
    }

    const dice = [];
    for (let i = 0; i < 3; i++) {
        dice.push(Math.floor(Math.random() * 6) + 1);
    }

    const total = dice.reduce((a, b) => a + b, 0);
    const result = total >= 11 ? "tài" : "xỉu";
    const isJackpot = dice.every(val => val === dice[0]);
    const jackpotWinners = [];

    let data;
    try {
        data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (error) {
        return api.sendMessage("Không thể đọc dữ liệu người dùng.", threadID);
    }

    const winners = state.bets.filter(bet => bet.choose === result);
    const losers = state.bets.filter(bet => bet.choose !== result);

    if (isJackpot) {
        const winningAmount = pot.amount;
        winners.forEach(winner => {
            const user = data.find(u => u.user_id === winner.userID);
            if (user) {
                user.balance += winningAmount / winners.length;
                jackpotWinners.push(user.full_name);
            }
        });
        pot.amount = 0;
    } else {
        winners.forEach(winner => {
            const user = data.find(u => u.user_id === winner.userID);
            if (user) {
                user.balance += winner.amount * 1.8;
            }
        });
    }

    losers.forEach(loser => {
        const user = data.find(u => u.user_id === loser.userID);
        if (user) {
            user.balance -= loser.amount;
            pot.amount += loser.amount * 0.2; 
        }
    });

    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
    writePot(pot);

    state.history.push(result);
    if (state.history.length > 10) state.history.shift(); 
    writeState(state);

    api.sendMessage("Bắt đầu lắc xúc xắc...", threadID);

    setTimeout(async () => {
        const currentTime = new Date().toLocaleString("vi-VN", { timeZone: "Asia/Ho_Chi_Minh", hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit", day: "2-digit", month: "2-digit", year: "numeric" });
        const sessionID = Math.floor(Math.random() * 100000) + 1;

        const resultEmoji = result === "tài" ? "⚫️" : "⚪️";
        const historyEmojis = state.history.map(r => r === "tài" ? "⚫️" : "⚪️").join('');

        const msg = `PHIÊN: ${sessionID}\nSỐ NGƯỜI CHƠI: ${state.bets.length}\nTỔNG TIỀN CƯỢC: ${replace(state.bets.reduce((total, bet) => total + bet.amount, 0))} VNĐ\nKẾT QUẢ: ${dice.join("-")} | ${result.charAt(0).toUpperCase() + result.slice(1)} ${resultEmoji}\nTHỜI GIAN: ${currentTime}`;

        const gifAttachments = await Promise.all(dice.map(d => axios.get(gifs[d - 1], { responseType: 'stream' }).then(response => response.data)));

        api.sendMessage({ body: msg, attachment: gifAttachments }, threadID, (err, info) => {
            if (err) return console.error(err);

            setTimeout(() => {
                api.unsendMessage(info.messageID, (error) => {
                    if (error) console.error("Error unsending message:", error);
                });
            }, 8000);
        });

        if (isJackpot && jackpotWinners.length > 0) {
            const jackpotMessage = `🎉 Chúc mừng ${jackpotWinners.join(', ')} đã nổ hũ, toàn bộ số tiền trong hũ đã được chia đều!`;
            api.sendMessage(jackpotMessage, threadID);
        }

        setTimeout(() => {
            state.isSessionActive = false;
            writeState(state);
            module.exports.run({ api, event: { threadID, messageID: null } });
        }, 10000);
    }, 3000);
}

module.exports.handleEvent = function ({ api, event }) {
    const { threadID, messageID, body, senderID } = event;
    const { sendMessage } = api;
    let state = readState();

    if (!state.isSessionActive) return;

    let match = body.toLowerCase().match(/(tài|xỉu)\s+(all|\d+)/);
    if (!match) return;

    const [, choose, amountStr] = match;
    let betAmount;


    if (amountStr === "all") {
        let data;
        try {
            data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (error) {
            return sendMessage("Không thể đọc dữ liệu người dùng.", threadID, messageID);
        }

        const user = data.find(user => user.user_id === senderID);
        if (!user) {
            return sendMessage("Bạn chưa đăng ký. Vui lòng sử dụng lệnh @dangkytx để đăng ký.", threadID, messageID);
        }

        betAmount = user.balance; 
    } else {
        betAmount = parseInt(amountStr);
    }

    if (isNaN(betAmount) || betAmount < 5000) {
        return sendMessage("Cược tối thiểu là 5,000 VNĐ.", threadID, messageID);
    }

    let data;
    try {
        data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (error) {
        return sendMessage("Không thể đọc dữ liệu người dùng.", threadID, messageID);
    }

    const user = data.find(user => user.user_id === senderID);
    if (!user) {
        return sendMessage("Bạn chưa đăng ký. @dangkytx để đăng ký", threadID, messageID);
    }

    if (betAmount > user.balance) {
        return sendMessage("Bạn thiếu tiền không thể cược.", threadID, messageID);
    }

    const existingBet = state.bets.find(bet => bet.userID === senderID);
    if (existingBet) {
        return sendMessage("Bạn không thể cược 2 cửa trong cùng 1 phiên.", threadID, messageID);
    }

    state.bets.push({ userID: senderID, name: user.full_name, choose, amount: betAmount });
    writeState(state);
    sendMessage({ body: `Đã ghi nhận cược: ${choose.charAt(0).toUpperCase() + choose.slice(1)} - ${replace(betAmount)} VNĐ`, mentions: [{ tag: user.full_name, id: senderID }] }, threadID, messageID);
};