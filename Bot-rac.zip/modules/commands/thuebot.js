exports.config = {
	name: 'thuebot',
	version: '1.0.5',
  usePrefix: false,
	hasPermssion: 2,
	credits: 'DC-Nam',
	description: 'Thuê bot.',
	commandCategory: 'Admin',
	usages: '[]',
	cooldowns: 3
};

let fs = require('fs');
const moment = require("moment-timezone");

if (!fs.existsSync(__dirname+'/data'))fs.mkdirSync(__dirname+'/data');

let path = __dirname+'/data/thuebot.json';
let data = [];
let save = ()=>fs.writeFileSync(path, JSON.stringify(data));

if (!fs.existsSync(path))save(); else data = require(path);


let form_mm_dd_yyyy = (input = '', split = input.split('/'))=>`${split[1]}/${split[0]}/${split[2]}`;
let invalid_date = date=>/^Invalid Date$/.test(new Date(date));


exports.run = function(o) {
	let send = (msg, callback)=>o.api.sendMessage(msg, o.event.threadID, callback, o.event.messageID);

	switch (o.args[0]) {
		case 'add': {
			if (!o.args[1])return send(`❎ Reply /${this.config.name} add time_end`);
			var uid = o.event.senderID;
			 if(o.event.type == "message_reply") {
			uid = o.event.messageReply.senderID 
		}  else if (Object.keys(o.event.mentions).length > 0) {
				uid = Object.keys(o.event.mentions)[0];
		}
			let t_id = o.event.threadID;
			let id = uid;
			let time_start = moment.tz("Asia/Ho_Chi_Minh").format("DD/MM/YYYY");
			let time_end = o.args[1];
			if (isNaN(id) || isNaN(t_id))return send(`❎ ID Không Hợp Lệ !`);
			if (invalid_date(form_mm_dd_yyyy(time_end)))return send(`❎ Thời Gian Không Hợp Lệ !`);

			data.push({
				t_id, id, time_start, time_end,
			});
			send(`✅ Đã Thêm Vào Danh Sách Thuê !`);
		};
			break;
		case 'list': {
			send(`[ Danh Sách Thuê Bot ]\n\n${data.map(($, i) => {
				const status = new Date(form_mm_dd_yyyy($.time_end)).getTime() >= Date.now() + 25200000 ? '✅' : '❎';
				return `${i + 1}. ${global.data.userName.get($.id)}\n🏘️ Box: ${(global.data.threadInfo.get($.t_id) || {}).threadName}\n📌 Tình Trạng ${status}`;
			}).join('\n──────────────\n')}\n\nSTT Để Xem Rõ\ndel STT Để Xoá\nout STT Để Out Box\ngiahan STT Để Gia Hạn\nGiá thuê bot là 20k/1 tháng`, (err, res) => (res.name = exports.config.name, res.event = o.event, res.data = data, global.client.handleReply.push(res)));
		};
			break;

		default: send(`-${this.config.name} list -> Để Xem Danh Sách Thuê !\nReply: -${this.config.name} add time_end -> Để Thêm Vào Danh Sách Thuê !\nVí dụ: -${this.config.name} add 12/12/2023\nGiá thuê bot là 20k/1 tháng hãy inbox admin để thuê`)
			break;
	}
	save();
};
exports.handleReply = async function(o) {
	let _ = o.handleReply;
	let send = (msg, callback)=>o.api.sendMessage(msg, o.event.threadID, callback, o.event.messageID);

	if (o.event.senderID != _.event.senderID)return;

	if (isFinite(o.event.args[0])) {
		let info = data[o.event.args[0]-1];

		if (!info)return send(`STT không tồn tại!`);

		return send(`[ Thông Tin Thuê Bot ]\n──────────────\n👤 Người Thuê: ${global.data.userName.get(info.id)}\n🌐 Profile: fb.me/${info.id}\n──────────────\n🏘️ Box: ${(global.data.threadInfo.get(info.t_id) || {}).threadName}\n⚡ TID: ${info.t_id}\n📆 Từ: ${info.time_start}\n⏳ Hết Hạn: ${info.time_end}\n📌 Còn ${(()=> {
			let time_diff = new Date(form_mm_dd_yyyy(info.time_end)).getTime()-(Date.now()+25200000);
			let days = (time_diff/(1000*60*60*24))<<0;
			let hour = (time_diff/(1000*60*60)%24)<<0;

			return `${days} Ngày ${hour} Giờ Làn Hết Hạn`;
		})()}`);
	} else if (o.event.args[0].toLowerCase() == 'del') {
		o.event.args.slice(1).sort((a, b)=>b-a).forEach($=>data.splice($-1, 1));
		send(`✅ Đã Xóa !`);
	} else if (o.event.args[0].toLowerCase() == 'giahan') {
		let STT = o.event.args[1];
		let time_start = o.event.args[2];
		let time_end = o.event.args[4];

		if (invalid_date(form_mm_dd_yyyy(time_start)) || invalid_date(form_mm_dd_yyyy(time_end)))return send(`Thời Gian Không Hợp Lệ!`);

		if (!data[STT-1])return send(`STT không tồn tại`);

		let $ = data[STT-1];

		$.time_start = time_start;
		$.time_end = time_end;
		send(`✅ Đã Gia Hạn !`);
	} else if (o.event.args[0].toLowerCase() == 'out') {
		for (let i of o.event.args.slice(1)) await o.api.removeUserFromGroup(o.api.getCurrentUserID(), data[i-1].t_id);

		send(`✅ Đã out !`);
	};
	save();
};