const axios = require('axios');

module.exports.config = {
    name: "Cari",
    version: "1.1",
    hasPermission: 0,
    credits: "tienbu",
    description: "Tương tác với CARI (Trí tuệ nhân tạo đàm thoại)",
    commandCategory: "AI",
    usages: "/Cari [câu hỏi] = [câu trả lời]",
    cooldowns: 3,
};

module.exports.run = async function ({ api, event, args }) {
    const { threadID, senderID } = event;
    const prompt = args.join(" ");

    if (!prompt) {
        api.sendMessage("How can I assist you today?", event.threadID, );
        return;
    }

    try {
        const userName = await getUserName(api, senderID);
        const cariAPI = "https://cari.august-quinn-api.repl.co/response";
        const response = await axios.post(cariAPI, { userID: senderID, userName, prompt });
        const reply = response.data.reply;

        api.sendMessage(reply, threadID, );
    } catch (error) {
        console.error("Lỗi:", error);
        api.sendMessage("⛔ Lưu lượng truy cập cao: Vui lòng thử lại sau.", threadID, event.messageID);
    }
};

async function getUserName(api, userID) {
    try {
        const name = await api.getUserInfo(userID);
        return name[userID].firstName;
    } catch (error) {
        console.error("Error getting user name:", error);
        return "Friend";
    }
}