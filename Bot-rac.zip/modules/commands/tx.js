const fs = require('fs');
const path = require('path');
const axios = require('axios');

module.exports.config = {
    name: "tx",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "Mây Trắng",
    usePrefix: false,
    description: "Tài xỉu trên hệ thống đa dạng nhiều kiểu",
    commandCategory: "Trò Chơi",
    usages: "[tài/xỉu] [số tiền]",
    cooldowns: 10
};

const gifs = [
    "https://trangbel.x10.mx/gif/1.gif",
    "https://trangbel.x10.mx/gif/2.gif",
    "https://trangbel.x10.mx/gif/3.gif",
    "https://trangbel.x10.mx/gif/4.gif",
    "https://trangbel.x10.mx/gif/5.gif",
    "https://trangbel.x10.mx/gif/6.gif"
];

const dataPath = path.join(__dirname, 'data', 'data.json');

function replace(int) {
    return int.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
}

module.exports.run = async function ({ event, api, args }) {
    try {
        const { threadID, messageID, senderID } = event;
        const { sendMessage, unsendMessage } = api;

        
        let data;
        try {
            data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (error) {
            data = [];
        }

        
        const user = data.find(user => user.user_id === senderID);
        if (!user) {
            return sendMessage("Bạn chưa đăng ký @dangkytx để đăng ký", threadID, messageID);
        }

        const name = user.full_name;
        const bet = parseInt(args[1]);
        const input = args[0];

        if (!input || !bet || isNaN(bet)) return sendMessage("[ ❗ ] Bạn nhập sai cú pháp. Cú pháp đúng: @taixiu [tài/xỉu] [số tiền]", threadID, messageID);
        if (bet < 5000) return sendMessage("[ 💸 ] Bạn cần cược tối thiểu là 5,000 VND", threadID, messageID);
        if (bet > user.balance) return sendMessage("[ 💸 ] Bạn thiếu tiền không thể cược", threadID, messageID);

        const choose = (input.toLowerCase() === "tài" || input.toLowerCase() === "xỉu") ? input.toLowerCase() : null;
        if (!choose) return sendMessage("[ ❗ ] Bạn chỉ có thể chọn tài hoặc xỉu", threadID, messageID);

        
        sendMessage("Bắt đầu lắc xúc xắc...", threadID, async () => {
            const dice = [];
            for (let i = 0; i < 3; i++) {
                dice.push(Math.floor(Math.random() * 6) + 1);
            }

            const total = dice.reduce((a, b) => a + b, 0);
            const result = total >= 11 ? "tài" : "xỉu";
            const win = (choose === result) && !(dice[0] === dice[1] && dice[1] === dice[2]);
            const amount = win ? bet * 1.8 : bet;

            if (win) {
                user.balance += Math.floor(amount - bet);
            } else {
                user.balance -= bet;
            }

            
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

            const resultEmoji = result === "tài" ? "⚫️" : "⚪️";
            const currentTime = new Date().toLocaleString("vi-VN", {
                timeZone: "Asia/Ho_Chi_Minh",
                hour12: false,
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit",
                day: "2-digit",
                month: "2-digit",
                year: "numeric"
            });

            const msg = `NGƯỜI CHƠI: ${name}\n`
                + `CƯỢC: ${choose.charAt(0).toUpperCase() + choose.slice(1)}\n`
                + `TIỀN CƯỢC: ${replace(bet)} VND\n`
                + `KẾT QUẢ: ${dice.join("-")} | ${result.charAt(0).toUpperCase() + result.slice(1)} ${resultEmoji}\n`
                + `TIỀN ${(win ? "THẮNG" : "THUA")}: ${replace(Math.floor(amount))} VND\n`
                + `TG: ${currentTime}`;

            const attachments = await Promise.all(dice.map(d => axios.get(gifs[d - 1], { responseType: 'stream' }).then(response => response.data)));

            sendMessage({ body: msg, attachment: attachments }, threadID, (err, info) => {
                if (err) return console.error(err);
                setTimeout(() => {
                    unsendMessage(info.messageID);
                }, 10000); 
            });
        });
    } catch (e) {
        console.error(e);
        sendMessage("[ ❗ ] Đã xảy ra lỗi, vui lòng thử lại sau", threadID, messageID);
    }
};