module.exports.config = {
    name: "ai",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "KENLIEPLAYS",
    usePrefix: true,
    description: "AI by KENLIEPLAYS",
    commandCategory: "ai",
    usages: "[ask]",
    cooldowns: 2,
};

module.exports.run = async function({ api, event, args }) {
    const axios = require("axios");
    const openai = require('openai');

    const userId = event.senderID;
    let { messageID, threadID, senderID, body } = event;
    let tid = threadID,
    mid = messageID;
    const content = args.join(" ");

    if (!content) return api.sendMessage("Vui lòng nhập một câu hỏi...", tid, mid);

    try {
        // Gửi yêu cầu cho model AI của Replit
        const res = await axios.get(`https://ai-tools.replit.app/gpt?prompt=${encodeURIComponent(content)}&uid=${encodeURIComponent(userId)}`);
        const respond = res.data.gpt4;

        if (res.data.error) {
            api.sendMessage(`Lỗi: ${res.data.error}`, tid, mid);
        } else {
            api.sendMessage(respond, tid, async (error, info) => {
                if (error) {
                    console.error(error);
                } else {
                    // Sử dụng OpenAI để tạo phản hồi cho tin nhắn người dùng
                    const openaiResponse = await openai.ChatCompletion.create({
                        model: 'gpt-3.5-turbo',
                        messages: [
                            { role: 'system', content: 'You are a helpful assistant.' },
                            { role: 'user', content: content },
                            { role: 'assistant', content: respond },
                        ],
                    });

                    const assistantResponse = openaiResponse.data.choices[0].message.content;

                    // Gửi phản hồi từ trí óc AI
                    api.sendMessage(`AI: ${assistantResponse}`, tid, mid);
                }
            });
        }
    } catch (error) {
        console.error(error);
        api.sendMessage("Có lỗi xảy ra khi lấy dữ liệu.", tid, mid);
    }
};