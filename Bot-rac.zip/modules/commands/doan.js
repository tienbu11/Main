module.exports.config = {
  name: "đoán",
  version: "1.1.1",
  hasPermssion: 0,
  credits: "Quất",
  description: "Đoán số may mắn",
  commandCategory: "Giải Trí",
  usages: "/đoán [1] [2] [3] hoặc /đoán help",
  usePrefix: false,
  cooldowns: 3,
};

module.exports.run = async function ({ api, event, args, Users, Currencies }) {
  var axios = global.nodemodule["axios"];
  var i = (url) => axios.get(url, { responseType: "stream" }).then((r) => r.data);
  var number1 = parseInt(args[0]);
  if (args.join(' ').trim() === "help") {
    return api.sendMessage({ body: "✦ Bạn sẽ được cược theo ba tham số\n\n1 Tham số đầu tiên sẽ là tham số bạn muốn nhân lên khi thắng cược với số tiền bạn đưa ra (bất kể số nào là số nguyên nhưng không phải nguyên âm và số 0 và số 1) nếu bạn cược số thập phân bạn sẽ mất trắng, tiền càng cao tỉ lệ càng thấp\n2 Tham số thứ 2 bạn sẽ chọn số may mắn cho chính bạn nhưng những số đó chỉ có thể chọn từ 1 đến tham số thứ nhất của bạn\n3 Tham số thứ 3 bạn sẽ cược mệnh giá tiền\n\n✦ Nếu tham số thứ 2 trùng với tham số bot đưa ra thì bạn thắng tặng kèm số tiền mà bạn đã cược nhân với tham số đầu tiên\n✦ Nếu tham số thứ 2 không trùng với tham số bot đưa ra thì bạn thua\n✦ Bot chỉ được quyền random từ 1 đến tham số thứ nhất của bạn và bạn cũng vậy!!\n✦ Bạn có thể cược tất cả thay cho tham số thứ 3 thành \"all\"", attachment: await i("https://i.imgur.com/6gCRMEN.jpg") }, event.threadID);
  }
  var choose = parseInt(args[1]);
  if (isNaN(number1) || number1 !== parseFloat(args[0]) || isNaN(choose) || choose !== parseFloat(args[1]) || number1 <= 1) {
    return api.sendMessage({ body: "✦ Cả 2 tham số đầu tiên phải là một số nguyên và phải lớn hơn 1", attachment: await i("https://i.imgur.com/AtbEqL6.jpg") }, event.threadID);
  }
  var money = (await Currencies.getData(event.senderID)).money;
  var bet = args[2] === 'all' ? money : args[2];
  if (money < bet || money < 1000 || bet < 1000) {
    return api.sendMessage({ body: "Bạn cần đủ 1 trong 3 điều kiện\n✦ Số dư lớn hơn 1000$\n✦ Số tiền đặt cược lớn hơn 1000$\n✦ Tiền cược không được lớn hơn tiền hiện tại", attachment: await i("https://i.imgur.com/PNyoFbm.jpg") }, event.threadID);
  }
  if (number1 == undefined || bet == undefined || choose == undefined) {
    return api.sendMessage({ body: `✦ Bạn chưa đặt cược hãy dùng ${this.config.name} help để biết cách chơi`, attachment: await i("https://i.imgur.com/WscoCkf.jpg") }, event.threadID);
  }
  if (choose > number1) {
    return api.sendMessage({ body: `✦ Số may mắn đưa ra lớn hơn số bạn yêu cầu? Bạn chỉ được chọn số may mắn từ 1 đến ${number1}`, attachment: await i("https://i.imgur.com/AtbEqL6.jpg") }, event.threadID);
  }
  var number = Math.floor(Math.random() * number1) + 1;
  if (choose === number) {
    await Currencies.increaseMoney(event.senderID, parseInt(bet * (number1 - 1)));
    return api.sendMessage({ body: `✦ ▬▬ Bạn Đã Thắng ▬▬ ✦\n➩ Với tỉ lệ thắng là : ${100 / number1}%\n➩ Số bạn đưa ra : ${choose}\n➩ Số bot đưa ra : ${number}\n➩ Số tiền thưởng nhân được : ${bet * number1}$\n➩ Hiện bạn còn : ${money - bet + (bet * number1)}$`, attachment: await i("https://i.imgur.com/4y78gmb.jpg") }, event.threadID);
  } else {
    await Currencies.decreaseMoney(event.senderID, parseInt(bet));
    return api.sendMessage({ body: `✦ ▬▬ Bạn Đã Thua ▬▬ ✦\n➩ Với tỉ lệ thua là : ${100 - (100 / number1)}%\n➩ Số bạn bạn đưa ra : ${choose}\n➩ Số bot đưa ra : ${number}\n➩ Bạn mất : ${bet}$\n➩ Hiện bạn còn : ${money - bet}$`, attachment: await i("https://i.imgur.com/Xi7cf0f.jpg") }, event.threadID);
  }
};