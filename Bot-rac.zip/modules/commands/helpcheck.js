module.exports.config = {
  name: "helpcheck",
  version: "1.0.0",
  usePrefix: false,
  hasPermssion: 0,
  credits: "Mây Trắng",
  description: "Hiển thị danh sách các lệnh có sẵn",
  commandCategory: "Hỗ trợ",
  usages: "helpcheck",
  cooldowns: 5
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID } = event;
  const { sendMessage } = api;

  const helpMessage = `
[CHECK HELP]:
1. checktt: repply/tag/: xem chi tiết tương tác, xếp hạng, ngày tham gia nhóm..

2. checktuongtac: day/week/all: Xem tất cả tương tác trong ngày/tuần/tổng.

3. checknickname: Xem tất cả thành viên chưa đặt biệt danh.

4. checklockick + số tin nhắn: Lọc những thành viên có số tin nhắn ít hơn số đã chỉ định. Hiện thị danh sách và repply stt để kick

5. checkdie: Kiểm tra những tài khoản Facebook đã bị vô hiệu hóa.

6. checktagg: Tag tất cả thành viên ít tương tác trong ngày.

7. checksendnoti + giờ:phút:giây/on/off/clear: Đặt thời gian gửi thông báo tương tác /bật/tắt/xóa chế độ tự động gửi thông báo.

8. checkreset: Đặt lại dữ liệu tương tác của nhóm về 0.
`;

  sendMessage(helpMessage, threadID, messageID);
};