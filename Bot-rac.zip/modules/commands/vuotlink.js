const axios = require('axios');

module.exports = {
  cấu hình: {
    tên: 'vuotlink',
    phiên bản: '1.0.0',
    hasPermssion: 0,
    credit: 'Mây trắng',
    mô tả: 'Bỏ qua liên kết',
    commandCategory: 'Tiện ích',
    cách sử dụng: '[liên kết]',
    thời gian hồi chiêu: 3
  },

  chạy: hàm không đồng bộ ({ api, sự kiện, args }) {
    hãy liên kết = args.join(" ");


    link = link.replace(/^https?:\/\//, '');    

    link = link.replace(/\/.*/, '');

    const validLinks = ['traffic123.net', 'link68.net', 'laymangay.com'];

    if (!validLinks.includes(link)) {
      return api.sendMessage(`Các liên kết hiện có thể bỏ qua là:\n- Traffic123.net\n- link68.net\n- laymanngay.com`, event.threadID);
    }

    thử {
      const phản hồi = đang chờ axios.get(`${link}`);
      const { trạng thái, mật khẩu } = phản hồi.data;

      nếu (trạng thái) {
        api.sendMessage(`Mã: ${password}`, event.threadID);
      } khác {
        api.sendMessage('Không tìm thấy Mã.', event.threadID);
      }
    } bắt (lỗi) {
      console.error(lỗi);
      api.sendMessage('Có lỗi xảy ra, vui lòng thử lại sau.', event.threadID);
    }
  }
};