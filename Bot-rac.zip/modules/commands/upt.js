const os = require('os');
const moment = require('moment-timezone');
const fs = require('fs').promises;
const axios = require('axios');

module.exports.config = {
		name: "upt",
		version: "2.0.0",
    usePrefix: false,
		hasPermission: 0,
		credits: "Thjhn",
		description: "Hiển thị thông tin hệ thống của bot",
		commandCategory: "Admin",
		usages: "",
		cooldowns: 5
};

async function getDependencyCount() {
		try {
				const packageJsonString = await fs.readFile('package.json', 'utf8');
				const packageJson = JSON.parse(packageJsonString);
				const depCount = Object.keys(packageJson.dependencies || {}).length;
				const devDepCount = Object.keys(packageJson.devDependencies || {}).length;
				return { depCount, devDepCount };
		} catch (error) {
				console.error('Không thể đọc file package.json:', error);
				return { depCount: -1, devDepCount: -1 };
		}
}

function getStatusByPing(ping) {
		if (ping < 50) {
				return 'Rất Tốt';
		} else if (ping < 100) {
				return 'Tốt';
		} else if (ping < 300) {
				return 'Bình Thường';
		} else {
				return 'Xấu !';
		}
}

async function getPrimaryIP() {
		try {
				const response = await axios.get('https://api.ipify.org/?format=json');
				return response.data.ip;
		} catch (error) {
				console.error('Lỗi khi lấy địa chỉ IP:', error);
				return '127.0.0.1';
		}
}

module.exports.run = async ({ api, event, Users }) => {
		try {
			    const url = await axios.get('http://localhost:1604/');
				const urlUptime = url.data.Uptime;
				const commands = global.client.commands
				const events = global.client.events
				const totalMemory = os.totalmem();
				const freeMemory = os.freemem();
				const usedMemory = totalMemory - freeMemory;
				const uptime = process.uptime();
				const { depCount, devDepCount } = await getDependencyCount();
				let name = await Users.getNameUser(event.senderID);
				let threadInfo = await api.getThreadInfo(event.threadID);
				let threadName = threadInfo.threadName;
				const systemPrefix = global.config.PREFIX;
				const groupPrefix = global.data.threadData.get(event.threadID)?.PREFIX || systemPrefix;
				const primaryIp = await getPrimaryIP();
				const timeStart = Date.now();
				const botStatus = getStatusByPing(Date.now() - timeStart);
				const uptimeString = urlUptime;

				const replyMsg = `
⏰ Thời gian: ${moment().tz('Asia/Ho_Chi_Minh').format('HH:mm:ss')} || ${moment().tz('Asia/Ho_Chi_Minh').format('DD/MM/YYYY')}
⏱️ Uptime: ${uptimeString}
📝 Prefix Main [ ${systemPrefix} ]
💥 Prefix Box [ ${groupPrefix} ]
🏝 Tổng Nhóm: ${global.data.allThreadID.length}
👤 Tổng Người Dùng: ${global.data.allUserID.length}
🔣 Tình Trạng: ${botStatus}
👉 Thông Tin Hệ Thống 👈
📋 Hệ Điều Hành: ${os.type()}
💾 CPU: ${os.cpus().length} core(s)
🌉 Model: ${os.cpus()[0].model.trim()}
🔥 Xung Nhịp: ${os.cpus()[0].speed}MHz
📊 Ram: ${(usedMemory / 1024 / 1024 / 1024).toFixed(2)}GB/${(totalMemory / 1024 / 1024 / 1024).toFixed(2)}GB
🛜 Ping: ${Date.now() - timeStart} ms
🗣 ${name} - ${threadName || `Đoạn Chat Riêng !`}
	`.trim();

				api.sendMessage(replyMsg, event.threadID, event.messageID);
		} catch (error) {
				console.error('Lỗi khi thực hiện yêu cầu:', error);
		}
};