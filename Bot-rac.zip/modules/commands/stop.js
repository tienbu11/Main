const fs = require('fs');
const path = require('path');

module.exports.config = {
    name: "stop",
    version: "1.0.0",
    hasPermssion: 2,
    usePrefix: false,
    credits: "Mây Trắng",
    description: "Dừng phiên Tài Xỉu tự động",
    commandCategory: "Trò Chơi",
    usages: "@stopmophienauto",
    cooldowns: 5
};

const statePath = path.join(__dirname, 'data', 'state.json');

function readState() {
    try {
        return JSON.parse(fs.readFileSync(statePath, 'utf8'));
    } catch (error) {
        return { isSessionActive: false, bets: [], history: [] };
    }
}

function writeState(state) {
    fs.writeFileSync(statePath, JSON.stringify(state, null, 2));
}

module.exports.run = function ({ api, event }) {
    const { threadID, messageID } = event;
    const { sendMessage } = api;
    let state = readState();

    if (!state.isSessionActive) {
        return sendMessage("Hiện không có phiên cược nào đang diễn ra.", threadID, messageID);
    }


    state.isSessionActive = false;
    state.bets = [];
    writeState(state);
    sendMessage("Đã dừng phiên cược tự động.", threadID, messageID);
};
