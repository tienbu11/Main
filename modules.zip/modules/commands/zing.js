const axios = require('axios');

exports.config = {
 name: 'zing',
 version: '1.0.0',
 hasPermssion: 0,
 usePrefix: false,
 credits: 'Trung Hieu',
 description: 'Lấy thông tin từ Zing MP3',
 commandCategory: 'Tiện ích',
 usages: '[]',
 cooldowns: 5,
};

const API_KEY = 'HARIN'; 

exports.run = async function ({ api, event, args }) {
 const { threadID: tid, messageID: mid, senderID: sid } = event;
 const command = args[0];
 const argument = args.slice(1).join(" ");

 switch (command) {
 case 'info':
 const infoUrl = argument;
 if (!infoUrl) {
 return api.sendMessage("Vui lòng cung cấp URL bài hát!", tid, mid);
 }
 try {
 const response = await axios.get(`https://api.phungtuanhai.site/api/zingmp3/info?apikey=${API_KEY}&link=${encodeURIComponent(infoUrl)}`);
 const data = response.data;
 console.log(data); // Log data để kiểm tra
 if (data.error) {
 return api.sendMessage("❎ URL không hợp lệ hoặc có lỗi xảy ra.", tid, mid);
 }
 
 const artworkUrl = data.album_cover || 'Không có ảnh bìa'; // Lấy URL ảnh bìa từ dữ liệu
 const message = {
 body: `Thông tin bài hát từ Zing MP3:\n- Tiêu đề: ${data.title}\n- Nghệ sĩ: ${data.artist}\n- Album: ${data.album}\n- Link bài hát: ${data.link}`,
 };

 if (artworkUrl !== 'Không có ảnh bìa') {
 const imageBuffer = await streamURL(artworkUrl);
 if (imageBuffer) {
 message.attachment = imageBuffer;
 }
 }

 api.sendMessage(message, tid, mid);
 } catch (error) {
 console.error(error);
 api.sendMessage("❎ Không thể lấy thông tin bài hát từ URL này.", tid, mid);
 }
 break;

 case 'search':
 const searchKeyword = argument;
 if (!searchKeyword) {
 return api.sendMessage("Vui lòng cung cấp từ khóa tìm kiếm!", tid, mid);
 }
 try {
 const response = await axios.get(`https://api.phungtuanhai.site/api/zingmp3/search?apikey=${API_KEY}&keyword=${encodeURIComponent(searchKeyword)}`);
 const data = response.data;
 console.log(data); // Log data để kiểm tra
 if (data.error) {
 return api.sendMessage("❎ Không tìm thấy kết quả tìm kiếm.", tid, mid);
 }
 const results = data.songs.slice(0, 5); 
 const listMessage = results.map((song, index) => `|› ${index + 1}. Tiêu đề: ${song.title}\n|› Nghệ sĩ: ${song.artist}\n|› Link: ${song.link}\n──────────────────`).join('\n');
 api.sendMessage({
 body: `[ Zing MP3 Search Results ]\n──────────────────\n${listMessage}\n\n📌 Reply (phản hồi) STT để xem thông tin chi tiết`
 }, tid, (error, info) => {
 if (error) return console.error("Error sending message:", error);
 global.client.handleReply.push({
 type: "search",
 name: exports.config.name,
 author: sid,
 messageID: info.messageID,
 result: results,
 });
 });
 } catch (error) {
 console.error(error);
 api.sendMessage("❎ Không thể tìm kiếm với từ khóa này.", tid, mid);
 }
 break;

 default:
 api.sendMessage({
 body: `Sử dụng các lệnh:\ninfo [URL]\nsearch [keyword]`,
 attachment: await streamURL('https://files.catbox.moe/1rybcw.jpeg')
 }, tid, mid);
 break;
 }
};

async function streamURL(url) {
 try {
 const response = await axios.get(url, { responseType: 'arraybuffer' });
 const imageBuffer = Buffer.from(response.data, 'binary');
 return imageBuffer;
 } catch (error) {
 console.error("Error streaming URL:", error);
 return null;
 }
}

module.exports.handleReply = async function ({ event, api, handleReply }) {
 const { threadID: tid, messageID: mid, body } = event;
 const choose = parseInt(body);
 if (isNaN(choose)) {
 return api.sendMessage('⚠️ Vui lòng nhập một số hợp lệ.', tid, mid);
 }
 const selected = handleReply.result[choose - 1];
 if (!selected) {
 return api.sendMessage('❎ Lựa chọn không hợp lệ.', tid, mid);
 }
 switch (handleReply.type) {
 case 'search':
 api.unsendMessage(handleReply.messageID);
 api.sendMessage({
 body: `Thông tin bài hát từ Zing MP3:\n- Tiêu đề: ${selected.title}\n- Nghệ sĩ: ${selected.artist}\n- Album: ${selected.album}\n- Link bài hát: ${selected.link}`
 }, tid, mid);
 break;

 default:
 break;
 }
};