﻿const fs = require('fs-extra');
const path = require('path');
const axios = require('axios');

const antiDir = "./modules/commands/data/anti";
const crFile = (f, i) => {
    if (!fs.existsSync(f)) {
        const data = i !== undefined ? JSON.stringify(i, null, 2) : JSON.stringify([]);
        fs.writeFileSync(f, data);
    }
};
if (!fs.existsSync(antiDir)) fs.mkdirSync(antiDir, { recursive: true });

const antiNameBox = antiDir + "/antiNameBox.json"; crFile(antiNameBox);
const antiIMG = antiDir + "/antiIMG.json"; crFile(antiIMG);
const BietDanh = antiDir + "/BietDanh.json"; crFile(BietDanh);
const Out = antiDir + "/Out.json"; crFile(Out);
const iCon = antiDir + "/iCon.json"; crFile(iCon);
const Join = antiDir + "/Join.json"; crFile(Join);
const Qtv = antiDir + "/Qtv.json"; crFile(Qtv);
const antiSpam = antiDir + "/antiSpam.json"; crFile(antiSpam);


const FilePathImage = antiDir + '/anti_image'
if (!fs.existsSync(FilePathImage)) fs.mkdirSync(FilePathImage, { recursive: true });

module.exports.config = {
    name: "anti",
    version: "2.0.0",
    hasPermssion: 1,
    credits: "Niio-team (Vtuan)",
	    usePrefix: false,
    description: "Quản Lí Box",
    commandCategory: "Nhóm",
    usages: "No",
    cooldowns: 0
};

module.exports.run = async ({ api, event, args, Threads }) => {
    const { threadID, senderID } = event
    const LC = args[0]
    if (LC === "namebox") {
        let read = await fs.readFile(antiNameBox, 'utf-8');
        let antiData = read ? JSON.parse(read) : [];
        let threadEntry = antiData.find(entry => entry.threadID === threadID);

        if (threadEntry) {
            antiData = antiData.filter(entry => entry.threadID !== threadID);
            await fs.writeFile(antiNameBox, JSON.stringify(antiData, null, 4), 'utf-8');
            api.sendMessage("✅ Đã tắt chế độ chống đổi tên nhóm", threadID);
        } else {
            const thread = (await Threads.getData(event.threadID)).threadInfo;
            const nameBox = thread.threadName;

            const Data = {
                threadID: threadID,
                namebox: nameBox,
                report: {}
            };
            antiData.push(Data);

            await fs.writeFile(antiNameBox, JSON.stringify(antiData, null, 4), 'utf-8');
            api.sendMessage("✅ Đã bật chế độ chống đổi tên nhóm", threadID);

        }
    }
    else if (LC === "avtbox") {
        let read = await fs.readFile(antiIMG, 'utf-8');
        let antiData = read ? JSON.parse(read) : [];
        let threadEntry = antiData.find(entry => entry.threadID === threadID);
        const filePath = path.join(FilePathImage, `${threadID}.png`);

        if (threadEntry) {
            antiData = antiData.filter(entry => entry.threadID !== threadID);
            fs.unlinkSync(filePath)
            await fs.writeFile(antiIMG, JSON.stringify(antiData, null, 4), 'utf-8');
            api.sendMessage("✅ Đã tắt chế độ chống đổi ảnh nhóm", threadID);
        } else {
            let msg = await api.sendMessage("🔨 Tiến hành khởi động chế độ vui lòng chờ!!!", threadID);

            const threadInfo = await Threads.getData(event.threadID);
            const thread = threadInfo.threadInfo;
            axios({
                url: thread.imageSrc,
                responseType: 'stream',
            }).then(response => {
                response.data.pipe(fs.createWriteStream(filePath))
            }).catch(err => {
                console.error('Lỗi khi tải ảnh:', err);
            });
            try {
                const Data = {
                    threadID: threadID
                };
                antiData.push(Data);
                await fs.writeFile(antiIMG, JSON.stringify(antiData, null, 4), 'utf-8');

                api.unsendMessage(msg.messageID);


                api.sendMessage("✅ Đã bật chế độ chống đổi ảnh nhóm", threadID);
            } catch (error) {
                api.sendMessage("Đã xảy ra lỗi!!", threadID);
            }
        }
    }

    else if (LC === "bietdanh") {
        let read = await fs.readFile(BietDanh, 'utf-8');
        let antiData = read ? JSON.parse(read) : [];
        let threadEntry = antiData.find(entry => entry.threadID === threadID);
        if (threadEntry) {
            antiData.splice(threadEntry, 1);
            api.sendMessage("✅ Tắt thành công chế độ anti đổi biệt danh", threadID);
        } else {
            const nickName = (await Threads.getData(event.threadID)).threadInfo.nicknames;
            antiData.push({ threadID, data: nickName });
            api.sendMessage("✅ Bật thành công chế độ anti đổi biệt danh", threadID);
        }
        await fs.writeFile(BietDanh, JSON.stringify(antiData, null, 4), 'utf-8');
    }

    else if (LC === "out") {
        let read = await fs.readFile(Out, 'utf-8');
        let antiData = read ? JSON.parse(read) : [];
        let threadEntry = antiData.find(entry => entry.threadID === threadID);
        if (threadEntry) {
            antiData = antiData.filter(entry => entry.threadID !== threadID);
            await fs.writeFile(Out, JSON.stringify(antiData, null, 4), 'utf-8');
            api.sendMessage("✅ Đã tắt chế độ chống người dùng thoát khỏi nhóm", threadID);
        } else {
            antiData.push({ threadID: threadID });
            await fs.writeFile(Out, JSON.stringify(antiData, null, 4), 'utf-8');
            api.sendMessage("✅ Đã bật chế độ chống người dùng thoát khỏi nhóm", threadID);
        }
    }

    else if (LC === "join") {
        const info = (await Threads.getData(event.threadID)).threadInfo;
        if (!info.adminIDs.some(item => item.id == api.getCurrentUserID()))
            return api.sendMessage('⚠️ Bot cần quyền quản trị viên nhóm', threadID, event.messageID);
        let read = await fs.readFile(Join, 'utf-8');
        let antiData = read ? JSON.parse(read) : [];
        let threadEntry = antiData.find(entry => entry.threadID === threadID);
        if (threadEntry) {
            antiData = antiData.filter(entry => entry.threadID !== threadID);
            await fs.writeFile(Out, JSON.stringify(antiData, null, 4), 'utf-8');
            api.sendMessage("✅ Đã tắt chế độ chống người dùng tham gia nhóm", threadID);
        } else {
            antiData.push({ threadID: threadID });
            await fs.writeFile(Join, JSON.stringify(antiData, null, 4), 'utf-8');
            api.sendMessage("✅ Đã bật chế độ chống người dùng tham gia nhóm", threadID);
        }
    }

    else if (LC === "qtv") {
        const info = (await Threads.getData(event.threadID)).threadInfo;
        if (!info.adminIDs.some(item => item.id == api.getCurrentUserID()))
            return api.sendMessage('⚠️ Bot cần quyền quản trị viên nhóm', event.threadID, event.messageID);
        let read = await fs.readFile(Qtv, 'utf-8');
        let antiData = read ? JSON.parse(read) : [];
        let threadEntry = antiData.find(entry => entry.threadID === threadID);
        if (threadEntry) {
            antiData = antiData.filter(entry => entry.threadID !== threadID);
            await fs.writeFile(Qtv, JSON.stringify(antiData, null, 4), 'utf-8');
            api.sendMessage("✅ Đã tắt chế độ chống cướp qtv", threadID);
        } else {
            antiData.push({ threadID: threadID });
            await fs.writeFile(Qtv, JSON.stringify(antiData, null, 4), 'utf-8');
            api.sendMessage("✅ Đã bật chế độ chống cướp qtv", threadID);
        }
    }

    else if (LC === "emoji") {
        let read = await fs.readFile(iCon, 'utf-8');
        let antiData = read ? JSON.parse(read) : [];
        let threadEntry = antiData.find(entry => entry.threadID === threadID);
        if (threadEntry) {
            antiData = antiData.filter(entry => entry.threadID !== threadID);
            await fs.writeFile(iCon, JSON.stringify(antiData, null, 4), 'utf-8');
            api.sendMessage("✅ Đã tắt chế độ chống đổi emoji", threadID);
        } else {
            const thread = (await Threads.getData(event.threadID)).threadInfo;
            const emoji = thread.emoji;

            const Data = {
                threadID: threadID,
                emoji: emoji
            };
            antiData.push(Data);

            await fs.writeFile(iCon, JSON.stringify(antiData, null, 4), 'utf-8');
            api.sendMessage("✅ Đã bật chế độ chống đổi emoji", threadID);
        }
    }

    else if (LC === "spam") {
        const info = (await Threads.getData(event.threadID)).threadInfo;
        if (!info.adminIDs.some(item => item.id == api.getCurrentUserID()))
            return api.sendMessage('⚠️ Bot cần quyền quản trị viên nhóm', event.threadID, event.messageID);
        let read = await fs.readFile(antiSpam, 'utf-8');
        let antiData = read ? JSON.parse(read) : [];
        let threadEntry = antiData.find(entry => entry.threadID === threadID);
        if (threadEntry) {
            antiData = antiData.filter(entry => entry.threadID !== threadID);
            await fs.writeFile(antiSpam, JSON.stringify(antiData, null, 4), 'utf-8');
            api.sendMessage("✅ Đã tắt chế độ chống spam", threadID);
        } else {
            antiData.push({ threadID: threadID });
            await fs.writeFile(antiSpam, JSON.stringify(antiData, null, 4), 'utf-8');
            api.sendMessage("✅ Đã bật chế độ chống spam", threadID);
        }
    }

    else if (LC === "check") {
        let status = "";
        const filesToRead = [antiNameBox, antiIMG, BietDanh, Out, Join, Qtv, iCon, antiSpam];
        const antiModes = ["namebox", "avtbox", "bietdanh", "out", "join", "qtv", "icon", "spam"];

        for (let i = 0; i < filesToRead.length; i++) {
            let read = await fs.readFile(filesToRead[i], 'utf-8');
            let antiData = read ? JSON.parse(read) : [];
            let threadEntry = antiData.find(entry => entry.threadID === threadID);
            if (threadEntry) {
                status += `${i + 1}. Anti ${antiModes[i]}: bật\n`;
            } else {
                status += `${i + 1}. Anti ${antiModes[i]}: tắt\n`;
            }
        }

        api.sendMessage(`[ CONFIG ANTI ]\n\n${status}\nReply tin nhắn này kèm số thứ tự để bật hoặc tắt chế độ`, threadID, (err, info) => {
            if (err) return console.error(err);
            global.client.handleReply.push({
                name: module.exports.config.name,
                author: senderID,
                messageID: info.messageID,
                threadID: event.threadID,
            });
        });
    }

    else {
        const { PREFIX } = global.config;
        let threadSetting = global.data.threadData.get(threadID) || {};
        let prefix = threadSetting.PREFIX || PREFIX;
        const messageBody = `
Hướng dẫn sử dụng - HDSĐ:
${prefix}anti + tên anti để sử dụng nhanh!

1. ${prefix}anti namebox - Cấm đổi tên nhóm
2. ${prefix}anti avtbox - Cấm đổi ảnh nhóm
3. ${prefix}anti bietdanh - Cấm đổi biệt danh
4. ${prefix}anti out - Cấm out chùa
5. ${prefix}anti join - Cấm người vào box
6. ${prefix}anti qtv - Chống cướp box
7. ${prefix}anti emoji - Cấm đổi emoji
8. ${prefix}anti spam - Chống spam
9. ${prefix}anti check - Kiểm tra anti của box

-> Reply số để bật/tắt tính năng.
`;

        api.sendMessage(messageBody, threadID, (err, info) => {
            if (err) return console.error(err);
            global.client.handleReply.push({
                name: module.exports.config.name,
                author: senderID,
                messageID: info.messageID,
                threadID: event.threadID,
            });
        });
    }
}

module.exports.handleReply = async ({ api, event, handleReply, Threads }) => {
    const { threadID, senderID } = event;
    const { author } = handleReply;

    const adminIDs = (await Threads.getData(event.threadID)).threadInfo.adminIDs.map(admin => admin.id);

    if (!adminIDs.includes(senderID)) return api.sendMessage(`⚠️Bạn không phải quản trị viên!!`, threadID);

    const number = event.args.filter(i => !isNaN(i));
    for (const num of number) {
        switch (num) {
            case "1": {
                let read = await fs.readFile(antiNameBox, 'utf-8');
                let antiData = read ? JSON.parse(read) : [];
                let threadEntry = antiData.find(entry => entry.threadID === threadID);

                if (threadEntry) {
                    antiData = antiData.filter(entry => entry.threadID !== threadID);
                    await fs.writeFile(antiNameBox, JSON.stringify(antiData, null, 4), 'utf-8');
                    api.sendMessage("✅ Đã tắt chế độ chống đổi tên nhóm", threadID);
                } else {
                    const thread = (await Threads.getData(event.threadID)).threadInfo;
                    const nameBox = thread.threadName;

                    const Data = {
                        threadID: threadID,
                        namebox: nameBox,
                        report: {}
                    };
                    antiData.push(Data);

                    await fs.writeFile(antiNameBox, JSON.stringify(antiData, null, 4), 'utf-8');
                    api.sendMessage("✅ Đã bật chế độ chống đổi tên nhóm", threadID);
                }
                break;
            }
            case "2": {
                let read = await fs.readFile(antiIMG, 'utf-8');
                let antiData = read ? JSON.parse(read) : [];
                let threadEntry = antiData.find(entry => entry.threadID === threadID);
                const filePath = path.join(FilePathImage, `${threadID}.png`);

                if (threadEntry) {
                    antiData = antiData.filter(entry => entry.threadID !== threadID);
                    fs.unlinkSync(filePath)
                    await fs.writeFile(antiIMG, JSON.stringify(antiData, null, 4), 'utf-8');
                    api.sendMessage("✅ Đã tắt chế độ chống đổi ảnh nhóm", threadID);
                } else {
                    let msg = await api.sendMessage("🔨 Tiến hành khởi động chế độ vui lòng chờ!!!", threadID);

                    const threadInfo = await Threads.getData(event.threadID);
                    const thread = threadInfo.threadInfo;
                    axios({
                        url: thread.imageSrc,
                        responseType: 'stream',
                    }).then(response => {
                        response.data.pipe(fs.createWriteStream(filePath))
                    }).catch(err => {
                        console.error('Lỗi khi tải ảnh:', err);
                    });
                    try {
                        const Data = {
                            threadID: threadID
                        };
                        antiData.push(Data);
                        await fs.writeFile(antiIMG, JSON.stringify(antiData, null, 4), 'utf-8');

                        api.unsendMessage(msg.messageID);


                        api.sendMessage("✅ Đã bật chế độ chống đổi ảnh nhóm", threadID);
                    } catch (error) {
                        api.sendMessage("Đã xảy ra lỗi!!", threadID);
                    }
                }
                break;
            }
            case "3": {
                let read = await fs.readFile(BietDanh, 'utf-8');
                let antiData = read ? JSON.parse(read) : [];
                let threadEntry = antiData.find(entry => entry.threadID === threadID);
                if (threadEntry) {
                    antiData.splice(threadEntry, 1);
                    api.sendMessage("✅ Tắt thành công chế độ anti đổi biệt danh", threadID);
                } else {
                    const nickName = (await Threads.getData(event.threadID)).threadInfo.nicknames;
                    antiData.push({ threadID, data: nickName });
                    api.sendMessage("✅ Bật thành công chế độ anti đổi biệt danh", threadID);
                }
                await fs.writeFile(BietDanh, JSON.stringify(antiData, null, 4), 'utf-8');
                break;
            }
            case "4": {
                let read = await fs.readFile(Out, 'utf-8');
                let antiData = read ? JSON.parse(read) : [];
                let threadEntry = antiData.find(entry => entry.threadID === threadID);
                if (threadEntry) {
                    antiData = antiData.filter(entry => entry.threadID !== threadID);
                    await fs.writeFile(Out, JSON.stringify(antiData, null, 4), 'utf-8');
                    api.sendMessage("✅ Đã tắt chế độ chống người dùng thoát khỏi nhóm", threadID);
                } else {
                    antiData.push({ threadID: threadID });
                    await fs.writeFile(Out, JSON.stringify(antiData, null, 4), 'utf-8');
                    api.sendMessage("✅ Đã bật chế độ chống người dùng thoát khỏi nhóm", threadID);
                }
                break;
            }
            case "5": {
                const info = (await Threads.getData(event.threadID)).threadInfo
                if (!info.adminIDs.some(item => item.id == api.getCurrentUserID()))
                    return api.sendMessage('⚠️ Bot cần quyền quản trị viên nhóm', threadID, event.messageID);
                let read = await fs.readFile(Join, 'utf-8');
                let antiData = read ? JSON.parse(read) : [];
                let threadEntry = antiData.find(entry => entry.threadID === threadID);
                if (threadEntry) {
                    antiData = antiData.filter(entry => entry.threadID !== threadID);
                    await fs.writeFile(Out, JSON.stringify(antiData, null, 4), 'utf-8');
                    api.sendMessage("✅ Đã tắt chế độ chống người dùng tham gia nhóm", threadID);
                } else {
                    antiData.push({ threadID: threadID });
                    await fs.writeFile(Join, JSON.stringify(antiData, null, 4), 'utf-8');
                    api.sendMessage("✅ Đã bật chế độ chống người dùng tham gia nhóm", threadID);
                }
                break;
            }
            case "6": {
                const info = (await Threads.getData(event.threadID)).threadInfo
                if (!info.adminIDs.some(item => item.id == api.getCurrentUserID()))
                    return api.sendMessage('⚠️ Bot cần quyền quản trị viên nhóm', event.threadID, event.messageID);
                let read = await fs.readFile(Qtv, 'utf-8');
                let antiData = read ? JSON.parse(read) : [];
                let threadEntry = antiData.find(entry => entry.threadID === threadID);
                if (threadEntry) {
                    antiData = antiData.filter(entry => entry.threadID !== threadID);
                    await fs.writeFile(Qtv, JSON.stringify(antiData, null, 4), 'utf-8');
                    api.sendMessage("✅ Đã tắt chế độ chống cướp qtv", threadID);
                } else {
                    antiData.push({ threadID: threadID });
                    await fs.writeFile(Qtv, JSON.stringify(antiData, null, 4), 'utf-8');
                    api.sendMessage("✅ Đã bật chế độ chống cướp qtv", threadID);
                }
                break;
            }
            case "7": {
                let read = await fs.readFile(iCon, 'utf-8');
                let antiData = read ? JSON.parse(read) : [];
                let threadEntry = antiData.find(entry => entry.threadID === threadID);
                if (threadEntry) {
                    antiData = antiData.filter(entry => entry.threadID !== threadID);
                    await fs.writeFile(iCon, JSON.stringify(antiData, null, 4), 'utf-8');
                    api.sendMessage("✅ Đã tắt chế độ chống đổi emoji", threadID);
                } else {
                    const thread = (await Threads.getData(event.threadID)).threadInfo;
                    const emoji = thread.emoji;

                    const Data = {
                        threadID: threadID,
                        emoji: emoji
                    };
                    antiData.push(Data);

                    await fs.writeFile(iCon, JSON.stringify(antiData, null, 4), 'utf-8');
                    api.sendMessage("✅ Đã bật chế độ chống đổi emoji", threadID);
                }
                break;
            }
            case "8": {
                const info = (await Threads.getData(event.threadID)).threadInfo
                if (!info.adminIDs.some(item => item.id == api.getCurrentUserID()))
                    return api.sendMessage('⚠️ Bot cần quyền quản trị viên nhóm', event.threadID, event.messageID);
                let read = await fs.readFile(antiSpam, 'utf-8');
                let antiData = read ? JSON.parse(read) : [];
                let threadEntry = antiData.find(entry => entry.threadID === threadID);
                if (threadEntry) {
                    antiData = antiData.filter(entry => entry.threadID !== threadID);
                    await fs.writeFile(antiSpam, JSON.stringify(antiData, null, 4), 'utf-8');
                    api.sendMessage("✅ Đã tắt chế độ chống spam", threadID);
                } else {
                    antiData.push({ threadID: threadID });
                    await fs.writeFile(antiSpam, JSON.stringify(antiData, null, 4), 'utf-8');
                    api.sendMessage("✅ Đã tắt chế độ chống spam", threadID);
                }
                break;
            }
            case "9": {
                let status = "";
                const filesToRead = [antiNameBox, antiIMG, BietDanh, Out, Join, Qtv, iCon, antiSpam];
                const antiModes = ["namebox", "avtbox", "bietdanh", "out", "join", "qtv", "icon", "spam"];

                for (let i = 0; i < filesToRead.length; i++) {
                    let read = await fs.readFile(filesToRead[i], 'utf-8');
                    let antiData = read ? JSON.parse(read) : [];
                    let threadEntry = antiData.find(entry => entry.threadID === threadID);
                    if (threadEntry) {
                        status += `${i + 1}. Anti ${antiModes[i]}: bật\n`;
                    } else {
                        status += `${i + 1}. Anti ${antiModes[i]}: tắt\n`;
                    }
                }

                api.sendMessage(`[ CONFIG ANTI ]\n\n${status}\nReply tin nhắn này kèm số thứ tự để bật hoặc tắt chế độ`, threadID, (err, info) => {
                    if (err) return console.error(err);
                    global.client.handleReply.push({
                        name: module.exports.config.name,
                        author: senderID,
                        messageID: info.messageID,
                        threadID: event.threadID,
                    });
                });
                break;
            }

        }
    }
};
let usersSpam = {};
module.exports.handleEvent = async function ({ api, event, Threads, Users }) {
    const { threadID, senderID } = event;

    let read = await fs.readFile(antiSpam, 'utf-8');
    let antiData = read ? JSON.parse(read) : [];
    let threadEntry = antiData.find(entry => entry.threadID === threadID);

    if (threadEntry) {

        const adminIDs = (await Threads.getData(event.threadID)).threadInfo.adminIDs.map(admin => admin.id);
        const adminBot = global.config.ADMINBOT || [];

        if (adminBot.includes(senderID) || adminIDs.includes(senderID)) return;
        if (!usersSpam[senderID]) {
            usersSpam[senderID] = { count: 0, start: Date.now() };
        }
        usersSpam[senderID].count++;
        const userInfo = await Users.getData(senderID);
        const userName = userInfo.name;

        if (Date.now() - usersSpam[senderID].start > 2500) {
            if (usersSpam[senderID].count > 5) {
                api.removeUserFromGroup(senderID, threadID);
                api.sendMessage({
                    body: `Đã tự động kick ${userName} do spam`
                }, threadID);
            }
            usersSpam = {}
        }
    }
}