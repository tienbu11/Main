const fs = require('fs');
const path = require('path');
const dataPath = path.join(__dirname, '../../Game/data.json');

function readData() {
    if (fs.existsSync(dataPath)) {
        const data = fs.readFileSync(dataPath);
        return JSON.parse(data);
    } else {
        return {};
    }
}

function writeData(data) {
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 4));
}

module.exports.config = {
    name: "setmoney",
    version: "1.0.0",
    hasPermssion: 2,
    usePrefix: false,
    credits: "CatalizCS",
    description: "Điều chỉnh thông tin của người dùng",
    commandCategory: "Admin",
    usages: "[add/set/clean/reset] [Số tiền] [Tag người dùng]",
    cooldowns: 5
};

module.exports.run = async function({ event, api, args }) {
    const { threadID, messageID, senderID } = event;
    const mentionID = Object.keys(event.mentions);
    const money = parseInt(args[1]);
    let data = readData();

    var message = [];
    var error = [];
    try {
        switch (args[0]) {
            case "add": {
                if (mentionID.length != 0) {
                    for (let singleID of mentionID) {
                        if (isNaN(money)) return api.sendMessage('❎ Money phải là một số', threadID, messageID);
                        if (!data[singleID]) data[singleID] = 0;
                        data[singleID] += money;
                        message.push(singleID);
                    }
                } else {
                    if (isNaN(money)) return api.sendMessage('Money phải là một số', threadID, messageID);
                    let uid = event.senderID;
                    if (event.type == "message_reply") uid = event.messageReply.senderID;
                    if (!data[uid]) data[uid] = 0;
                    data[uid] += money;
                    message.push(uid);
                }
                writeData(data);
                return api.sendMessage(`✅ Đã cộng thêm ${money} tiền cho ${message.length} người.`, threadID, messageID);
            }

            case "set": {
                if (mentionID.length != 0) {
                    for (let singleID of mentionID) {
                        if (isNaN(money)) return api.sendMessage('Money phải là một số', threadID, messageID);
                        data[singleID] = money;
                        message.push(singleID);
                    }
                } else {
                    if (isNaN(money)) return api.sendMessage('Money phải là một số', threadID, messageID);
                    let uid = event.senderID;
                    if (event.type == "message_reply") uid = event.messageReply.senderID;
                    data[uid] = money;
                    message.push(uid);
                }
                writeData(data);
                return api.sendMessage(`✅ Đã set thành công ${money} tiền cho ${message.length} người.`, threadID, messageID);
            }

            case "clean": {
                if (args[1] === 'all') {
                    const allUserID = Object.keys(data);
                    for (const singleUser of allUserID) {
                        data[singleUser] = 0;
                    }
                    writeData(data);
                    return api.sendMessage("✅ Đã xóa thành công toàn bộ tiền của nhóm.", threadID);
                } else {
                    if (mentionID.length != 0) {
                        for (let singleID of mentionID) {
                            data[singleID] = 0;
                            message.push(singleID);
                        }
                    } else {
                        let uid = event.senderID;
                        if (event.type == "message_reply") uid = event.messageReply.senderID;
                        data[uid] = 0;
                        message.push(uid);
                    }
                    writeData(data);
                    return api.sendMessage(`✅ Đã xóa thành công tiền của ${message.length} người.`, threadID, messageID);
                }
            }

            case "reset": {
                const allUserData = Object.keys(data);
                for (const userID of allUserData) {
                    data[userID] = 0;
                }
                writeData(data);
                return api.sendMessage(`✅ Đã reset toàn bộ tiền của ${allUserData.length} người.`, threadID, messageID);
            }

            default: {
                return api.sendMessage("Lệnh không hợp lệ.", threadID, messageID);
            }
        }
    } catch (e) {
        console.log(e);
        return api.sendMessage("Đã có lỗi xảy ra.", threadID, messageID);
    }
}
