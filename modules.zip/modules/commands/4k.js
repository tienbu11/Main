exports.config = {
 name: "4k",
 version: "1.0.0",
 hasPermssion: 0,
 credits: "NLam182",
 description: "",
 commandCategory: "tiện ích",
 usages: "[reply]",
 cooldowns: 0,
 usePrefix: false
};

exports.run = async function({ api, event, args }) {
 const fs = require('fs-extra');
 const axios = require('axios');
 const isLink = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/i.test(args[0]);
 const linkUp = event.messageReply ? event.messageReply.attachments[0].url : (isLink ? args[0] : '');

 if (!linkUp) {
 return api.sendMessage('Vui lòng reply 1 ảnh hoặc nhập link ảnh!', event.threadID, event.messageID);
 }

 try {
 let imageBuffer;

 if (isLink) {
 const response = await axios.get(linkUp, { responseType: "arraybuffer" });
 imageBuffer = Buffer.from(response.data, "binary");
 } else {
 // Upload ảnh lên Imgur
 const uploadResponse = await axios.get(`https://apibot.dungkon.me/imgur?link=${encodeURIComponent(linkUp)}&apikey=Free_1744646768`);
 const imageLink = uploadResponse.data.uploaded.image;

 
 const enhanceResponse = await axios.get(`http://43.134.186.138:3333/s4b1k/remini?input=${imageLink}`, { responseType: "arraybuffer" });
 imageBuffer = Buffer.from(enhanceResponse.data, "binary");
 }

 
 const filePath = __dirname + `/cache/netanh.png`;
 fs.writeFileSync(filePath, imageBuffer);

 
 return api.sendMessage({
 body: 'Ảnh của bạn đây!',
 attachment: fs.createReadStream(filePath)
 }, event.threadID, () => fs.unlinkSync(filePath), event.messageID);

 } catch (e) {
 console.error(e);
 return api.sendMessage('Đã xảy ra lỗi trong quá trình làm nét ảnh. Vui lòng thử lại sau.', event.threadID, event.messageID);
 }
};