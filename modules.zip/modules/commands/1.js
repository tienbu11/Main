module.exports.config = {
  name: "info",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "",
  description: "Lấy thông tin Facebook từ UID",
  commandCategory: "tiện ích",
  usages: "info [uid]",
  cooldowns: 5,
  usePrefix: false
};

module.exports.run = async function({ api, event, args }) {
  const axios = require('axios');
  const uid = args[0];

  if (!uid) {
    return api.sendMessage('Vui lòng nhập UID của người dùng!', event.threadID, event.messageID);
  }

  try {
    const apikey = 'APIKEY_FREE'; 
    const url = `https://apibot.dungkon.me/facebook/getinfo?uid=${uid}&apikey=${apikey}`;
    const response = await axios.get(url);

    const data = response.data;

    if (data.error) {
      return api.sendMessage(`Lỗi: ${data.error}`, event.threadID, event.messageID);
    }

   
    let resultMessage = `Thông tin người dùng:\n`;
    resultMessage += `- UID: ${data.uid}\n`;
    resultMessage += `- Tên: ${data.name}\n`;
    resultMessage += `- Giới tính: ${data.gender}\n`;
    resultMessage += `- Ngày sinh: ${data.birthday}\n`;
    resultMessage += `- Email: ${data.email}\n`;
    resultMessage += `- Số điện thoại: ${data.phone}\n`;
    resultMessage += `- Địa chỉ: ${data.address}\n`;
    resultMessage += `- Website: ${data.website}\n`;
    resultMessage += `- Trạng thái hôn nhân: ${data.relationship_status}\n`;

    return api.sendMessage(resultMessage, event.threadID, event.messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage('Đã xảy ra lỗi khi gọi API. Vui lòng thử lại sau.', event.threadID, event.messageID);
  }
};