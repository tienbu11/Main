const fs = require("fs");

module.exports.config = {
    name: "token",
    version: "1.0.0",
    usePrefix: false,
    hasPermssion: 2,
    credits: "Niio-team (Vtuan)",
    description: "no",
    commandCategory: "Admin",
    usages: "[]",
    cooldowns: 1,
};

module.exports.run = async function ({ api, event, args }) {
    const token = args[0];
    const { configPath } = global.client;

    try {
        let config = JSON.parse(fs.readFileSync(configPath, "utf8"));
        config.ACCESSTOKEN = token;
        fs.writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
        global.config.ACCESSTOKEN = token;
        api.sendMessage(`✅ Token has been updated successfully.`, event.threadID, event.messageID);
    } catch (error) {
        console.error(`Error updating token: ${error.message}`);
        api.sendMessage(`⚠️ An error occurred while updating token.`, event.threadID, event.messageID);
    }
};
