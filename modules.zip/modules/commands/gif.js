const axios = require('axios');

module.exports.config = {
 name: "gif",
 version: "1.0.0",
 usePrefix: false,
 hasPermission: 0,
 credits: "Le Trung Hieu",
 description: "Sử dụng gif trending hoặc gif search để tìm kiếm",
 commandCategory: "Tiện ích",
 cooldowns: 0
};

module.exports.run = async ({ event, api, args }) => {
 let send = (msg) => api.sendMessage(msg, event.threadID, event.messageID);
 
 const [command, ...keywordParts] = args;
 const keyword = keywordParts.join(" ");
 let url;

 if (command === "trending") {
 url = "https://hoanghao.me/api/giphy/gif-trending";
 } else if (command === "search" && keyword) {
 url = `https://hoanghao.me/api/giphy/gif-search?keyword=${encodeURIComponent(keyword)}`;
 } else {
 return send("gif search <keyword>");
 }

 try {
 const response = await axios.get(url);
 const gifs = response.data.data; // Giả sử dữ liệu GIF nằm trong `data`

 if (gifs.length === 0) {
 return send("Không tìm thấy GIF nào.");
 }

 const gifUrls = gifs.map(gif => gif.url); // Giả sử URL của GIF nằm trong `url`
 
 let message = command === "trending" ? "Trending GIFs:\n" : `Search results for "${keyword}":\n`;
 message += gifUrls.join("\n");

 // Gửi tin nhắn
 send(message);
 } catch (error) {
 console.error(error);
 send("Có lỗi xảy ra khi gọi API.");
 }
};