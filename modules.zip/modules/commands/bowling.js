const fs = require('fs');
const path = require('path');
const axios = require('axios');

module.exports.config = {
    name: "bowling",
    version: "1.0.0",
    hasPermssion: 0,
    usePrefix: false,
    credits: "Mây Trắng",
    description: "Ném bóng Bowling và đoán số Ki gỗ không bị ngã",
    commandCategory: "Trò Chơi",
    usages: "[bc/bl/bt/bx] [số tiền]",
    cooldowns: 15
};

const dataPath = path.join(__dirname, 'data', 'data.json');

const gifs = {
    0: "https://trangbel.x10.mx/truot.gif",
    1: "https://trangbel.x10.mx/1.gif",
    3: "https://trangbel.x10.mx/3.gif",
    4: "https://trangbel.x10.mx/4.gif",
    5: "https://trangbel.x10.mx/5.gif",
    6: "https://trangbel.x10.mx/6.gif"
};

function replace(int) {
    return int.toString().replace(/(.)(?=(\d{3})+$)/g, '$1,');
}

module.exports.run = async function ({ event, api, args }) {
    try {
        const { threadID, messageID, senderID } = event;
        const { sendMessage, unsendMessage } = api;


        let data;
        try {
            data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (error) {
            data = [];
        }


        const user = data.find(user => user.user_id === senderID);
        if (!user) {
            return sendMessage("Bạn chưa đăng ký. Vui lòng sử dụng lệnh @dangkytx để đăng ký.", threadID, messageID);
        }

        const name = user.full_name;
        const bet = parseInt(args[1]);
        const input = args[0]?.toLowerCase();

        if (!input || !bet || isNaN(bet)) {
            return sendMessage(`[ ❗ ] Bạn nhập sai cú pháp. Cú pháp đúng: @bowling [bc/bl/bt/bx] [số tiền]\n\nNội dung  |   Kết quả   | Tỉ lệ ăn\nBC | 2,4,6 | x2\nBL | 1,3,5 | x2\nBT | 4,5,6 | x2\nBX | 1,2,3 | x2\nBC | 0 | x3`, threadID, messageID);
        }
        if (bet < 5000) {
            return sendMessage("[ 💸 ] Bạn cần cược tối thiểu là 5,000 VND", threadID, messageID);
        }
        if (bet > user.balance) {
            return sendMessage("[ 💸 ] Bạn thiếu tiền không thể cược", threadID, messageID);
        }

        const options = ['bc', 'bl', 'bt', 'bx'];
        if (!options.includes(input)) {
            return sendMessage(`[ ❗ ] Bạn chỉ có thể chọn bc, bl, bt hoặc bx\n\nNội dung  |   Kết quả   | Tỉ lệ ăn\nBC | 2,4,6 | x2\nBL | 1,3,5 | x2\nBT | 4,5,6 | x2\nBX | 1,2,3 | x2\nBC | 0 | x3`, threadID, messageID);
        }

        sendMessage("Bắt đầu ném...", threadID, async () => {

            const pinsKnockedDown = Math.floor(Math.random() * 7);
            let win = false;
            let winAmount = 0;


            if (pinsKnockedDown === 0 && input === 'bc') {
                win = true;
                winAmount = bet * 3;
            } else if ((pinsKnockedDown === 2 || pinsKnockedDown === 4 || pinsKnockedDown === 6) && input === 'bc') {
                win = true;
                winAmount = bet * 2;
            } else if ((pinsKnockedDown === 1 || pinsKnockedDown === 3 || pinsKnockedDown === 5) && input === 'bl') {
                win = true;
                winAmount = bet * 2;
            } else if ((pinsKnockedDown === 4 || pinsKnockedDown === 5 || pinsKnockedDown === 6) && input === 'bt') {
                win = true;
                winAmount = bet * 2;
            } else if ((pinsKnockedDown === 1 || pinsKnockedDown === 2 || pinsKnockedDown === 3) && input === 'bx') {
                win = true;
                winAmount = bet * 2;
            }

            if (win) {
                user.balance += winAmount;
            } else {
                user.balance -= bet;
            }


            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));


            let msg;
            if (pinsKnockedDown === 0) {
                msg = `Lêu lêu ném hụt rồi kìa 🫣\nSố dư: -${replace(bet)} VNĐ 💵\nSố dư khả dụng: ${replace(user.balance)} VNĐ 🏦`;
            } else if (win) {
                if (pinsKnockedDown === 6) {
                    msg = `Chính xác 💯\nSố dư: +${replace(winAmount)} VNĐ 💵\nSố dư khả dụng: ${replace(user.balance)} VNĐ 🏦`;
                } else {
                    msg = `Chính xác\nSố dư: +${replace(winAmount)} VNĐ 💵\nSố dư khả dụng: ${replace(user.balance)} VNĐ 🏦`;
                }
            } else {
                msg = `Đoán sai rồi cưng 🤣\nSố dư: -${replace(bet)} VNĐ 💵\nSố dư khả dụng: ${replace(user.balance)} VNĐ 🏦`;
            }

            const attachments = [await axios.get(gifs[pinsKnockedDown], { responseType: 'stream' }).then(response => response.data)];

            sendMessage({ body: msg, attachment: attachments }, threadID, (err, info) => {
                if (err) return console.error(err);
                setTimeout(() => {
                    unsendMessage(info.messageID);
                }, 10000); 
            });
        });
    } catch (e) {
        console.error(e);
        sendMessage("[ ❗ ] Đã xảy ra lỗi, vui lòng thử lại sau", threadID, messageID);
    }
};