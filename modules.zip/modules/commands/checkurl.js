const axios = require('axios');

exports.config = {
  name: 'checkurl',
usePrefix: false,
  version: '1.0.0',
  hasPermssion: 0,
  credits: '',
  description: 'Kiểm tra thông tin từ URL',
  commandCategory: 'Nhóm',
  usages: 'checkurl <URL>',
  cooldowns: 5
};

exports.run = async function({ api, event, args }) {
  const apiKey = '69b45662864c466e89a628162900b32c';
  const urlToCheck = args[0];

  if (!urlToCheck) {
    api.sendMessage('Vui lòng cung cấp URL.', event.threadID, event.messageID);
    return;
  }

  const url = `https://scrape.abstractapi.com/v1/?api_key=${apiKey}&url=${encodeURIComponent(urlToCheck)}`;

  try {
    const response = await axios.get(url);
    const data = response.data;

    let resultMessage = `Thông tin từ URL ${urlToCheck}:\n`;
    resultMessage += `- Tiêu đề: ${data.title ? data.title : 'Không xác định'}\n`;
    resultMessage += `- Mô tả: ${data.description ? data.description : 'Không xác định'}\n`;
    resultMessage += `- Từ khóa: ${data.keywords ? data.keywords.join(', ') : 'Không xác định'}\n`;
    resultMessage += `- Hình ảnh: ${data.image ? data.image : 'Không xác định'}\n`;

    api.sendMessage(resultMessage, event.threadID, event.messageID);
  } catch (error) {
    console.error('Error fetching URL data:', error);
    api.sendMessage('Có lỗi xảy ra khi kiểm tra URL. Vui lòng thử lại sau.', event.threadID, event.messageID);
  }
};
