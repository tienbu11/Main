const moment = require('moment-timezone');
const fs = require('fs');
const path = require('path');

module.exports.config = {
  name: 'checksendnoti',
  version: '1.0.0',
  usePrefix: false,
  hasPermission: 2,
  credits: 'Mây Trắng',
  description: 'Đặt thời gian gửi thông báo tương tác/bật/tắt/xóa chế độ tự động gửi thông báo.',
  commandCategory: 'Hệ thống',
  usages: '[giờ:phút:giây/on/off/clear]',
  cooldowns: 5,
  dependencies: {
    "moment-timezone": "",
    "fs": "",
  }
};

const notificationTimesFile = path.join(__dirname, 'notificationTimes.json');

const loadNotificationTimes = () => {
  if (fs.existsSync(notificationTimesFile)) {
    return JSON.parse(fs.readFileSync(notificationTimesFile));
  } else {
    return { times: [], enabled: false };
  }
};

const saveNotificationTimes = (data) => {
  fs.writeFileSync(notificationTimesFile, JSON.stringify(data, null, 4));
};

module.exports.onLoad = ({ api }) => {
  if (!fs.existsSync(notificationTimesFile)) {
    saveNotificationTimes({ times: [], enabled: false });
  }
  setInterval(async () => {
    const notificationData = loadNotificationTimes();
    const currentTime = moment().tz('Asia/Ho_Chi_Minh').format('HH:mm:ss');
    console.log(`Checking notifications at ${currentTime}`);
    
    if (notificationData.enabled && notificationData.times.includes(currentTime)) {
      const message = `Dậy Tương Tác Đi Các Trùm ${currentTime}`;
      if (global.data.allThreadID && global.data.allThreadID.length > 0) {
        for (const threadID of global.data.allThreadID) {
          console.log(`Sending message to thread ${threadID} at ${currentTime}`);
          api.sendMessage(message, threadID, (err) => {
            if (err) {
              console.error(`Failed to send message to thread ${threadID}: ${err}`);
            } else {
              console.log(`Message sent successfully to thread ${threadID}`);
            }
          });
        }
      } else {
        console.log('Không có threadID để gửi thông báo.');
      }
    }
  }, 1000);
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID } = event;
  const notificationData = loadNotificationTimes();
  
  if (args.length === 0) {
    return api.sendMessage("Bạn cần nhập lệnh [giờ:phút:giây/on/off/clear]", threadID, messageID);
  }

  const command = args[0].toLowerCase();

  if (command === 'on') {
    notificationData.enabled = true;
    saveNotificationTimes(notificationData);
    return api.sendMessage("Chế độ tự động gửi thông báo đã được bật.", threadID, messageID);
  } 

  if (command === 'off') {
    notificationData.enabled = false;
    saveNotificationTimes(notificationData);
    return api.sendMessage("Chế độ tự động gửi thông báo đã được tắt.", threadID, messageID);
  } 

  if (command === 'clear') {
    notificationData.times = [];
    saveNotificationTimes(notificationData);
    return api.sendMessage("Đã xóa tất cả thời gian gửi thông báo.", threadID, messageID);
  } 

  const timePattern = /^([01]\d|2[0-3]):([0-5]\d):([0-5]\d)$/;
  if (timePattern.test(command)) {
    if (!notificationData.times.includes(command)) {
      notificationData.times.push(command);
      saveNotificationTimes(notificationData);
      return api.sendMessage(`Đã thêm thời gian gửi thông báo: ${command}`, threadID, messageID);
    } else {
      return api.sendMessage(`Thời gian ${command} đã tồn tại trong danh sách thông báo.`, threadID, messageID);
    }
  }

  return api.sendMessage("Lệnh không hợp lệ. Vui lòng nhập [giờ:phút:giây/on/off/clear]", threadID, messageID);
};