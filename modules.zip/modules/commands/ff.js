const axios = require('axios');

module.exports.config = {
  name: "ff",
  version: "1.0.0",
  hasPermission: 0,
  usePrefix: false,
  credits: "Mây Trắng",
  description: "Lấy thông tin chi tiết của tài khoản Free Fire qua ID",
  commandCategory: "tiện ích",
  usages: "ff [ID Tài khoản Free Fire]",
  cooldowns: 5,
};

module.exports.run = async function({ api, event, args }) {
  if (!args[0]) {
    return api.sendMessage("Vui lòng nhập ID của tài khoản Free Fire.", event.threadID);
  }

  const ffId = args[0];
  const apiUrl = `https://trangbel.x10.mx/ff.php?region=&uid=&key=maytrang&uid=${ffID}`;

  try {
    const response = await axios.get(apiUrl);
    const data = response.data;

    if (data && data.basicInfo) {
      const info = data.basicInfo;
      const socialInfo = data.socialInfo || {};
      const captainInfo = data.captainBasicInfo || {};
      const creditInfo = data.creditScoreInfo || {};
      const petInfo = data.petInfo || {};
      const clanInfo = data.clanBasicInfo || {};

      let resultMessage = "THÔNG TIN TÀI KHOẢN:\n";

      resultMessage += "┌ 👤 THÔNG TIN CƠ BẢN\n";
      resultMessage += `├─ Tên: ${info.nickname}\n`;
      resultMessage += `├─ ID: ${info.accountId}\n`;
      resultMessage += `├─ Level: ${info.level} (Exp: ${info.exp})\n`;
      resultMessage += `├─ Khu vực: ${info.region}\n`;
      resultMessage += `├─ Like: ${info.liked}\n`;

      if (socialInfo.gender) {
        const genderText = socialInfo.gender === 'Gender_FEMALE' ? 'Nữ' : socialInfo.gender === 'Gender_MALE' ? 'Nam' : 'Không xác định';
        resultMessage += `├─ Giới tính: ${genderText}\n`;
      }

      resultMessage += `├─ Uy Tín: ${creditInfo.creditScore || 'Không có'}\n`;
      resultMessage += `└─ Chữ ký: ${socialInfo.signature || 'Không có'}\n\n`;

      resultMessage += "┌ 🎮 HOẠT ĐỘNG CỦA TÀI KHOẢN\n";
      resultMessage += `├─ Số huy hiệu BP: ${info.badgeCnt}\n`;
      resultMessage += `├─ Ngày tạo: ${new Date(parseInt(info.createAt) * 1000).toLocaleString('vi-VN')}\n`;
      resultMessage += `└─ Lần đăng nhập cuối: ${new Date(parseInt(info.lastLoginAt) * 1000).toLocaleString('vi-VN')}\n\n`;

      if (petInfo.name) {
        resultMessage += "┌ 🐾 THÔNG TIN PET\n";
        resultMessage += `├─ Tên: ${petInfo.name}\n`;
        resultMessage += `├─ EXP Pet: ${petInfo.exp}\n`;
        resultMessage += `└─ Level Pet: ${petInfo.level}\n\n`;
      }

      if (clanInfo.clanName) {
        resultMessage += "┌ 🛡️ QUÂN ĐOÀN\n";
        resultMessage += `├─ Tên: ${clanInfo.clanName}\n`;
        resultMessage += `├─ ID: ${clanInfo.clanId}\n`;
        resultMessage += `├─ Level: ${clanInfo.clanLevel}\n`;
        resultMessage += `├─ Thành viên: ${clanInfo.memberNum}\n`;
        resultMessage += `└─ CHỦ QUÂN ĐOÀN:\n`;
        resultMessage += `    ├─ Tên: ${captainInfo.nickname}\n`;
        resultMessage += `    ├─ ID: ${captainInfo.accountId}\n`;
        resultMessage += `    ├─ Level: ${captainInfo.level} (Exp: ${captainInfo.exp})\n`;
        resultMessage += `    ├─ Ngày tạo: ${new Date(parseInt(captainInfo.createAt) * 1000).toLocaleString('vi-VN')}\n`;
        resultMessage += `    └─ Lần đăng nhập cuối: ${new Date(parseInt(captainInfo.lastLoginAt) * 1000).toLocaleString('vi-VN')}\n`;
      }

      api.sendMessage(resultMessage, event.threadID);
    } else {
      api.sendMessage("Không tìm thấy thông tin hoặc có lỗi xảy ra.", event.threadID);
    }
  } catch (error) {
    console.error(error);
    api.sendMessage("Có lỗi xảy ra khi lấy thông tin tài khoản.", event.threadID);
  }
};