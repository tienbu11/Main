const axios = require('axios');
const fs = require('fs-extra');
const dl = require("soundcloud-downloader").default;
const cheerio = require("cheerio");

exports.config = {
    name: 'scl',
    version: '1.0.0',
    credits: '',
    hasPermssion: 0,
    usePrefix: false,
    description: '',
    commandCategory: 'Tiện ích',
    usages: '[]',
    cooldowns: 5,
};

exports.run = async function ({ api, event, args }) {
    const { threadID: tid, messageID: mid, senderID: sid } = event;
    const command = args[0];
    const argument = args.slice(1).join(" ");
    const send = (msg, callback) => api.sendMessage(msg, tid, callback, mid);

    switch (command) {
        case 'info':
            await handleInfo(api, tid, mid, argument);
            break;
        case 'search':
            await handleSearch(api, tid, mid, sid, argument, send);
            break;
        default:
            await handleDefault(api, tid, mid);
            break;
    }
};

async function handleInfo(api, tid, mid, infoUrl) {
    if (!infoUrl) {
        return api.sendMessage("❎ Vui lòng nhập tên bài hát!", tid, mid);
    }

    try {
        const trackInfo = await dl.getInfo(infoUrl);
        const title = trackInfo.title || 'Không có thông tin';
        const artist = trackInfo.user.username || 'Không có thông tin';
        const playCount = trackInfo.playback_count || 'Không có thông tin';
        const likes = trackInfo.likes_count || 'Không có thông tin';
        const duration = trackInfo.duration ? `${Math.floor(trackInfo.duration / 60000)} phút ${Math.floor((trackInfo.duration % 60000) / 1000)} giây` : 'Không có thông tin';
        const releaseDate = trackInfo.release_date || 'Không có thông tin';
        const link = trackInfo.permalink_url || 'Không có thông tin';
        const created_at = trackInfo.created_at || 'Không có thông tin';
        const download_count = trackInfo.download_count || 'Không có thông tin';

        //created_at
        const artworkUrl = trackInfo.artwork_url ? trackInfo.artwork_url.replace('-large', '-original') : 'Không có thông tin';

        const attachment = artworkUrl !== 'Không có thông tin' ? (await axios.get(artworkUrl, { responseType: 'stream' })).data : null;

        api.sendMessage({
            body: `Thông tin bài hát từ SoundCloud:\n- Tiêu đề: ${title}\n- Nghệ sĩ: ${artist}\n- Số lượt nghe: ${playCount}\n- Số lượt thích: ${likes}\n- Thời lượng: ${duration}\n- Ngày phát hành: ${releaseDate}\n- Link bài hát: ${link}`,
            attachment: attachment
        }, tid, mid);
    } catch (error) {
        console.error("Error fetching track info:", error);
        api.sendMessage("❎ Không thể lấy thông tin bài hát từ URL này.", tid, mid);
    }
}

async function handleSearch(api, tid, mid, sid, query, send) {
    if (!query) {
        return send("❎ Vui lòng nhập tên bài hát!");
    }

    const headers = {
        Accept: "application/json",
        "Accept-Language": "en-US,en;q=0.9,vi;q=0.8",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36",
    };

    try {
        const response = (await axios.get(`https://m.soundcloud.com/search?q=${encodeURIComponent(query)}`, { headers })).data;
        const $ = cheerio.load(response);
        let data = [];

        $("div > ul > li > div").each(function (index, element) {
            if (index < 10) {
                const title = $(element).find("a").attr("aria-label")?.trim() || "";
                const url = "https://soundcloud.com" + ($(element).find("a").attr("href") || "").trim();
                const thumb = $(element).find("a > div > div > div > picture > img").attr("src")?.trim() || "";
                const artist = $(element).find("a > div > div > div").eq(1).text()?.trim() || "";
                const views = $(element).find("a > div > div > div > div > div").eq(0).text()?.trim() || "";
                const timestamp = $(element).find("a > div > div > div > div > div").eq(1).text()?.trim() || "";
                const release = $(element).find("a > div > div > div > div > div").eq(2).text()?.trim() || "";
                data.push({
                    title,
                    url,
                    thumb,
                    artist,
                    views,
                    release,
                    timestamp,
                });
            }
        });

        if (data.length === 0) return send("❎ Không tìm thấy bài hát nào!");

        let d = data.map((r, i) => `${i + 1}. 👤 Tên: ${r.artist}\n📝 Tiêu đề: ${r.title}\n⌛ Thời lượng: ${r.timestamp}\n`).join("\n");
        const attachment = await Promise.all(data.map(i => i.thumb).filter(i => i !== "").map(async i => (await axios.get(i, { responseType: "stream" })).data));

        send({ body: `Đây là danh sách tìm kiếm của từ khoá: ${query}\n\n${d}\n📌 Reply (phản hồi) theo STT tương ứng để tải nhạc`, attachment }, (e, i) => {
            global.client.handleReply.push({
                name: exports.config.name,
                messageID: i.messageID,
                author: sid,
                data
            });
        });
    } catch (e) {
        send("❎ Có lỗi xảy ra!");
    }
}

async function handleDefault(api, tid, mid) {
    api.sendMessage({body:``,attachment: (await require("axios").get(`https://files.catbox.moe/a03ejb.png`, { responseType: "stream" })).data} ,tid, mid);
}

global.client.handleReply = global.client.handleReply || [];
global.client.handleReply.push({
    name: exports.config.name,
    messageID: "",
    author: "",
    data: []
});

exports.handleReply = async function(o) {
    const { threadID: t, messageID: m, senderID: s, body: b } = o.event;
    const _ = o.handleReply;
    const send = msg => o.api.sendMessage(msg, t, m);

    if (s !== _.author) return send("❎ Không phải người dùng lệnh!");

    o.api.unsendMessage(_.messageID);
    const choose = parseInt(b);

    if (!isNaN(choose)) {
        if (choose >= 1 && choose <= _.data.length) {
            try {
                const stream = await dl.download(_.data[choose - 1].url);
                const filePath = `${__dirname}/cache/scl.mp3`;
                stream.pipe(fs.createWriteStream(filePath));
                setTimeout(() => send({ body: `[ SOUNDCLOUD ]\n👤 Tên: ${_.data[choose - 1].artist}\n📝 Tiêu đề: ${_.data[choose - 1].title}\n⌛ Thời lượng: ${_.data[choose - 1].timestamp}\n📺 Lượt xem: ${_.data[choose - 1].views}\n📌 Link: ${_.data[choose - 1].url}`, attachment: fs.createReadStream(filePath) }), 5000);
            } catch (e) {
                send("❎ Có lỗi xảy ra!");
            }
        } else {
            return send("❎ Lựa chọn không nằm trong danh sách");
        }
    } else {
        return send("❎ Vui lòng chọn 1 con số");
    }
};