const axios = require('axios');
const request = require('request');

module.exports.config = {
    name: "kick",
    version: "1.0.0",
    hasPermssion: 1,
    usePrefix: true,
    credits: "D-Jukie",
    description: "Xoá người bạn cần xoá khỏi nhóm bằng cách tag hoặc reply",
    commandCategory: "Qtv",
    usages: "[tag/reply/all]",
    cooldowns: 0
};

module.exports.run = async function ({ args, api, event, Threads }) {
    try {
        const threadInfo = (await Threads.getData(event.threadID)).threadInfo;
        const botID = api.getCurrentUserID();

        
        if (args.join().indexOf('@') !== -1) {
            const mention = Object.keys(event.mentions);
            for (let o in mention) {
                setTimeout(() => {
                    api.removeUserFromGroup(mention[o], event.threadID);
                }, 1000);
            }
            return;
        }

        
        if (event.type === "message_reply") {
            const uid = event.messageReply.senderID;
            api.removeUserFromGroup(uid, event.threadID);
            return;
        }

        
        if (args[0] === "all") {
            const listUserID = threadInfo.participantIDs.filter(ID => ID != botID && ID != event.senderID);
            for (let idUser of listUserID) {
                setTimeout(() => {
                    api.removeUserFromGroup(idUser, event.threadID);
                }, 1000);
            }
            return;
        }

        
        api.sendMessage({
            body: 'Vui lòng tag hoặc reply người cần kick',
            attachment: global.a.splice(0, 1)
        }, event.threadID, event.messageID);

    } catch (error) {
        console.log(error);
        api.sendMessage('❎ Đã xảy ra lỗi trong quá trình thực hiện lệnh', event.threadID, event.messageID);
    }
};