const axios = require('axios');

module.exports.config = {
  name: "checkip",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "ok",
  description: "Kiểm tra thông tin IP",
  commandCategory: "Utilities",
  usages: "[IP]",
  cooldowns: 5,
  usePrefix: false
};

module.exports.run = async ({ api, event, args }) => {
  const { threadID, messageID } = event;
  const ipAddress = args.join(' ');

  if (!ipAddress) {
    return api.sendMessage('⚠️ Bạn cần cung cấp địa chỉ IP để kiểm tra.', threadID, messageID);
  }

  const apiUrl = `https://hoanghao.me/api/checkip?ip=${encodeURIComponent(ipAddress)}`;

  try {
    const response = await axios.get(apiUrl);
    const { data } = response;

    // Extracting relevant information from the response
    const { ip, city, region, country, loc, org, postal, timezone } = data;

    // Format and send the result message
    const message = `
  Thông Tin IP
------------------
- IP: ${ip}
- Thành Phố: ${city}
- Khu Vực: ${region}
- Quốc Gia: ${country}
- Vị Trí: ${loc}
- Nhà Cung Cấp: ${org}
- Mã Bưu Điện: ${postal}
- Múi Giờ: ${timezone}
------------------
`;

    return api.sendMessage(message, threadID, messageID);
  } catch (error) {
    console.error('Lỗi khi gửi yêu cầu đến API:', error);
    return api.sendMessage('⚠️ Đã xảy ra lỗi khi kiểm tra địa chỉ IP. Vui lòng thử lại sau.', threadID, messageID);
  }
};