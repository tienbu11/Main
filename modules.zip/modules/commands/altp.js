const fs = require('fs');

exports.config = {
 name: 'altp',
 version: '1.0.0',
 hasPermssion: 0,
 usePrefix: false,
 credits: 'Trung Hieu',
 description: 'Trò chơi Ai là triệu phú',
 commandCategory: 'Giải trí',
 usages: '[]',
 cooldowns: 5,
};

const questionsFilePath = './modules/commands/Game/altp.json';
const adminUIDs = ['61555809030974', '', ''];

let gameData = {};

function readQuestions() {
 if (fs.existsSync(questionsFilePath)) {
 const rawData = fs.readFileSync(questionsFilePath);
 return JSON.parse(rawData).questions;
 }
 return [];
}

function getRandomQuestion() {
 const questions = readQuestions();
 if (!questions.length) return null;
 const randomIndex = Math.floor(Math.random() * questions.length);
 return questions[randomIndex];
}

exports.run = async function ({ api, event, args }) {
 const { threadID: tid, messageID: mid, senderID: sid } = event;
 const command = args[0];
 
 switch (command) {
 case 'start':
 const question = getRandomQuestion();
 if (!question) {
 return api.sendMessage("Hiện tại chưa có câu hỏi nào trong trò chơi. Vui lòng thêm câu hỏi vào tệp altp.json.", tid, mid);
 }
 
 const questionText = `${question.question}\nA: ${question.options[0]}\nB: ${question.options[1]}\nC: ${question.options[2]}\nD: ${question.options[3]}`;
 const correctAnswer = question.answer;

 gameData[tid] = {
 answer: correctAnswer,
 active: true,
 creator: sid,
 attempts: 3,
 questionMessageID: null,
 timeout: setTimeout(() => {
 if (gameData[tid] && gameData[tid].active) {
 api.sendMessage('⏰ Hết thời gian trả lời! Trò chơi đã kết thúc.', tid, mid);
 gameData[tid].active = false;
 api.unsendMessage(gameData[tid].questionMessageID);
 delete gameData[tid];
 }
 }, 60000)
 };

 api.sendMessage(questionText, tid, (error, info) => {
 if (error) return console.error(error);
 gameData[tid].questionMessageID = info.messageID;
 global.client.handleReply.push({
 type: 'game',
 name: exports.config.name,
 author: sid,
 messageID: info.messageID,
 result: correctAnswer
 });
 });
 break;

 case 'add':
 if (!adminUIDs.includes(sid)) {
 return api.sendMessage('Bạn không có quyền thêm câu hỏi vào trò chơi.', tid, mid);
 }

 const newQuestion = args.slice(1).join(' ').trim();
 if (!newQuestion) {
 return api.sendMessage('Vui lòng cung cấp câu hỏi và các đáp án theo định dạng JSON.', tid, mid);
 }

 let newQuestionData;
 try {
 newQuestionData = JSON.parse(newQuestion);
 if (!validateQuestion(newQuestionData)) {
 return api.sendMessage('Định dạng câu hỏi không hợp lệ. Vui lòng cung cấp đúng định dạng JSON với câu hỏi, các đáp án và đáp án đúng.', tid, mid);
 }
 } catch (error) {
 return api.sendMessage('Định dạng câu hỏi không hợp lệ. Vui lòng sử dụng định dạng JSON.', tid, mid);
 }

 let questionsList = readQuestions();
 questionsList.push(newQuestionData);
 fs.writeFileSync(questionsFilePath, JSON.stringify({ questions: questionsList }, null, 2));
 api.sendMessage(`Đã thêm câu hỏi mới vào trò chơi.`, tid, mid);
 break;

 case 'del':
 if (!adminUIDs.includes(sid)) {
 return api.sendMessage('Bạn không có quyền xóa câu hỏi khỏi trò chơi.', tid, mid);
 }

 const questionToDelete = args.slice(1).join(' ').trim();
 if (!questionToDelete) {
 return api.sendMessage('Vui lòng cung cấp câu hỏi bạn muốn xóa.', tid, mid);
 }

 let questionsListToDelete = readQuestions();
 const questionIndex = questionsListToDelete.findIndex(q => q.question === questionToDelete);
 if (questionIndex === -1) {
 return api.sendMessage(`Câu hỏi "${questionToDelete}" không có trong danh sách.`, tid, mid);
 }

 questionsListToDelete.splice(questionIndex, 1);
 fs.writeFileSync(questionsFilePath, JSON.stringify({ questions: questionsListToDelete }, null, 2));
 api.sendMessage(`Đã xóa câu hỏi "${questionToDelete}" khỏi trò chơi.`, tid, mid);
 break;

 default:
 api.sendMessage('Sử dụng lệnh: start, add hoặc del', tid, mid);
 break;
 }
};

function validateQuestion(question) {
 return question && 
 typeof question.question === 'string' &&
 Array.isArray(question.options) && 
 question.options.length === 4 &&
 typeof question.answer === 'string' &&
 ['A', 'B', 'C', 'D'].includes(question.answer);
}

module.exports.handleReply = async function ({ event, api, handleReply }) {
 const { threadID: tid, messageID: mid, body, senderID } = event;
 const game = gameData[tid];

 if (!game || !game.active) {
 return api.sendMessage('❎ Không có trò chơi nào đang hoạt động hoặc trò chơi đã kết thúc.', tid, mid);
 }

 if (senderID !== game.creator) {
 return api.sendMessage('❎ Bạn không phải là người khởi tạo trò chơi này.', tid, mid);
 }

 const userAnswer = body.trim().toUpperCase();
 const correctAnswer = game.answer;

 if (userAnswer === correctAnswer) {
 api.sendMessage('✅ Chúc mừng! Bạn đã trả lời đúng.', tid, mid);
 clearTimeout(game.timeout);
 game.active = false;
 api.unsendMessage(game.questionMessageID);

 const newQuestion = getRandomQuestion();
 if (newQuestion) {
 const questionText = `${newQuestion.question}\nA: ${newQuestion.options[0]}\nB: ${newQuestion.options[1]}\nC: ${newQuestion.options[2]}\nD: ${newQuestion.options[3]}`;
 const newCorrectAnswer = newQuestion.answer;

 gameData[tid] = {
 answer: newCorrectAnswer,
 active: true,
 creator: senderID,
 attempts: 3,
 questionMessageID: null,
 timeout: setTimeout(() => {
 if (gameData[tid] && gameData[tid].active) {
 api.sendMessage('⏰ Hết thời gian trả lời! Trò chơi đã kết thúc.', tid, mid);
 gameData[tid].active = false;
 api.unsendMessage(gameData[tid].questionMessageID);
 delete gameData[tid];
 }
 }, 60000)
 };

 api.sendMessage(questionText, tid, (error, info) => {
 if (error) return console.error(error);
 gameData[tid].questionMessageID = info.messageID;
 global.client.handleReply.push({
 type: 'game',
 name: exports.config.name,
 author: senderID,
 messageID: info.messageID,
 result: newCorrectAnswer
 });
 });
 }
 } else {
 game.attempts--;
 if (game.attempts <= 0) {
 clearTimeout(game.timeout);
 api.sendMessage(`❎ Bạn đã hết lượt trả lời. Đáp án đúng là: ${correctAnswer}`, tid, mid);
 game.active = false;
 api.unsendMessage(game.questionMessageID);
 delete gameData[tid];
 } else {
 api.sendMessage(`❎ Sai rồi! Bạn còn ${game.attempts} lượt trả lời.`, tid, mid);
 }
 }
};