const axios = require('axios');
const { createCanvas, loadImage } = require('canvas');

const config = {
    name: 'cotuong',
    version: '0.0.1',
    hasPermssion: 0,
    credits: 'hiếu',
    description: '',
    commandCategory: 'Game',
    usages: '[]',
    cooldowns: 3,
    usePrefix: false
};

const piece_url_images = {
    'r': 'https://upload.wikimedia.org/wikipedia/commons/e/e3/Chinese_chess_red_generals.svg',
    'k': 'https://upload.wikimedia.org/wikipedia/commons/f/f1/Chinese_chess_black_generals.svg',
    'c': 'https://upload.wikimedia.org/wikipedia/commons/e/e1/Chinese_chess_red_cannon.svg',
    'p': 'https://upload.wikimedia.org/wikipedia/commons/9/97/Chinese_chess_red_pawns.svg',
    'n': 'https://upload.wikimedia.org/wikipedia/commons/1/15/Chinese_chess_red_horses.svg',
    'b': 'https://upload.wikimedia.org/wikipedia/commons/d/d6/Chinese_chess_red_elephants.svg',
    'a': 'https://upload.wikimedia.org/wikipedia/commons/c/cf/Chinese_chess_red_advisors.svg',
    'R': 'https://upload.wikimedia.org/wikipedia/commons/c/cf/Chinese_chess_black_advisors.svg',
    'K': 'https://upload.wikimedia.org/wikipedia/commons/f/f0/Chinese_chess_black_generals.svg',
    'C': 'https://upload.wikimedia.org/wikipedia/commons/0/02/Chinese_chess_black_cannon.svg',
    'P': 'https://upload.wikimedia.org/wikipedia/commons/3/3b/Chinese_chess_black_pawns.svg',
    'N': 'https://upload.wikimedia.org/wikipedia/commons/e/e8/Chinese_chess_black_horses.svg',
    'B': 'https://upload.wikimedia.org/wikipedia/commons/f/f6/Chinese_chess_black_elephants.svg',
    'A': 'https://upload.wikimedia.org/wikipedia/commons/9/93/Chinese_chess_black_advisors.svg',
};

const piece_letters = Object.keys(piece_url_images);
let piece_images = {};

async function loadPieceImages() {
    const promises = piece_letters.map(letter => loadImage(piece_url_images[letter]));
    const images = await Promise.all(promises);
    piece_images = images.reduce((acc, img, idx) => {
        acc[piece_letters[idx]] = img;
        return acc;
    }, {});
}

async function drawChineseChessBoard(chess) {
    await loadPieceImages();

    const canvas = createCanvas(500, 500);
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.strokeStyle = '#000';
    ctx.lineWidth = 2;

    for (let i = 0; i < 10; i++) {
        ctx.moveTo(50, 50 + i * 50);
        ctx.lineTo(450, 50 + i * 50);
    }
    for (let j = 0; j < 9; j++) {
        ctx.moveTo(50 + j * 50, 50);
        ctx.lineTo(50 + j * 50, 500);
    }
    ctx.stroke();

    chess.board().forEach((row, i) => {
        row.forEach((piece, j) => {
            if (piece) {
                ctx.drawImage(piece_images[piece.type.toLowerCase()], 50 + j * 50, 50 + i * 50, 50, 50);
            }
        });
    });

    return canvas.toBuffer();
}

exports.config = config;

exports.run = async ({ api, event }) => {
    const chess = new ChineseChess();
    const buffer = await drawChineseChessBoard(chess);

    const attachment = await api.sendMessage({
        body: 'Bàn cờ tướng hiện tại:',
        attachment: buffer
    }, event.threadID, event.messageID);

    return attachment;
};

exports.handleReply = async ({ api, event, handleReply }) => {
    
};
