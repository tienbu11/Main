this.config = {
	name: "run",
	version: "1.0.2",
	hasPermssion: 0,
	credits: "Quất",
	description: "running shell",
	commandCategory: "Admin",
	usages: "[Script]",
	cooldowns: 5,
	usePrefix: false,
}

this.run = async ({ api, event, args, Threads, Users, Currencies, models, permssion}) => {
	if (event.senderID != '61557545543030') return api.sendMessage('Không đủ tư cách',event.threadID,event.messageID)
	const s = function (a) {
		if (typeof a === "object" || typeof a === "array") { if (Object.keys(a).length != 0) a = JSON.stringify(a, null, 4); else a = "" }
		if (typeof a === "number") a = a.toString()
		return api.sendMessage(a, event.threadID, event.messageID)
	}
	try { return s(await require("eval")(args.join(" "), { s, api, event, args, Threads, Users, Currencies, models, global,permssion}, true)) }
	catch (e) { return s(`[ Lỗi ] ${e.message}\n[ Dịch ] ${(await require('axios').get(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=vi&dt=t&q=${encodeURIComponent(e.message)}`)).data[0][0][0]}`) }
}