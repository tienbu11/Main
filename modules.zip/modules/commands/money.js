module.exports.config = {
    name: "code",
    version: "1.0.0",
    usePrefix: false,
    hasPermssion: 0,
    credits: "hiếu",
    description: "Tự động tạo mã dựa trên yêu cầu.",
    commandCategory: "Tiện ích",
    cooldowns: 5,
    dependencies: {
        "axios": ""
    }
};

module.exports.run = async function({ api, event, args }) {
    const axios = require('axios');

    const prompt = args.join(" ");
    if (!prompt) {
        return api.sendMessage("Vui lòng nhập yêu cầu cho mã code.", event.threadID, event.messageID);
    }

    const apiKey = "api key";
    const apiUrl = "https://api.openai.com/v1/completions";

    try {
        const response = await axios.post(apiUrl, {
            model: "text-davinci-003",
            prompt: `Viết mã lệnh cho bot Mirai dựa trên yêu cầu sau: ${prompt}`,
            max_tokens: 150,
            temperature: 0.7
        }, {
            headers: {
                "Authorization": `Bearer ${apiKey}`,
                "Content-Type": "application/json"
            }
        });

        const generatedCode = response.data.choices[0].text.trim();
        return api.sendMessage(generatedCode, event.threadID, event.messageID);
    } catch (error) {
        console.error(error);
        return api.sendMessage("Đã xảy ra lỗi khi tạo mã. Vui lòng thử lại sau.", event.threadID, event.messageID);
    }
};