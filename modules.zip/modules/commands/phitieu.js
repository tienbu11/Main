const fs = require('fs');
const path = require('path');
const axios = require('axios');

module.exports.config = {
    name: "phitieu",
    version: "1.0.0",
    hasPermssion: 0,
    usePrefix: false,
    credits: "Mây Trắng",
    description: "Ném phi tiêu và đoán kết quả",
    commandCategory: "Trò Chơi",
    usages: "[trang/do/tam] [số tiền]",
    cooldowns: 15
};

const dataPath = path.join(__dirname, 'data', 'data.json');

const gifs = {
    trượt: "https://trangbel.x10.mx/phitieu/truot.gif",
    tâm: "https://trangbel.x10.mx/phitieu/tam.gif",
    đỏ: "https://trangbel.x10.mx/phitieu/red.gif",
    đỏ2: "https://trangbel.x10.mx/phitieu/red1.gif",
    trắng: "https://trangbel.x10.mx/phitieu/white.gif",
    trắng2: "https://trangbel.x10.mx/phitieu/white1.gif"
};

function replace(int) {
    return int.toString().replace(/(.)(?=(\d{3})+$)/g, '$1,');
}

module.exports.run = async function ({ event, api, args }) {
    try {
        const { threadID, messageID, senderID } = event;
        const { sendMessage, unsendMessage } = api;

        
        let data;
        try {
            data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (error) {
            data = [];
        }

        
        const user = data.find(user => user.user_id === senderID);
        if (!user) {
            return sendMessage("Bạn chưa đăng ký. Vui lòng sử dụng lệnh @dangkytx để đăng ký.", threadID, messageID);
        }

        const name = user.full_name;
        const bet = parseInt(args[1]);
        const input = args[0]?.toLowerCase();

        if (!input || !bet || isNaN(bet)) {
            return sendMessage(`[ ❗ ] Bạn nhập sai cú pháp. Cú pháp đúng: @phitieu [trang/do/tam] [số tiền]\n\nNội dung  |   Kết quả   | Tỉ lệ ăn\ntrang | Vòng Trắng | x2\ndo | Vòng Đỏ | x2\ntam | Tâm Của Bia | x2.5`, threadID, messageID);
        }
        if (bet < 5000) {
            return sendMessage("[ 💸 ] Bạn cần cược tối thiểu là 5,000 VND", threadID, messageID);
        }
        if (bet > user.balance) {
            return sendMessage("[ 💸 ] Bạn thiếu tiền không thể cược", threadID, messageID);
        }

        const options = ['trang', 'do', 'tam'];
        if (!options.includes(input)) {
            return sendMessage(`[ ❗ ] Bạn chỉ có thể chọn trang, do hoặc tam\n\nNội dung  |   Kết quả   | Tỉ lệ ăn\ntrang | Vòng Trắng | x2\ndo | Vòng Đỏ | x2\ntam | Tâm Của Bia | x2.5`, threadID, messageID);
        }

        sendMessage("Bắt đầu ném...", threadID, async () => {
            
            const outcomes = ['trượt', 'trắng', 'trắng2', 'đỏ', 'đỏ2', 'tâm'];
            const result = outcomes[Math.floor(Math.random() * outcomes.length)];
            let win = false;
            let winAmount = 0;
            let msg = '';

            if (result === 'trượt') {
                user.balance -= bet;
                msg = `Phi tiêu ném trượt tiền được ném chính xác vào nhà cái 👉👈\nSố tiền thua: ${replace(bet)} VNĐ\nSố dư: ${replace(user.balance)} VNĐ`;
            } else if (result === 'tâm') {
                if (input === 'tam') {
                    win = true;
                    winAmount = bet * 2.5;
                    user.balance += winAmount;
                    msg = `Ném quá đẹp✨ Số dư: +${replace(winAmount)} VNĐ.\nSố dư khả dụng: ${replace(user.balance)} VNĐ 🏦`;
                } else {
                    user.balance -= bet;
                    msg = `10đ ném đẹp nhưng đoán sai rùi 👽 \nSố tiền thua: ${replace(bet)} VNĐ\nSố dư: ${replace(user.balance)} VNĐ`;
                }
            } else if ((result === 'trắng' || result === 'trắng2') && input === 'trang') {
                win = true;
                winAmount = bet * 2;
                user.balance += winAmount;
                msg = `Chính xác! Số dư: +${replace(winAmount)} VNĐ 💵\nSố dư khả dụng: ${replace(user.balance)} VNĐ 🏦`;
            } else if ((result === 'đỏ' || result === 'đỏ2') && input === 'do') {
                win = true;
                winAmount = bet * 2;
                user.balance += winAmount;
                msg = `Chính xác! Số dư: +${replace(winAmount)} VNĐ 💵\nSố dư khả dụng: ${replace(user.balance)} VNĐ 🏦`;
            } else {
                user.balance -= bet;
                msg = `Bạn đoán sai rùi🥲\nSố dư: -${replace(bet)} VNĐ\nSố dư khả dụng: ${replace(user.balance)} VNĐ 🏦`;
            }

            
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

            
            const attachment = await axios.get(gifs[result], { responseType: 'stream' }).then(response => response.data);

            sendMessage({ body: msg, attachment }, threadID, (err, info) => {
                if (err) return console.error(err);
                setTimeout(() => {
                    unsendMessage(info.messageID);
                }, 10000);
            });
        });

    } catch (e) {
        console.error(e);
        sendMessage("[ ❗ ] Đã xảy ra lỗi, vui lòng thử lại sau", threadID, messageID);
    }
};