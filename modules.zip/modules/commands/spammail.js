const nodemailer = require('nodemailer');

module.exports.config = {
    name: "spammail",
    usePrefix: false,
    version: "3.0.0",
    hasPermssion: 2,
    credits: "Trung Hieu",
    description: "Spam email đến một địa chỉ cụ thể",
    commandCategory: "Tiện ích",
    usages: "spammail [email] [nội dung] [số lượng] | stop",
    cooldowns: 5
};

let activeSpam = {};

module.exports.run = async ({ api, event, args }) => {
    const { threadID, messageID } = event;

    if (args[0] === 'stop') {
        if (activeSpam[threadID]) {
            clearInterval(activeSpam[threadID]);
            delete activeSpam[threadID];
            return api.sendMessage("Đã dừng spam email.", threadID, messageID);
        } else {
            return api.sendMessage("Không có quá trình spam email nào đang chạy.", threadID, messageID);
        }
    }

    const email = args[0];
    const content = args[1];
    const count = parseInt(args[2]);

    if (!email || !content || isNaN(count)) {
        return api.sendMessage("Vui lòng nhập đúng định dạng: spammail [email] [nội dung] [số lượng]", threadID, messageID);
    }

    let transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'gmail',
            pass: 'passs'
        }
    });

    let sentEmails = 0;
    let successCount = 0;
    let failureCount = 0;

    activeSpam[threadID] = setInterval(() => {
        if (sentEmails >= count) {
            clearInterval(activeSpam[threadID]);
            delete activeSpam[threadID];
            return api.sendMessage(`Hoàn tất gửi ${count} email đến ${email}.\nThành công: ${successCount}\nThất bại: ${failureCount}`, threadID, messageID);
        }

        let mailOptions = {
            from: 'youremail@gmail.com',
            to: email,
            subject: `Spam email ${sentEmails + 1}`,
            text: content
        };

        transporter.sendMail(mailOptions, (error, info) => {
            sentEmails++;
            if (error) {
                failureCount++;
                api.sendMessage(`Email ${sentEmails} thất bại: ${error.message}`, threadID, messageID);
            } else {
                successCount++;
                api.sendMessage(`Email ${sentEmails} đã gửi thành công: ${info.response}`, threadID, messageID);
            }
        });
    }, 1000);

    return api.sendMessage(`Đang gửi ${count} email đến ${email} với nội dung: ${content}`, threadID, messageID);
};
