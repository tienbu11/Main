const axios = require('axios');

exports.config = {
 name: 'ig',
 version: '1.0.0',
 hasPermssion: 0,
 usePrefix: false,
 credits: 'Trung Hieu',
 description: 'Lấy thông tin từ Instagram',
 commandCategory: 'Tiện ích',
 usages: '[]',
 cooldowns: 5,
};

const API_KEY = 'HARIN'; 

exports.run = async function ({ api, event, args }) {
 const { threadID: tid, messageID: mid, senderID: sid } = event;
 const command = args[0];
 const argument = args.slice(1).join(" ");

 switch (command) {
 case 'download':
 const url = argument;
 if (!url) {
 return api.sendMessage("Vui lòng cung cấp URL bài viết!", tid, mid);
 }
 try {
 const response = await axios.get(`https://api.phungtuanhai.site/api/instagram/dlpost?apikey=${API_KEY}&url=${encodeURIComponent(url)}`);
 const data = response.data;
 console.log(data); // Log data để kiểm tra
 if (data.error) {
 return api.sendMessage("❎ URL không hợp lệ hoặc có lỗi xảy ra.", tid, mid);
 }
 api.sendMessage({
 body: `Tải xuống bài viết Instagram:\n- Tiêu đề: ${data.title}\n- Người đăng: ${data.username}\n- Số lượt thích: ${data.likes}\n- Số lượt bình luận: ${data.comments}\n- Link bài viết: ${data.link}`,
 attachment: await streamURL(data.media[0], 'jpg')
 }, tid, mid);
 } catch (error) {
 console.error(error);
 api.sendMessage("❎ Không thể tải bài viết từ URL này.", tid, mid);
 }
 break;

 case 'info':
 const username = argument;
 if (!username) {
 return api.sendMessage("Vui lòng cung cấp tên người dùng Instagram!", tid, mid);
 }
 try {
 const response = await axios.get(`https://api.phungtuanhai.site/api/instagram/info?apikey=${API_KEY}&username=${username}`);
 const data = response.data[0]; // Dữ liệu trả về là một mảng

 // Kiểm tra xem các trường dữ liệu có tồn tại không
 const fullName = data.full_name || 'Chưa có thông tin';
 const userName = data.username || 'Chưa có thông tin';
 const posts = data.media_count || 'Chưa có thông tin';
 const followers = data.follower_count || 'Chưa có thông tin';
 const following = data.following_count || 'Chưa có thông tin';
 const biography = data.biography || 'Chưa có thông tin';
 const profilePic = data.profile_pic_url_hd || 'https://files.catbox.moe/1rybcw.jpeg'; // Ảnh đại diện mặc định

 // Gửi thông tin người dùng Instagram
 api.sendMessage({
 body: `Thông tin người dùng Instagram:\n- Tên: ${fullName}\n- Username: ${userName}\n- Số bài viết: ${posts}\n- Số người theo dõi: ${followers}\n- Số người đang theo dõi: ${following}\n- Tiểu sử: ${biography}`,
 attachment: await streamURL(profilePic, 'jpg') // Gửi ảnh đại diện
 }, tid, mid);

 } catch (error) {
 console.error('API Error:', error); // Log API error
 api.sendMessage("❎ Không thể lấy thông tin người dùng này.", tid, mid);
 }
 break;

 case 'post':
 const postUrl = argument;
 if (!postUrl) {
 return api.sendMessage("Vui lòng cung cấp URL bài viết!", tid, mid);
 }
 try {
 const response = await axios.get(`https://api.phungtuanhai.site/api/instagram/post?apikey=${API_KEY}&url=${encodeURIComponent(postUrl)}`);
 const data = response.data;
 console.log(data); // Log data để kiểm tra
 if (data.error) {
 return api.sendMessage("❎ URL không hợp lệ hoặc có lỗi xảy ra.", tid, mid);
 }
 api.sendMessage({
 body: `Bài viết Instagram:\n- Tiêu đề: ${data.caption}\n- Người đăng: ${data.username}\n- Số lượt thích: ${data.likes}\n- Số lượt bình luận: ${data.comments}\n- Link bài viết: ${data.link}`,
 attachment: await streamURL(data.media[0], 'jpg')
 }, tid, mid);
 } catch (error) {
 console.error(error);
 api.sendMessage("❎ Không thể lấy bài viết từ URL này.", tid, mid);
 }
 break;

 case 'search':
 const searchKeyword = argument;
 if (!searchKeyword) {
 return api.sendMessage("Vui lòng cung cấp từ khóa tìm kiếm!", tid, mid);
 }
 try {
 const response = await axios.get(`https://api.phungtuanhai.site/api/instagram/search?apikey=${API_KEY}&username=${searchKeyword}`);
 const data = response.data;
 console.log(data); // Log data để kiểm tra
 if (data.error) {
 return api.sendMessage("❎ Không tìm thấy kết quả tìm kiếm.", tid, mid);
 }
 const results = data.users.slice(0, 5); 
 const listMessage = results.map((user, index) => `|› ${index + 1}. Tên: ${user.full_name}\n|› Username: ${user.username}\n|› Tiểu sử: ${user.biography}\n──────────────────`).join('\n');
 api.sendMessage({
 body: `[ Instagram Search Results ]\n──────────────────\n${listMessage}\n\n📌 Reply (phản hồi) STT để xem thông tin chi tiết`, 
 attachment: await Promise.all(results.map(user => streamURL(user.profile_pic_url_hd, 'jpg'))) // Lấy ảnh đại diện
 }, tid, (error, info) => {
 if (error) return console.error("Error sending message:", error);
 global.client.handleReply.push({
 type: "search",
 name: exports.config.name,
 author: sid,
 messageID: info.messageID,
 result: results,
 });
 });
 } catch (error) {
 console.error(error);
 api.sendMessage("❎ Không thể tìm kiếm với từ khóa này.", tid, mid);
 }
 break;

 default:
 api.sendMessage({
 body: `Sử dụng các lệnh:\n- download [URL]\n- info [username]\n- post [URL]\n- search [username]`,
 attachment: await streamURL('https://files.catbox.moe/1rybcw.jpeg', 'jpg')
 }, tid, mid);
 break;
 }
};

async function streamURL(url, ext = 'jpg') {
 try {
 const response = await axios.get(url, { responseType: 'stream' });
 response.data.path = `tmp.${ext}`;
 return response.data;
 } catch (error) {
 console.error("Error streaming URL:", error);
 return null;
 }
}

module.exports.handleReply = async function ({ event, api, handleReply }) {
 const { threadID: tid, messageID: mid, body } = event;
 const choose = parseInt(body);
 if (isNaN(choose)) {
 return api.sendMessage('⚠️ Vui lòng nhập một số hợp lệ.', tid, mid);
 }
 const selected = handleReply.result[choose - 1];
 if (!selected) {
 return api.sendMessage('❎ Lựa chọn không hợp lệ.', tid, mid);
 }
 switch (handleReply.type) {
 case 'postuser':
 api.unsendMessage(handleReply.messageID);
 api.sendMessage({
 body: `Bài viết Instagram:\n- Tiêu đề: ${selected.caption}\n- Link: ${selected.link}`,
 attachment: await streamURL(selected.media[0], 'jpg') // Lấy ảnh đầu tiên từ bài viết
 }, tid, mid);
 break;

 case 'search':
 api.unsendMessage(handleReply.messageID);
 api.sendMessage({
 body: `Thông tin người dùng Instagram:\n- Tên: ${selected.full_name}\n- Username: ${selected.username}\n- Số bài viết: ${selected.media_count}\n- Số người theo dõi: ${selected.follower_count}\n- Số người đang theo dõi: ${selected.following_count}\n- Tiểu sử: ${selected.biography}`,
 attachment: await streamURL(selected.profile_pic_url_hd, 'jpg') // Gửi ảnh đại diện
 }, tid, mid);
 break;

 default:
 break;
 }
};