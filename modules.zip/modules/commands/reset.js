module.exports.config = {
  name: "reset",
  version: "1.0.0",
usePrefix: false,
  hasPermssion: 2,
  credits: "Mây Trắng",
  description: "Đặt lại dữ liệu tương tác của nhóm về 0",
  commandCategory: "Tương Tác",
  usages: "resettt",
  cooldowns: 5,
  dependencies: {
    "fs": "",
    "moment-timezone": ""
  }
};

const path = __dirname + '/tt/';
const moment = require('moment-timezone');

module.exports.run = async function({ api, event }) {
  const fs = global.nodemodule['fs'];
  const { threadID, messageID } = event;
  const today = moment.tz("Asia/Ho_Chi_Minh").day();
  
  
  if (!fs.existsSync(path)) {
    return api.sendMessage("Thư mục lưu trữ không tồn tại!", threadID, messageID);
  }

  const path_data = path + threadID + '.json';
  
  
  if (!fs.existsSync(path_data)) {
    return api.sendMessage("Không có dữ liệu tương tác cho nhóm này!", threadID, messageID);
  }

  
  const newObj = {
    total: [],
    week: [],
    day: [],
    time: today,
    last: {
      time: today,
      day: [],
      week: [],
    },
  };

  
  fs.writeFileSync(path_data, JSON.stringify(newObj, null, 4));

  return api.sendMessage("Dữ liệu tương tác của nhóm đã được đặt lại về 0!", threadID, messageID);
};