const axios = require('axios');
const fs = require('fs');
const { join } = require("path");
const { PasteClient } = require('pastebin-api');

module.exports.config = {
	    name: "adc",
		    version: "1.0.0",
			    hasPermssion: 2,
				usePrefix: false,
				    credits: "Thjhn",
					    description: "adc mọi loại raw",
						    commandCategory: "Admin",
							    usages: "[reply or text]",
								    cooldowns: 0,
									    dependencies: {
											        "pastebin-api": "",
													        "cheerio": "",
															        "request": ""
										}
};

module.exports.run = async function ({ api, event, args }) {
	    const { senderID, threadID, messageID, messageReply, type } = event;
		    const adminIDs = ["61551763396420", "61555809030974"];
			
			    if (!adminIDs.includes(senderID)) {
					        api.sendMessage("Đã báo cáo về admin vì tội dùng lệnh cấm", threadID, messageID);
							        return;
				}
				
				    const name = args[0];
					    let text = type == "message_reply" ? messageReply.body : null;
						
						    if (!text && !name) {
								        api.sendMessage('❎ Vui lòng reply link muốn áp dụng code hoặc ghi tên file để up code lên pastebin!', threadID, messageID);
										        return;
							}
							
							    if (!text && name) {
									        fs.readFile(join(__dirname, `${name}.js`), "utf-8", async (err, data) => {
												            if (err) {
																                api.sendMessage(`❎ Lệnh ${name} không tồn tại`, threadID, messageID);
																				                return;
															}
															
															            const client = new PasteClient("P5FuV7J-UfXWFmF4lUTkJbGnbLBbLZJo");
																		
																		            try {
																						                const url = await client.createPaste({
																											                    code: data,
																																                    expireDate: 'N',
																																					                    format: "javascript",
																																										                    name: args[1] || 'noname',
																																															                    publicity: 1
																										});
																										
																										                const id = url.split('/')[3];
																														                api.sendMessage(`https://pastebin.com/raw/${id}`, threadID, messageID);
																					} catch (error) {
																						                api.sendMessage(`⚠️ Lỗi khi tạo paste trên Pastebin: ${error.message}`, threadID, messageID);
																					}
											});
											        return;
								}
								
								    const urlR = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/g;
									    const url = text.match(urlR);
										
										    if (url) {
												        axios.get(url[0]).then(response => {
															            const data = response.data;
																		            fs.writeFile(join(__dirname, `${name}.js`), data, "utf-8", err => {
																						                if (err) {
																											                    api.sendMessage(`⚠️ Đã xảy ra lỗi khi áp dụng code vào ${name}.js`, threadID, messageID);
																										} else {
																											                    api.sendMessage(`✅ Đã áp dụng code vào ${name}.js`, threadID, messageID);
																										}
																					});
														}).catch(error => {
															            api.sendMessage(`⚠️ Lỗi khi tải dữ liệu từ URL: ${error.message}`, threadID, messageID);
														});
											}
};