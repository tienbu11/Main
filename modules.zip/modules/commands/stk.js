module.exports.config = {
  name: "stk",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "NL",
  description: "Tìm sticker Giphy theo từ khóa",
  commandCategory: "tiện ích",
  usages: "getsticker [keyword]",
  cooldowns: 5,
  usePrefix: false
};

module.exports.run = async function({ api, event, args }) {
  const axios = require('axios');
  const keyword = args.join(" ");

  if (!keyword) {
    return api.sendMessage('Vui lòng nhập từ khóa tìm kiếm!', event.threadID, event.messageID);
  }

  try {
    const apiUrl = `https://hoanghao.me/api/giphy/sticker-search?keyword=${encodeURIComponent(keyword)}`;
    const response = await axios.get(apiUrl);

    
    if (response.status !== 200) {
      throw new Error(`Lỗi từ API: Mã trạng thái ${response.status}`);
    }

    const data = response.data;

    
    if (!data || !data.data || data.data.length === 0) {
      return api.sendMessage('Không tìm thấy sticker nào với từ khóa này!', event.threadID, event.messageID);
    }

   
    const stickerUrl = data.data[Math.floor(Math.random() * data.data.length)].url;

    
    return api.sendMessage({
      attachment: stickerUrl
    }, event.threadID, event.messageID);

  } catch (e) {
    
    console.error(e);
    return api.sendMessage('Đã xảy ra lỗi khi gọi API. Vui lòng thử lại sau.', event.threadID, event.messageID);
  }
};
