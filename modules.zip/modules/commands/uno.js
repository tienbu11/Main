module.exports.config = {
    name: "uno",
    version: "1.0.0",
    hasPermssion: 0,
    usePrefix: false,
    credits: "Procode LTH",
    description: "Chơi trò chơi bài Uno",
    commandCategory: "Game",
    usages: "",
    cooldowns: 5,
    dependencies: {}
};

let games = {};

module.exports.run = async function({ api, event, args, Users }) {
    const threadID = event.threadID;
    const senderID = event.senderID;
    const messageID = event.messageID;

    if (!games[threadID]) {
        games[threadID] = {
            players: [],
            deck: createDeck(),
            currentCard: null,
            direction: 1,
            turnIndex: 0,
            inProgress: false
        };
        games[threadID].players.push({
            id: senderID,
            hand: drawCards(games[threadID].deck, 7)
        });

        return api.sendMessage("Trò chơi Uno đã được tạo. Người chơi có thể tham gia bằng cách dùng lệnh 'uno join'. Khi đủ người, dùng lệnh 'uno start' để bắt đầu.", threadID, messageID);
    } else {
        const game = games[threadID];

        if (args[0] === "join") {
            if (game.inProgress) return api.sendMessage("Trò chơi đang diễn ra. Bạn không thể tham gia lúc này.", threadID, messageID);
            if (game.players.some(p => p.id === senderID)) return api.sendMessage("Bạn đã tham gia trò chơi rồi.", threadID, messageID);

            game.players.push({
                id: senderID,
                hand: drawCards(game.deck, 7)
            });

            return api.sendMessage("Bạn đã tham gia trò chơi Uno!", threadID, messageID);

        } else if (args[0] === "start") {
            if (game.inProgress) return api.sendMessage("Trò chơi đã bắt đầu.", threadID, messageID);
            if (game.players.length < 2) return api.sendMessage("Cần ít nhất 2 người chơi để bắt đầu trò chơi.", threadID, messageID);

            game.inProgress = true;
            game.currentCard = game.deck.pop();

            return api.sendMessage(`Trò chơi Uno đã bắt đầu! Lá bài đầu tiên là ${cardToString(game.currentCard)}.`, threadID, messageID, () => {
                sendCurrentPlayerPrompt(api, threadID, Users);
            });

        } else if (args[0] === "play") {
            if (!game.inProgress) return api.sendMessage("Trò chơi chưa bắt đầu.", threadID, messageID);
            const player = game.players[game.turnIndex];
            if (player.id !== senderID) return api.sendMessage("Không phải lượt của bạn!", threadID, messageID);

            const cardIndex = parseInt(args[1], 10) - 1;
            if (isNaN(cardIndex) || cardIndex < 0 || cardIndex >= player.hand.length) return api.sendMessage("Số thứ tự lá bài không hợp lệ.", threadID, messageID);

            const selectedCard = player.hand[cardIndex];
            if (!canPlayCard(selectedCard, game.currentCard)) return api.sendMessage("Lá bài này không hợp lệ.", threadID, messageID);

            game.currentCard = selectedCard;
            player.hand.splice(cardIndex, 1);

            if (player.hand.length === 0) {
                api.sendMessage(`Người chơi ${await getName(senderID, Users)} đã thắng trò chơi Uno!`, threadID);
                delete games[threadID];
                return;
            }

            handleSpecialCards(selectedCard, game);

            game.turnIndex = (game.turnIndex + game.direction + game.players.length) % game.players.length;
            sendCurrentPlayerPrompt(api, threadID, Users);

        } else if (args[0] === "draw") {
            if (!game.inProgress) return api.sendMessage("Trò chơi chưa bắt đầu.", threadID, messageID);
            const player = game.players[game.turnIndex];
            if (player.id !== senderID) return api.sendMessage("Không phải lượt của bạn!", threadID, messageID);

            const newCard = game.deck.pop();
            player.hand.push(newCard);

            api.sendMessage(`Bạn đã rút 1 lá bài: ${cardToString(newCard)}`, threadID, senderID, () => {
                sendCurrentPlayerPrompt(api, threadID, Users);
            });

        } else if (args[0] === "end") {
            if (game.inProgress) {
                delete games[threadID];
                return api.sendMessage("Trò chơi Uno đã kết thúc.", threadID, messageID);
            }
        } else {
            return api.sendMessage("Sử dụng: 'uno join' để tham gia, 'uno start' để bắt đầu, 'uno play <số>' để đánh bài, 'uno draw' để rút bài, 'uno end' để kết thúc.", threadID, messageID);
        }
    }
};

function createDeck() {
    const colors = ["red", "green", "blue", "yellow"];
    const values = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "skip", "reverse", "draw2"];
    let deck = [];

    for (let color of colors) {
        for (let value of values) {
            deck.push({ color, value });
            if (value !== "0") deck.push({ color, value });
        }
    }

    for (let i = 0; i < 4; i++) {
        deck.push({ color: "wild", value: "wild" });
        deck.push({ color: "wild", value: "wild_draw4" });
    }

    return deck.sort(() => Math.random() - 0.5);
}

function drawCards(deck, number) {
    return deck.splice(deck.length - number, number);
}

function cardToString(card) {
    return `${card.color === "wild" ? "Wild" : capitalizeFirstLetter(card.color)} ${card.value}`;
}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

function canPlayCard(card, currentCard) {
    return card.color === "wild" || card.color === currentCard.color || card.value === currentCard.value;
}

function handleSpecialCards(card, game) {
    if (card.value === "reverse") {
        game.direction *= -1;
    } else if (card.value === "skip") {
        game.turnIndex = (game.turnIndex + game.direction + game.players.length) % game.players.length;
    } else if (card.value === "draw2") {
        const nextPlayer = game.players[(game.turnIndex + game.direction + game.players.length) % game.players.length];
        nextPlayer.hand.push(...drawCards(game.deck, 2));
    } else if (card.value === "wild_draw4") {
        const nextPlayer = game.players[(game.turnIndex + game.direction + game.players.length) % game.players.length];
        nextPlayer.hand.push(...drawCards(game.deck, 4));
    }
}

async function sendCurrentPlayerPrompt(api, threadID, Users) {
    const game = games[threadID];
    const currentPlayer = game.players[game.turnIndex];

    api.sendMessage(`Lượt của bạn, ${await getName(currentPlayer.id, Users)}. Lá bài hiện tại: ${cardToString(game.currentCard)}.\n\nBài của bạn:\n${currentPlayer.hand.map((card, index) => `${index + 1}. ${cardToString(card)}`).join('\n')}\n\nSử dụng 'uno play <số>' để đánh bài hoặc 'uno draw' để rút bài.`, threadID, currentPlayer.id);
}

async function getName(userID, Users) {
    const userInfo = await Users.getData(userID);
    return userInfo.name;
}
