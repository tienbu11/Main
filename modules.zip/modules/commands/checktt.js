module.exports.config = {
  name: "check",
  version: "1.0.0",
  usePrefix: false,
  hasPermssion: 0,
  credits: "Mây Trắng",
  description: "Check tất cả tương tác trong ngày/tuần/tổng",
  commandCategory: "Tương Tác",
  usages: "[day/week/all]",
  cooldowns: 5,
  dependencies: {
    "fs": "",
    "moment-timezone": ""
  }
};

const path = __dirname + '/tt/';
const moment = require('moment-timezone');

module.exports.onLoad = () => {
  const fs = require('fs');
  if (!fs.existsSync(path) || !fs.statSync(path).isDirectory()) {
    fs.mkdirSync(path, { recursive: true });
  }
};

module.exports.handleEvent = async function({ api, event }) {
  try {
    if (!event.isGroup) return;
    const fs = global.nodemodule['fs'];
    const { threadID, senderID } = event;
    const today = moment.tz("Asia/Ho_Chi_Minh").day();

    if (!fs.existsSync(path + threadID + '.json')) {
      var newObj = {
        total: [],
        week: [],
        day: [],
        time: today,
        last: {
          time: today,
          day: [],
          week: [],
        },
      };
      fs.writeFileSync(path + threadID + '.json', JSON.stringify(newObj, null, 4));
    } else {
      var newObj = JSON.parse(fs.readFileSync(path + threadID + '.json'));
    }

    const threadData = JSON.parse(fs.readFileSync(path + threadID + '.json'));
    if (threadData.time != today) {
      threadData.day.forEach(e => e.count = 0);
      if (today == 1) {
        threadData.week.forEach(e => e.count = 0);
      }
      threadData.time = today;
    }

    const userIndex = threadData.total.findIndex(e => e.id == senderID);
    if (userIndex == -1) {
      threadData.total.push({ id: senderID, count: 1 });
    } else {
      threadData.total[userIndex].count++;
    }

    const userIndexWeek = threadData.week.findIndex(e => e.id == senderID);
    if (userIndexWeek == -1) {
      threadData.week.push({ id: senderID, count: 1 });
    } else {
      threadData.week[userIndexWeek].count++;
    }

    const userIndexDay = threadData.day.findIndex(e => e.id == senderID);
    if (userIndexDay == -1) {
      threadData.day.push({ id: senderID, count: 1 });
    } else {
      threadData.day[userIndexDay].count++;
    }

    fs.writeFileSync(path + threadID + '.json', JSON.stringify(threadData, null, 4));
  } catch (e) {
    console.log(e);
  }
};

module.exports.run = async function({ api, event, args }) {
  const fs = global.nodemodule['fs'];
  const { threadID, messageID } = event;
  const path_data = path + threadID + '.json';
  if (!fs.existsSync(path_data)) {
    return api.sendMessage("Chưa có dữ liệu", threadID);
  }

  const threadData = JSON.parse(fs.readFileSync(path_data));
  const command = args[0] ? args[0].toLowerCase() : 'all';

  let dataToDisplay = [];
  if (command === 'day') {
    dataToDisplay = threadData.day;
  } else if (command === 'week') {
    dataToDisplay = threadData.week;
  } else {
    dataToDisplay = threadData.total;
  }

  dataToDisplay.sort((a, b) => b.count - a.count);

  let message = `== [ CHECKTT ${command.toUpperCase()} ] ==\n`;
  for (const [index, user] of dataToDisplay.entries()) {
    const userInfo = await api.getUserInfo(user.id);
    const userName = userInfo[user.id].name;
    message += `${index + 1}. ${userName}: ${user.count}\n`;
  }

  return api.sendMessage(message, threadID, messageID);
};