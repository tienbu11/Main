module.exports.config = {
    name: "work",
    usePrefix: false,
    version: "0.0.2",
    hasPermssion: 0,
    credits: "Mirai Team",
    description: "Có làm thì mới có ăn!",
    commandCategory: "Kiếm tiền",
    cooldowns: 5,
    envConfig: {
        cooldownTime: 60
    }
};

module.exports.run = async ({ event, api, Currencies }) => {
    const { threadID, messageID, senderID } = event;
    const cooldown = global.configModule[this.config.name].cooldownTime;

    try {
        let userData = await Currencies.getData(senderID);
        if (!userData) userData = {};

        if (userData.workTime && (Date.now() - userData.workTime) < cooldown * 1000) {
            const remainingTime = cooldown * 1000 - (Date.now() - userData.workTime);
            const minutes = Math.floor(remainingTime / 60000);
            const seconds = Math.floor((remainingTime % 60000) / 1000);
            return api.sendMessage(`Bạn đang trong thời gian chờ. Vui lòng thử lại sau: ${minutes} phút ${(seconds < 10 ? "0" : "")}${seconds} giây!`, threadID, messageID);
        }

        const jobs = [
            { job: "đi bán vé số", amount: Math.floor(Math.random() * 5000) + 1000 },
            { job: "đi sửa xe", amount: Math.floor(Math.random() * 5000) + 2000 },
            { job: "làm nhân viên lập trình", amount: Math.floor(Math.random() * 10000) + 5000 },
            { job: "đi hack facebook", amount: Math.floor(Math.random() * 8000) + 3000 },
            { job: "làm thợ sửa ống nước ( ͡° ͜ʖ ͡°)", amount: Math.floor(Math.random() * 7000) + 2000 },
            { job: "làm đầu bếp", amount: Math.floor(Math.random() * 6000) + 2000 },
            { job: "làm thợ hồ", amount: Math.floor(Math.random() * 5000) + 1000 },
            { job: "đi bán hàng online", amount: Math.floor(Math.random() * 7000) + 3000 },
            { job: "làm nội trợ gia đình", amount: Math.floor(Math.random() * 4000) + 1000 },
            { job: "đi giật bồ người khác", amount: Math.floor(Math.random() * 6000) + 2000 },
            { job: "đi vả mấy ông mấy bà hàng xóm", amount: Math.floor(Math.random() * 5000) + 1000 },
            { job: "đi bán hoa", amount: Math.floor(Math.random() * 7000) + 3000 },
            { job: "chơi Yasuo trong rank và gánh team", amount: Math.floor(Math.random() * 10000) + 5000 }
        ];

        const randomJob = jobs[Math.floor(Math.random() * jobs.length)];

        await Currencies.increaseMoney(senderID, randomJob.amount);
        userData.workTime = Date.now();
        await Currencies.setData(senderID, { data: userData });

        return api.sendMessage(`Bạn ${randomJob.job} và đã nhận được số tiền là: ${randomJob.amount} coins`, threadID, messageID);
    } catch (error) {
        console.error("Error in 'work' command:", error);
        return api.sendMessage("Có lỗi xảy ra trong quá trình thực hiện lệnh 'work'. Vui lòng thử lại sau.", threadID, messageID);
    }
};
