const { createCanvas, loadImage } = require('canvas');
const fs = require('fs');
const path = require('path');

exports.config = {
 name: 'fakebill',
 version: '1.0.0',
 hasPermssion: 0,
 usePrefix: true,
 credits: 'hiếu',
 description: 'Giả lập hóa đơn chuyển tiền ngân hàng MB',
 commandCategory: 'Tiện ích',
 usages: '[tên người nhận] [số tiền] [ngân hàng nhận] [số tài khoản] [nội dung]',
 cooldowns: 5,
};

async function generateFakeBill({ recipientName, amount, bankName, accountNumber, description }) {
 try {
 const canvas = createCanvas(720, 1557);
 const ctx = canvas.getContext('2d');

 const templatePath = path.join(__dirname, 'bill-mbbank.jpg');
 if (!fs.existsSync(templatePath)) {
 throw new Error(`Template not found at path: ${templatePath}`);
 }

 const template = await loadImage(templatePath);
 ctx.drawImage(template, 0, 0, canvas.width, canvas.height);

 ctx.font = '36px Arial';
 ctx.fillStyle = '#000';

 ctx.fillText(recipientName, 50, 180);
 ctx.fillText(`${amount} VND`, 250, 480);
 ctx.fillText(`Chuyển từ tài khoản ${accountNumber}`, 50, 960);
 ctx.fillText(bankName, 50, 940);

 ctx.font = '28px Arial';
 ctx.fillText(description, 50, 1020);

 const filePath = path.join(__dirname, 'https://files.catbox.moe/o5os7c.jpeg');
 const buffer = canvas.toBuffer('image/png');
 fs.writeFileSync(filePath, buffer);

 return filePath;
 } catch (error) {
 console.error('Error generating bill:', error.message);
 throw error;
 }
}

exports.run = async function ({ api, event, args }) {
 const { threadID: tid, messageID: mid } = event;

 if (args.length < 5) {
 return api.sendMessage('Vui lòng cung cấp đầy đủ thông tin: tên người nhận, số tiền, ngân hàng nhận, số tài khoản, và nội dung.', tid, mid);
 }

 const [recipientName, amount, bankName, accountNumber, ...descriptionParts] = args;
 const description = descriptionParts.join(' ');

 try {
 const filePath = await generateFakeBill({
 recipientName,
 amount,
 bankName,
 accountNumber,
 description,
 });

 api.sendMessage({
 body: 'Đây là hóa đơn chuyển tiền ngân hàng MB của bạn.',
 attachment: fs.createReadStream(filePath)
 }, tid, mid);
 } catch (error) {
 api.sendMessage('❎ Có lỗi xảy ra khi tạo hóa đơn.', tid, mid);
 }
};