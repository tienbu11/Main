const axios = require('axios');

module.exports.config = {
    name: "checkdomain",
    version: "1.0.0",
    usePrefix: false,
    hasPermission: 0,
    credits: "Ng Văn Chiến",
    description: "Kiểm tra thông tin tên miền",
    commandCategory: "Tiện ích",
    cooldowns: 0
};

module.exports.run = async ({ event, api, args }) => {
    let send = (msg) => api.sendMessage(msg, event.threadID, event.messageID);

    const domain = args.join(" ");
    if (!domain) {
        return send("Vui lòng cung cấp tên miền để kiểm tra. Ví dụ: checkdomain sumiproject.io.vn");
    }

    const url = `https://apibot.dungkon.me/checkdomain?domain=${encodeURIComponent(domain)}`;

    try {
        const response = await axios.get(url);
        const domainInfo = response.data;

        if (domainInfo.status !== "success") {
            return send("Không tìm thấy thông tin cho tên miền đã cung cấp.");
        }

        let message = `Thông tin tên miền:\n`;
        message += `Châu lục: ${domainInfo.continent}\n`;
        message += `Mã châu lục: ${domainInfo.continentCode}\n`;
        message += `Quốc gia: ${domainInfo.country}\n`;
        message += `Mã quốc gia: ${domainInfo.countryCode}\n`;
        message += `Khu vực: ${domainInfo.region}\n`;
        message += `Tên khu vực: ${domainInfo.regionName}\n`;
        message += `Thành phố: ${domainInfo.city}\n`;
        message += `Quận: ${domainInfo.district || "Không có thông tin"}\n`;
        message += `Mã bưu điện: ${domainInfo.zip}\n`;
        message += `Vĩ độ: ${domainInfo.lat}\n`;
        message += `Kinh độ: ${domainInfo.lon}\n`;
        message += `Múi giờ: ${domainInfo.timezone}\n`;
        message += `Chênh lệch giờ: ${domainInfo.offset}\n`;
        message += `Tiền tệ: ${domainInfo.currency}\n`;
        message += `Nhà cung cấp dịch vụ Internet (ISP): ${domainInfo.isp}\n`;
        message += `Tổ chức: ${domainInfo.org}\n`;
        message += `AS: ${domainInfo.as}\n`;
        message += `Tên AS: ${domainInfo.asname}\n`;
        message += `Reverse: ${domainInfo.reverse || "Không có thông tin"}\n`;
        message += `Di động: ${domainInfo.mobile ? "Có" : "Không"}\n`;
        message += `Proxy: ${domainInfo.proxy ? "Có" : "Không"}\n`;
        message += `Lưu trữ: ${domainInfo.hosting ? "Có" : "Không"}\n`;
        message += `Truy vấn: ${domainInfo.query}\n`;

        await send(message);
    } catch (error) {
        console.error('Lỗi:', error.response ? error.response.data : error.message);
        send("Có lỗi xảy ra khi gọi API.");
    }
};
