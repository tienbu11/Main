const fs = require('fs');

exports.config = {
 name: 'vuatv',
 version: '1.0.0',
 hasPermssion: 0,
 usePrefix: false,
 credits: 'Trung Hieu',
 description: 'Trò chơi sắp xếp từ',
 commandCategory: 'Tiện ích',
 usages: '[]',
 cooldowns: 5,
};

const wordsFilePath = './modules/commands/Game/words.json';
const adminUIDs = ['61555809030974', '', ''];

let gameData = {};

function readWords() {
 if (fs.existsSync(wordsFilePath)) {
 const rawData = fs.readFileSync(wordsFilePath);
 return JSON.parse(rawData).words;
 }
 return [];
}

function writeWords(words) {
 fs.writeFileSync(wordsFilePath, JSON.stringify({ words }, null, 2));
}

function shuffleString(str) {
 const arr = str.split('');
 for (let i = arr.length - 1; i > 0; i--) {
 const j = Math.floor(Math.random() * (i + 1));
 [arr[i], arr[j]] = [arr[j], arr[i]];
 }
 return arr.join('');
}

function sendNewQuestion(api, tid, mid, sid) {
 let words = readWords();
 if (words.length === 0) {
 return api.sendMessage("Hiện tại chưa có từ nào trong trò chơi. Vui lòng thêm từ trước khi bắt đầu.", tid, mid);
 }
 const randomIndex = Math.floor(Math.random() * words.length);
 const keyword = words[randomIndex];
 const shuffledKeyword = shuffleString(keyword);
 const question = `🔠 Sắp xếp lại các chữ cái để tìm từ đúng: ${shuffledKeyword.split('').join(' ')}\n\nBạn có 60 giây để trả lời và 5 lượt để trả lời.`;

 gameData[tid] = {
 answer: keyword.toLowerCase(),
 attempts: 5,
 active: true,
 creator: sid,
 timeout: setTimeout(() => {
 if (gameData[tid] && gameData[tid].active) {
 api.sendMessage('⏰ Hết thời gian trả lời! Trò chơi đã kết thúc.', tid, mid);
 gameData[tid].active = false;
 }
 }, 60000)
 };

 api.sendMessage(question, tid, (error, info) => {
 if (error) return console.error(error);
 global.client.handleReply.push({
 type: 'game',
 name: exports.config.name,
 author: sid,
 messageID: info.messageID,
 result: keyword.toLowerCase()
 });
 gameData[tid].questionMessageID = info.messageID; // Lưu ID của tin nhắn câu hỏi
 });
}

exports.run = async function ({ api, event, args }) {
 const { threadID: tid, messageID: mid, senderID: sid } = event;
 const command = args[0];

 switch (command) {
 case 'start':
 sendNewQuestion(api, tid, mid, sid);
 break;

 case 'add':
 if (!adminUIDs.includes(sid)) {
 return api.sendMessage('Bạn không có quyền thêm từ vào trò chơi.', tid, mid);
 }

 const newWord = args.slice(1).join(' ').trim();
 if (!newWord) {
 return api.sendMessage('Vui lòng cung cấp từ bạn muốn thêm.', tid, mid);
 }

 let words = readWords();
 words.push(newWord.toLowerCase());
 writeWords(words);
 api.sendMessage(`Đã thêm từ "${newWord}" vào trò chơi.`, tid, mid);
 break;

 case 'del':
 if (!adminUIDs.includes(sid)) {
 return api.sendMessage('Bạn không có quyền xóa từ khỏi trò chơi.', tid, mid);
 }

 const wordToDelete = args.slice(1).join(' ').trim().toLowerCase();
 if (!wordToDelete) {
 return api.sendMessage('Vui lòng cung cấp từ bạn muốn xóa.', tid, mid);
 }

 let wordsList = readWords();
 const wordIndex = wordsList.indexOf(wordToDelete);
 if (wordIndex === -1) {
 return api.sendMessage(`Từ "${wordToDelete}" không có trong danh sách.`, tid, mid);
 }

 wordsList.splice(wordIndex, 1);
 writeWords(wordsList);
 api.sendMessage(`Đã xóa từ "${wordToDelete}" khỏi trò chơi.`, tid, mid);
 break;

 default:
 api.sendMessage('Sử dụng lệnh: start, add hoặc del', tid, mid);
 break;
 }
};

module.exports.handleReply = async function ({ event, api, handleReply }) {
 const { threadID: tid, messageID: mid, body, senderID } = event;
 const game = gameData[tid];

 if (!game || !game.active) {
 return api.sendMessage('❎ Không có trò chơi nào đang hoạt động hoặc trò chơi đã kết thúc.', tid, mid);
 }

 if (senderID !== game.creator) {
 return api.sendMessage('❎ Bạn không phải là người khởi tạo trò chơi này.', tid, mid);
 }

 const userAnswer = body.trim().toLowerCase();
 const correctAnswer = handleReply.result.toLowerCase();

 if (userAnswer === correctAnswer) {
 api.sendMessage('✅ Chúc mừng! Bạn đã trả lời đúng.', tid, mid);
 game.active = false;
 clearTimeout(game.timeout);
 api.unsendMessage(game.questionMessageID); // Thu hồi câu hỏi
 sendNewQuestion(api, tid, mid, senderID);
 } else {
 game.attempts--;
 if (game.attempts <= 0) {
 api.sendMessage(`❎ Bạn đã hết lượt trả lời. Đáp án đúng là: ${correctAnswer}`, tid, mid);
 game.active = false;
 clearTimeout(game.timeout);
 } else {
 api.sendMessage(`❎ Sai rồi! Bạn còn ${game.attempts} lượt để trả lời.`, tid, mid);
 }
 }
};