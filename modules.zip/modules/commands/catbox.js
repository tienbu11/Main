const axios = require('axios');

module.exports = {
 config: {
 name: 'catbox',
 commandCategory: 'Tiện ích',
 usePrefix: false,
 hasPermssion: 0,
 credits: 'Lê Minh Tiến',
 usages: 'chuyển ảnh, video, gif sang link catbox',
 description: 'chuyển ảnh,video,gif sang link catbox',
 cooldowns: 0
 },
 run: async (o) => {
 const send = (msg) => o.api.sendMessage(msg, o.event.threadID, o.event.messageID);
 let msg = '';

 if (o.event.type !== "message_reply") {
 return send("⚠️ Hình ảnh không hợp lệ, vui lòng phản hồi một video, ảnh nào đó");
 }

 for (let i of o.event.messageReply.attachments) {
 await axios.get(`https://catbox-mnib.onrender.com/upload?url=${encodeURIComponent(i.url)}`)
 .then(async (response) => {
 msg += `${response.data.url},\n`;
 })
 .catch(error => {
 console.error("Lỗi khi tải lên: ", error);
 msg += "Lỗi khi tải lên tệp đính kèm này.\n";
 });
 }

 return send(msg);
 }
};