
module.exports.config = {
  name: "checktt",
  version: "1.0.0",
  hasPermssion: 0,
  usePrefix: false,
  credits: "Mây Trắng",
  description: "Check tương tác của thành viên trong nhóm",
  commandCategory: "Tương Tác",
  usages: "[tag/reply]",
  cooldowns: 5,
  dependencies: {
    "fs": "",
    "moment-timezone": ""
  }
};

const path = __dirname + '/tt/';
const moment = require('moment-timezone');

const vietnameseDays = ["Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];

module.exports.onLoad = () => {
  const fs = require('fs');
  if (!fs.existsSync(path) || !fs.statSync(path).isDirectory()) {
    fs.mkdirSync(path, { recursive: true });
  }
};

module.exports.handleEvent = async function({ api, event }) {
  try {
    if (!event.isGroup) return;
    const fs = global.nodemodule['fs'];
    const { threadID, senderID } = event;
    const today = moment.tz("Asia/Ho_Chi_Minh").day();

    if (!fs.existsSync(path + threadID + '.json')) {
      var newObj = {
        total: [],
        week: [],
        day: [],
        time: today,
        last: {
          time: today,
          day: [],
          week: [],
        },
      };
      fs.writeFileSync(path + threadID + '.json', JSON.stringify(newObj, null, 4));
    } else {
      var newObj = JSON.parse(fs.readFileSync(path + threadID + '.json'));
    }

    const threadData = JSON.parse(fs.readFileSync(path + threadID + '.json'));
    if (threadData.time != today) {
      threadData.day.forEach(e => e.count = 0);
      if (today == 1) {
        threadData.week.forEach(e => e.count = 0);
      }
      threadData.time = today;
    }

    const userIndex = threadData.total.findIndex(e => e.id == senderID);
    if (userIndex == -1) {
      threadData.total.push({ id: senderID, count: 1 });
    } else {
      threadData.total[userIndex].count++;
    }

    const userIndexWeek = threadData.week.findIndex(e => e.id == senderID);
    if (userIndexWeek == -1) {
      threadData.week.push({ id: senderID, count: 1 });
    } else {
      threadData.week[userIndexWeek].count++;
    }

    const userIndexDay = threadData.day.findIndex(e => e.id == senderID);
    if (userIndexDay == -1) {
      threadData.day.push({ id: senderID, count: 1 });
    } else {
      threadData.day[userIndexDay].count++;
    }

    fs.writeFileSync(path + threadID + '.json', JSON.stringify(threadData, null, 4));
  } catch (e) {
    console.log(e);
  }
};

module.exports.run = async function({ api, event, args, Users }) {
  const fs = global.nodemodule['fs'];
  const { threadID, messageID, senderID, mentions, type } = event;
  const path_data = path + threadID + '.json';
  if (!fs.existsSync(path_data)) {
    return api.sendMessage("Chưa có dữ liệu", threadID);
  }
  const threadData = JSON.parse(fs.readFileSync(path_data));
  let targetID = senderID;
  if (Object.keys(mentions).length > 0) {
    targetID = Object.keys(mentions)[0];
  } else if (type === 'message_reply') {
    targetID = event.messageReply.senderID;
  }

  const userDataTotal = threadData.total.find(e => e.id == targetID) || { count: 0 };
  const userDataWeek = threadData.week.find(e => e.id == targetID) || { count: 0 };
  const userDataDay = threadData.day.find(e => e.id == targetID) || { count: 0 };

  const totalCount = threadData.total.reduce((acc, item) => acc + item.count, 0);
  const totalCountWeek = threadData.week.reduce((acc, item) => acc + item.count, 0);
  const totalCountDay = threadData.day.reduce((acc, item) => acc + item.count, 0);

  const rankTotal = threadData.total.sort((a, b) => b.count - a.count).findIndex(e => e.id == targetID) + 1;
  const rankWeek = threadData.week.sort((a, b) => b.count - a.count).findIndex(e => e.id == targetID) + 1;
  const rankDay = threadData.day.sort((a, b) => b.count - a.count).findIndex(e => e.id == targetID) + 1;

  const userInfo = await api.getUserInfo(targetID);
  const userName = userInfo[targetID].name;
  const joinTime = moment(userInfo[targetID].join_time).tz("Asia/Ho_Chi_Minh");
  const daysInGroup = moment().diff(joinTime, 'days');

  const threadInfo = await api.getThreadInfo(threadID);
  const isAdmin = threadInfo.adminIDs.some(admin => admin.id == targetID);
  const role = isAdmin ? 'Quản trị viên' : 'Thành viên';

  const lastMessageTime = moment(userInfo[targetID].last_message_time).tz("Asia/Ho_Chi_Minh");
  const lastMessageDay = vietnameseDays[lastMessageTime.day()];
  const formattedLastMessageTime = lastMessageTime.format('HH:mm:ss') + ' || ' + lastMessageDay;

  const message = `✨ Tương tác của ${userName}:\n🪪 Chức Vụ: ${role}\n💬 Tổng số tin nhắn: ${userDataTotal.count}\n📅 Số tin nhắn trong tuần: ${userDataWeek.count}\n📆 Số tin nhắn trong ngày: ${userDataDay.count}\n⏰ Lần cuối nhắn tin: ${formattedLastMessageTime}\n📊 Tỉ lệ tương tác: ${(userDataTotal.count / totalCount * 100).toFixed(2)}%\n🏆 Xếp hạng: ${rankTotal}/${threadData.total.length} (tổng)\n🏅 Xếp hạng: ${rankWeek}/${threadData.week.length} (tuần)\n🥇 Xếp hạng: ${rankDay}/${threadData.day.length} (ngày)\n📝 Ngày vào nhóm: ${joinTime.format('HH:mm:ss || YYYY-MM-DD')}\n🗓️ Đã tham gia được: ${daysInGroup} ngày`;

  return api.sendMessage(message, threadID, messageID);
};
