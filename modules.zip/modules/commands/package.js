﻿exports.config = {
  name: 'package',
  version: '0.0.9',
  hasPermssion: 2,
  credits: 'Hải harin',
  description: '',
  commandCategory: 'Admin',
    usePrefix: false,
  usages: '',
  cooldowns: 3
};
exports.run = function(o) {
  const fs = require('fs');
const send = nd => o.api.sendMessage(nd,o.event.threadID)
const filePath = './package.json';
fs.readFile(filePath, 'utf8', (err, data) => {
if (err) {
  console.error(err);
  return;
}
try {
  const packageJson = JSON.parse(data);
  const dependencies = Object.keys(packageJson.dependencies);
  if(o.args.length == 0){
  var msg = []
  msg = `[ PACKAGE LIST ]
━━━━━━━━━━━━━━━━━
→ Hiện đang có ${dependencies.length} gói npm đang sử dụng
⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n`;
  for (let i = 0; i < dependencies.length; i++) {
  msg +=`${i + 1}. ${dependencies[i]}\n`
  }
  o.api.sendMessage(msg+`━━━━━━━━━━━━━━━━━
→ Để gỡ bỏ gói npm, sử dụng lệnh: package uninstall <số thứ tự> hoặc reply với >u + stt<
→ Để tải gói npm, sử dụng lệnh: package install <tên gói>
→ Để xem thông tin gói npm, sử dụng lệnh: package info <số thứ tự> hoặc reply với >i + stt<`,o.event.threadID,  (err, res)=>(res.name = exports.config.name, res.messageID, res.dependencies = dependencies, global.client.handleReply.push(res)))
  }
if(o.args[0] == 'uninstall'){
const { exec } = require('child_process');
const packageName = `${dependencies[o.args[1]-1]}`;
exec(`npm uninstall ${packageName}`, (error, stdout) => {
if (error) {
  send(`Lỗi: ${error.message}`);
  return;
}
send(`Package "${packageName}" đã được xoá thành công.`);
});
}
if(o.args[0] == 'install'){
const { exec } = require('child_process');
const packageName = `${o.args[1]}`;
exec(`npm install ${packageName}`, (error, stdout) => {
if (error) {
  send(`Lỗi: ${error.message}`);
  return;
}
send(`Package "${packageName}" đã được tải thành công.`);
});
}
if(o.args[0] == 'info'){
async function getPackageInfo(packageName) {
const data = (await require("axios").get(`${global.api_url}/tienich/checknpm?apikey=${global.api_key}&npm=${packageName}`)).data
send(`[ PACKAGE INFO ] 
━━━━━━━━━━━━━━━━━
→ Package: ${data.name}
→ Author: ${data.author.name}
→ Mô tả: ${data.description}
→ Phiên bản: ${data.version}
→ Keywords: ${data.keywords.join(', ')}
→ Link: https://www.npmjs.com/package/${dependencies[o.args[1]-1]}
━━━━━━━━━━━━━━━━━`)
}
getPackageInfo(`${dependencies[o.args[1]-1]}`);
}
  } catch (error) {
    send(`Lỗi khi parse file JSON: ${error}`);
}
});
};
exports.handleReply = async function(o) {
o.api.unsendMessage(o.handleReply.messageID)
let send = (msg, callback)=>o.api.sendMessage(msg, o.event.threadID, callback, o.event.messageID);
if(o.event.args[0].toLowerCase() == 'u') {
const { exec } = require('child_process');
const packageName = `${o.handleReply.dependencies[o.event.args[1]-1]}`;
exec(`npm uninstall ${packageName}`, (error, stdout) => {
if (error) {
  send(`Lỗi: ${error.message}`);
  return;
}
send(`Package "${packageName}" đã được xoá thành công.`);
});
}
else if(o.event.args[0].toLowerCase() == 'i'){
async function getPackageInfo(packageName) {
const data = (await require("axios").get(`${global.api_url}/tienich/checknpm?apikey=${global.api_key}&npm=${packageName}`)).data
send(`[ PACKAGE INFO ] 
━━━━━━━━━━━━━━━━━
→ Package: ${data.name}
→ Author: ${data.author.name}
→ Mô tả: ${data.description}
→ Phiên bản: ${data.version}
→ Keywords: ${data.keywords.join(', ')}
→ Link: https://www.npmjs.com/package/${o.handleReply.dependencies[o.event.args[1]-1]}
━━━━━━━━━━━━━━━━━`)
}
getPackageInfo(`${o.handleReply.dependencies[o.event.args[1]-1]}`);
}
       }